<?php
/**
 * Vinetrimmer Playready DRM Tool - AJAX Handler Class
 * 
 * 이 클래스는 WordPress AJAX 요청을 수신하여 Vinetrimmer를 비동기 실행하고,
 * 진행 상태를 JSON 형식으로 반환합니다. WP-Cron을 통해 장시간 작업을 분리하여
 * 서버 타임아웃을 방지합니다.
 *
 * @package Vinetrimmer_DRM
 * @author Bread & Sonion
 * @version 1.5.1
 */

if (!defined('ABSPATH')) {
    exit;
}

class VT_Ajax_Handler {

    /**
     * Loader 인스턴스 (실행 엔진)
     *
     * @var VT_Loader
     */
    private $loader;

    /**
     * 작업 ID (유니크)
     *
     * @var string
     */
    private $job_id;

    /**
     * 생성자: Loader 인스턴스 주입 및 AJAX 훅 등록
     *
     * @param VT_Loader $loader
     */
    public function __construct(VT_Loader $loader) {
        $this->loader = $loader;
        $this->init_hooks();
    }

    /**
     * WordPress AJAX 훅 등록
     */
    private function init_hooks() {
        // 로그인된 사용자용 AJAX
        add_action('wp_ajax_vt_run_async', array($this, 'handle_async_run'));
        add_action('wp_ajax_vt_check_status', array($this, 'handle_status_check'));
        add_action('wp_ajax_vt_cancel_job', array($this, 'handle_cancel_job'));

        // 백그라운드 실행을 위한 WP-Cron 액션
        // 인자 6개: service, url, quality, sub_lang, sub_mode, job_id
        add_action('vt_background_run', array($this, 'background_execute'), 10, 6);

        // 작업 완료 / 실패 시 로깅 콜백
        add_action('vt_job_completed', array($this, 'on_job_completed'), 20, 2);
        add_action('vt_job_failed', array($this, 'on_job_failed'), 20, 2);

        // 주기적인 상태 업데이트 (선택적)
        add_action('vt_heartbeat', array($this, 'heartbeat_check'));

        // 하트비트 스케줄 등록 (커스텀 'vt_minute' 스케줄 사용)
        // 참고: WordPress 기본 스케줄에는 'minute'가 없으므로 메인 플러그인
        //       파일에서 cron_schedules 필터로 등록한 'vt_minute'를 사용한다.
        if (!wp_next_scheduled('vt_heartbeat')) {
            wp_schedule_event(time(), 'vt_minute', 'vt_heartbeat');
        }
    }

    /**
     * 비동기 실행 요청 처리 (AJAX 엔드포인트)
     */
    public function handle_async_run() {
        // 1. 보안 검증
        check_ajax_referer('vt_ajax_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => '권한이 없습니다.'), 403);
        }

        // 2. 입력값 획득 및 정리
        $service  = isset($_POST['service']) ? sanitize_text_field(wp_unslash($_POST['service'])) : '';
        $url      = isset($_POST['url']) ? esc_url_raw(wp_unslash($_POST['url'])) : '';
        $quality  = isset($_POST['quality']) ? sanitize_text_field(wp_unslash($_POST['quality'])) : 'best';
        $sub_lang = isset($_POST['sub_lang']) ? sanitize_text_field(wp_unslash($_POST['sub_lang'])) : 'ko';
        $sub_mode = isset($_POST['sub_mode']) ? sanitize_text_field(wp_unslash($_POST['sub_mode'])) : 'mux';

        // 3. 유효성 검증
        if (empty($service)) {
            wp_send_json_error(array('message' => '서비스를 선택하세요.'), 400);
        }
        if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
            wp_send_json_error(array('message' => '유효한 URL을 입력하세요.'), 400);
        }

        // 4. 작업 고유 ID 생성
        $this->job_id = uniqid('vt_job_', true);
        $job_data = array(
            'id'       => $this->job_id,
            'service'  => $service,
            'url'      => $url,
            'quality'  => $quality,
            'sub_lang' => $sub_lang,
            'sub_mode' => $sub_mode,
            'status'   => 'pending',
            'progress' => 0,
            'message'  => '작업이 대기열에 추가됨',
            'started'  => current_time('mysql'),
            'updated'  => current_time('mysql')
        );

        // 5. 작업 데이터 저장 (WP 옵션 또는 트랜시언트)
        set_transient('vt_job_' . $this->job_id, $job_data, HOUR_IN_SECONDS * 24); // 24시간 유지
        set_transient('vt_current_job', $this->job_id, HOUR_IN_SECONDS);

        // 6. 백그라운드 실행 예약 (WP-Cron)
        $scheduled = wp_schedule_single_event(time() + 5, 'vt_background_run', array(
            $service,
            $url,
            $quality,
            $sub_lang,
            $sub_mode,
            $this->job_id
        ));

        if ($scheduled === false && !wp_next_scheduled('vt_background_run')) {
            // 스케줄 실패 시 직접 실행 (일반적으로는 발생하지 않음)
            $this->background_execute($service, $url, $quality, $sub_lang, $sub_mode, $this->job_id);
        }

        // 7. 즉시 응답 반환 (작업 등록 완료)
        wp_send_json_success(array(
            'job_id'  => $this->job_id,
            'message' => '작업이 백그라운드에 성공적으로 등록되었습니다. 잠시 후 진행률을 확인하세요.'
        ));
    }

    /**
     * 백그라운드 실행 함수 (WP-Cron으로 호출)
     *
     * @param string $service
     * @param string $url
     * @param string $quality
     * @param string $sub_lang 자막 언어 코드 (기본 ko)
     * @param string $sub_mode 자막 처리 방식 (mux | burn | none)
     * @param string $job_id (선택)
     */
    public function background_execute($service, $url, $quality, $sub_lang = 'ko', $sub_mode = 'mux', $job_id = '') {
        if (empty($job_id)) {
            // 현재 진행 중인 작업 ID 조회
            $job_id = get_transient('vt_current_job');
            if (empty($job_id)) {
                $job_id = uniqid('vt_job_', true);
            }
        }

        // 작업 상태 업데이트 (실행 중)
        $job_data = get_transient('vt_job_' . $job_id);
        if ($job_data === false) {
            $job_data = array(
                'id'       => $job_id,
                'service'  => $service,
                'url'      => $url,
                'quality'  => $quality,
                'sub_lang' => $sub_lang,
                'sub_mode' => $sub_mode,
                'status'   => 'running',
                'progress' => 0,
                'message'  => '실행 준비 중...',
                'started'  => current_time('mysql'),
                'updated'  => current_time('mysql')
            );
        }

        $job_data['status'] = 'running';
        $job_data['progress'] = 10;
        $job_data['message'] = 'Vinetrimmer 실행 중...';
        $job_data['updated'] = current_time('mysql');
        set_transient('vt_job_' . $job_id, $job_data, HOUR_IN_SECONDS * 24);

        // Loader를 통해 실제 실행 (자막 언어/모드 포함)
        try {
            $output = $this->loader->run($service, $url, $quality, $sub_lang, $sub_mode);

            // Loader 는 예외를 던지지 않고 결과 문자열을 반환하므로,
            // 출력에서 오류 신호(ERROR:, ❌, 실패 등)를 감지하여 성공/실패를 판정한다.
            if ($this->output_indicates_failure($output)) {
                $job_data['status']  = 'failed';
                $job_data['progress'] = 0;
                $job_data['message'] = '실행 실패 (출력 로그를 확인하세요)';
                $job_data['output']  = $output;
            } else {
                $job_data['status']  = 'completed';
                $job_data['progress'] = 100;
                $job_data['message'] = '실행 완료';
                $job_data['output']  = $output;
            }
            $job_data['updated'] = current_time('mysql');

            // 참고: 실제 다운로드된 파일의 미디어 라이브러리 임포트는
            //       아래 vt_job_completed 훅에서 VT_File_Manager 가 출력
            //       디렉토리의 최신 파일을 스캔하여 처리한다.
            //       ($output 은 CLI 표준 출력 문자열이므로 파일 경로가 아님)

        } catch (Throwable $e) {
            // PHP 7+ : Throwable 로 Error 와 Exception 을 모두 포착
            $job_data['status'] = 'failed';
            $job_data['progress'] = 0;
            $job_data['message'] = '오류: ' . $e->getMessage();
            $job_data['error'] = $e->getTraceAsString();
            $job_data['updated'] = current_time('mysql');
        }

        // 최종 상태 저장
        set_transient('vt_job_' . $job_id, $job_data, HOUR_IN_SECONDS * 24);

        // 현재 작업 ID 초기화
        delete_transient('vt_current_job');

        // 실행 완료 훅 (파일 임포트 등)
        if ($job_data['status'] === 'completed') {
            do_action('vt_job_completed', $job_id, $job_data);
        } else {
            do_action('vt_job_failed', $job_id, $job_data);
        }
    }

    /**
     * 실행 출력 문자열이 실패를 의미하는지 판정
     *
     * @param string|null $output
     * @return bool
     */
    private function output_indicates_failure($output) {
        if (empty($output) || !is_string($output)) {
            return true; // 출력이 전혀 없으면 실패로 간주
        }
        $failure_markers = array('ERROR:', '❌', 'Traceback', 'command not found', '환경 검사 실패');
        foreach ($failure_markers as $marker) {
            if (stripos($output, $marker) !== false) {
                return true;
            }
        }
        return false;
    }

    /**
     * 작업 상태 확인 (AJAX 폴링용)
     */
    public function handle_status_check() {
        check_ajax_referer('vt_ajax_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => '권한이 없습니다.'), 403);
        }

        $job_id = isset($_POST['job_id']) ? sanitize_text_field($_POST['job_id']) : get_transient('vt_current_job');

        if (empty($job_id)) {
            wp_send_json_error(array('message' => '진행 중인 작업이 없습니다.'), 404);
        }

        $job_data = get_transient('vt_job_' . $job_id);

        if ($job_data === false) {
            wp_send_json_error(array('message' => '작업을 찾을 수 없습니다.'), 404);
        }

        // 응답 데이터 구성
        $response = array(
            'job_id'   => $job_id,
            'status'   => $job_data['status'],
            'progress' => intval($job_data['progress']),
            'message'  => $job_data['message']
        );

        // 완료/실패 시 추가 정보 제공
        if ($job_data['status'] === 'completed' || $job_data['status'] === 'failed') {
            $response['final'] = true;
            if (isset($job_data['output'])) {
                $response['output'] = $job_data['output'];
            }
            if (isset($job_data['error'])) {
                $response['error'] = $job_data['error'];
            }
            // 작업 데이터 정리 (완료 후 삭제)
            delete_transient('vt_job_' . $job_id);
        }

        wp_send_json_success($response);
    }

    /**
     * 작업 취소 요청 처리
     */
    public function handle_cancel_job() {
        check_ajax_referer('vt_ajax_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => '권한이 없습니다.'), 403);
        }

        $job_id = isset($_POST['job_id']) ? sanitize_text_field($_POST['job_id']) : '';

        if (empty($job_id)) {
            wp_send_json_error(array('message' => '작업 ID가 필요합니다.'), 400);
        }

        $job_data = get_transient('vt_job_' . $job_id);

        if ($job_data === false) {
            wp_send_json_error(array('message' => '작업을 찾을 수 없습니다.'), 404);
        }

        // 실행 중인 작업만 취소 가능
        if ($job_data['status'] === 'running' || $job_data['status'] === 'pending') {
            $job_data['status'] = 'cancelled';
            $job_data['message'] = '사용자에 의해 취소됨';
            $job_data['updated'] = current_time('mysql');
            set_transient('vt_job_' . $job_id, $job_data, HOUR_IN_SECONDS * 24);
            delete_transient('vt_current_job');

            // WP-Cron 이벤트 제거 (예정된 실행 취소)
            $next_run = wp_next_scheduled('vt_background_run');
            if ($next_run) {
                wp_unschedule_event($next_run, 'vt_background_run');
            }

            wp_send_json_success(array('message' => '작업이 취소되었습니다.'));
        } else {
            wp_send_json_error(array('message' => '이 작업은 취소할 수 없습니다 (이미 완료됨).'), 400);
        }
    }

    /**
     * 하트비트 체크 (오래 실행된 작업 모니터링)
     */
    public function heartbeat_check() {
        $job_id = get_transient('vt_current_job');
        if (empty($job_id)) {
            return;
        }

        $job_data = get_transient('vt_job_' . $job_id);
        if ($job_data === false) {
            delete_transient('vt_current_job');
            return;
        }

        // 실행 시간이 너무 오래 걸리면 (예: 30분) 실패로 처리
        $started = strtotime($job_data['started']);
        $now = current_time('timestamp');
        if (($now - $started) > 1800 && $job_data['status'] === 'running') {
            $job_data['status'] = 'timeout';
            $job_data['message'] = '작업 시간 초과 (30분)';
            $job_data['updated'] = current_time('mysql');
            set_transient('vt_job_' . $job_id, $job_data, HOUR_IN_SECONDS * 24);
            delete_transient('vt_current_job');
            // 실패 훅 트리거
            do_action('vt_job_failed', $job_id, $job_data);
        }
    }

    /**
     * 작업 완료 후 파일 목록 갱신 (훅에서 호출)
     *
     * @param string $job_id
     * @param array  $job_data
     */
    public function on_job_completed($job_id, $job_data) {
        // 예: 로그 기록, 이메일 알림 등
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[Vinetrimmer] Job completed: ' . $job_id);
        }
    }

    /**
     * 작업 실패 시 처리
     */
    public function on_job_failed($job_id, $job_data) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[Vinetrimmer] Job failed: ' . $job_id . ' - ' . $job_data['message']);
        }
    }
}