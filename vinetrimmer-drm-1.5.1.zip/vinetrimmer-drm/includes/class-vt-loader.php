<?php
/**
 * Vinetrimmer Playready DRM Tool - Loader Class
 * 
 * 이 클래스는 Python 가상환경의 존재 여부를 확인하고,
 * Vinetrimmer CLI를 실행하기 위한 명령어를 구성하며,
 * shell_exec() 호출을 안전하게 래핑합니다.
 *
 * @package Vinetrimmer_DRM
 * @author Bread & Sonion
 * @version 1.5.1
 */

if (!defined('ABSPATH')) {
    exit;
}

class VT_Loader {

    /**
     * Python 실행 파일 경로 (가상환경 우선)
     *
     * @var string
     */
    private $python_path;

    /**
     * runner.py 스크립트 절대 경로
     *
     * @var string
     */
    private $runner_script;

    /**
     * 출력 디렉토리 절대 경로
     *
     * @var string
     */
    private $output_dir;

    /**
     * 로그 디렉토리 절대 경로
     *
     * @var string
     */
    private $log_dir;

    /**
     * Logger 인스턴스 (선택적 의존성 주입)
     *
     * @var VT_Logger|null
     */
    private $logger;

    /**
     * 생성자: 상수로부터 경로 초기화
     *
     * @param VT_Logger|null $logger 통합 로거 (없으면 파일 로깅으로 폴백)
     */
    public function __construct($logger = null) {
        $this->logger        = $logger;
        $this->python_path   = defined('VT_VENV_PYTHON') && file_exists(VT_VENV_PYTHON)
                               ? VT_VENV_PYTHON
                               : 'python3';
        $this->runner_script = defined('VT_PYTHON_SCRIPT') ? VT_PYTHON_SCRIPT : WP_PLUGIN_DIR . '/vinetrimmer-drm/runner.py';
        $this->output_dir    = defined('VT_OUTPUT_DIR') ? VT_OUTPUT_DIR : WP_CONTENT_DIR . '/uploads/vinetrimmer/';
        $this->log_dir       = defined('VT_LOG_DIR') ? VT_LOG_DIR : WP_CONTENT_DIR . '/logs/';
    }

    /**
     * Python 가상환경이 유효한지 검사
     *
     * @return bool
     */
    public function check_environment() {
        // 0. shell_exec / 프로세스 실행 함수 사용 가능 여부 (공유 호스팅 대비)
        if (!$this->is_shell_exec_available()) {
            $this->log_error('shell_exec()가 서버에서 비활성화되어 있습니다. VPS 또는 전용 서버를 사용하거나 php.ini의 disable_functions를 확인하세요.');
            return false;
        }

        // 1. Python 실행 파일 존재 확인
        if (!file_exists($this->python_path) && !$this->command_exists('python3')) {
            $this->log_error('Python 실행 파일을 찾을 수 없습니다. 가상환경을 설치하거나 시스템 Python을 확인하세요.');
            return false;
        }

        // 2. runner.py 존재 확인
        if (!file_exists($this->runner_script)) {
            $this->log_error('runner.py 파일이 없습니다: ' . $this->runner_script);
            return false;
        }

        // 3. 출력 디렉토리 생성 가능 여부
        if (!is_dir($this->output_dir) && !mkdir($this->output_dir, 0755, true)) {
            $this->log_error('출력 디렉토리를 생성할 수 없습니다: ' . $this->output_dir);
            return false;
        }

        // 4. 로그 디렉토리 생성 가능 여부
        if (!is_dir($this->log_dir) && !mkdir($this->log_dir, 0755, true)) {
            $this->log_error('로그 디렉토리를 생성할 수 없습니다: ' . $this->log_dir);
            return false;
        }

        // 5. Vinetrimmer CLI가 설치되었는지 확인 (선택적)
        //    실제 실행은 runner.py에서 하지만, 여기서도 사전 체크 가능
        $vinetrimmer_check = $this->command_exists('vinetrimmer');
        if (!$vinetrimmer_check) {
            // 경고만 기록하고 계속 진행 (실제 실패는 runner.py 실행 시점에서 감지)
            $this->log_warning('Vinetrimmer 명령어가 PATH에 없습니다. poetry 설치 및 가상환경 활성화를 확인하세요.');
        }

        return true;
    }

    /**
     * shell_exec() 및 프로세스 실행 함수의 사용 가능 여부 확인
     *
     * @return bool
     */
    private function is_shell_exec_available() {
        if (!function_exists('shell_exec')) {
            return false;
        }
        $disabled = explode(',', (string) ini_get('disable_functions'));
        $disabled = array_map('trim', $disabled);
        return !in_array('shell_exec', $disabled, true);
    }

    /**
     * Vinetrimmer 실행 명령어 생성 및 실행
     *
     * @param string $service  스트리밍 서비스 식별자
     * @param string $url      콘텐츠 URL
     * @param string $quality  화질 (best, 1080p 등)
     * @param string $sub_lang 자막 언어 코드 (기본 ko)
     * @param string $sub_mode 자막 처리 방식 (mux | burn | none)
     * @param string $config   설정 파일 경로 (선택)
     * @return string          실행 결과 (표준 출력 + 표준 오류)
     */
    public function run($service, $url, $quality, $sub_lang = 'ko', $sub_mode = 'mux', $config = '') {
        // 환경 검사
        if (!$this->check_environment()) {
            return '❌ 환경 검사 실패. 로그를 확인하세요.';
        }

        // 입력값 검증 (추가 방어)
        $service  = $this->sanitize_service($service);
        $url      = $this->sanitize_url($url);
        $quality  = $this->sanitize_quality($quality);
        $sub_lang = $this->sanitize_sub_lang($sub_lang);
        $sub_mode = $this->sanitize_sub_mode($sub_mode);
        $config   = $config ? $this->sanitize_path($config) : '';

        // 기본 설정 파일 경로
        if (empty($config) && defined('VT_PLUGIN_DIR')) {
            $config = VT_PLUGIN_DIR . 'config.json';
        }

        // 명령어 구성
        // 주의: python 경로에 공백이 포함될 수 있으므로 escapeshellcmd 가 아닌
        //       escapeshellarg 로 개별 인자를 안전하게 이스케이프한다.
        $python = escapeshellarg($this->python_path);
        $script = escapeshellarg($this->runner_script);
        $cmd = $python . ' ' . $script
             . ' --service ' . escapeshellarg($service)
             . ' --url ' . escapeshellarg($url)
             . ' --quality ' . escapeshellarg($quality)
             . ' --output ' . escapeshellarg($this->output_dir)
             . ' --sub-lang ' . escapeshellarg($sub_lang)
             . ' --sub-mode ' . escapeshellarg($sub_mode);

        if (!empty($config) && file_exists($config)) {
            $cmd .= ' --config ' . escapeshellarg($config);
        }

        // 디버그 로그
        $this->log_message('실행 명령어: ' . $cmd);

        // 실행 (stderr 포함)
        $output = shell_exec($cmd . ' 2>&1');

        // 결과 로그 (null 방어)
        $log_excerpt = is_string($output) ? substr($output, 0, 500) : '(출력 없음)';
        $this->log_message('실행 결과: ' . $log_excerpt);

        return $output ?: '⚠️ 실행이 완료되었지만 출력이 없습니다. (서버 오류일 수 있음)';
    }

    /**
     * 외부 명령어 존재 여부 확인 (which)
     *
     * @param string $command
     * @return bool
     */
    private function command_exists($command) {
        $which = shell_exec('which ' . escapeshellarg($command) . ' 2>/dev/null');
        return !empty(trim($which));
    }

    /**
     * 서비스 식별자 정리 (허용 목록)
     *
     * @param string $service
     * @return string
     */
    private function sanitize_service($service) {
        $allowed = ['disney', 'amzn', 'apple', 'nowtv', 'hulu', 'itunes', 'canal', 'paramount', 'max', 'netflix',
                    'tving', 'wavve', 'watcha', 'coupang'];
        $service = strtolower(trim($service));
        return in_array($service, $allowed) ? $service : 'disney';
    }

    /**
     * URL 정리 (esc_url_raw 사용)
     *
     * @param string $url
     * @return string
     */
    private function sanitize_url($url) {
        return esc_url_raw(trim($url));
    }

    /**
     * 품질 정리 (허용 목록)
     *
     * @param string $quality
     * @return string
     */
    private function sanitize_quality($quality) {
        $allowed = ['best', '2160p', '1080p', '720p', '480p'];
        $quality = strtolower(trim($quality));
        return in_array($quality, $allowed) ? $quality : 'best';
    }

    /**
     * 자막 언어 코드 정리
     *
     * 허용 형식: 소문자 알파벳 2~3자리 언어 코드, 쉼표로 다중 지정 가능(예: ko, ko,en),
     * 특수값 'all'. 그 외 값은 안전하게 기본값 'ko' 로 강제한다.
     *
     * @param string $lang
     * @return string
     */
    private function sanitize_sub_lang($lang) {
        $lang = strtolower(trim((string) $lang));
        if ($lang === '' ) {
            return 'ko';
        }
        if ($lang === 'all') {
            return 'all';
        }
        // 쉼표 구분 언어 코드만 허용 (a-z, 2~3자, 최대 5개)
        $parts = array_filter(array_map('trim', explode(',', $lang)));
        $valid = array();
        foreach ($parts as $part) {
            if (preg_match('/^[a-z]{2,3}$/', $part)) {
                $valid[] = $part;
            }
            if (count($valid) >= 5) {
                break;
            }
        }
        return !empty($valid) ? implode(',', $valid) : 'ko';
    }

    /**
     * 자막 처리 모드 정리 (허용 목록)
     *
     * @param string $mode
     * @return string
     */
    private function sanitize_sub_mode($mode) {
        $allowed = ['mux', 'burn', 'none'];
        $mode = strtolower(trim((string) $mode));
        return in_array($mode, $allowed, true) ? $mode : 'mux';
    }

    /**
     * 경로 정리 (디렉토리 트래버설 방지)
     *
     * @param string $path
     * @return string
     */
    private function sanitize_path($path) {
        // 실제 파일 존재 여부와 안전한 경로만 허용
        $path = realpath(trim($path));
        if ($path === false || !file_exists($path)) {
            return '';
        }
        // 플러그인 디렉토리 내부에 있는지 확인 (추가 보안)
        if (defined('VT_PLUGIN_DIR') && strpos($path, VT_PLUGIN_DIR) !== 0) {
            $this->log_error('보안 경고: 설정 파일이 플러그인 디렉토리 외부에 있습니다: ' . $path);
            return '';
        }
        return $path;
    }

    /**
     * 로그 메시지 기록
     *
     * VT_Logger 가 주입되었으면 통합 로거로, 아니면 파일에 직접 기록한다.
     *
     * @param string $message
     * @param string $level   INFO | WARNING | ERROR
     */
    private function log_message($message, $level = 'INFO') {
        // 통합 로거가 있으면 우선 사용
        if ($this->logger instanceof VT_Logger) {
            switch (strtoupper($level)) {
                case 'ERROR':
                    $this->logger->error($message);
                    return;
                case 'WARNING':
                    $this->logger->warning($message);
                    return;
                default:
                    $this->logger->info($message);
                    return;
            }
        }

        // 폴백: 파일에 직접 기록
        $log_file = $this->log_dir . 'vinetrimmer.log';
        $timestamp = current_time('mysql');
        $entry = "[$timestamp] [$level] $message\n";
        @file_put_contents($log_file, $entry, FILE_APPEND | LOCK_EX);
    }

    private function log_error($message) {
        $this->log_message($message, 'ERROR');
    }

    private function log_warning($message) {
        $this->log_message($message, 'WARNING');
    }

    /**
     * 출력 디렉토리 경로 반환 (외부 접근용)
     *
     * @return string
     */
    public function get_output_dir() {
        return $this->output_dir;
    }

    /**
     * Python 경로 반환
     *
     * @return string
     */
    public function get_python_path() {
        return $this->python_path;
    }
}