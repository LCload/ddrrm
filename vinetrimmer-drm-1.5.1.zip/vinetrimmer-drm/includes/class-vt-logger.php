<?php
/**
 * Vinetrimmer Playready DRM Tool - Logger Class
 * 
 * 이 클래스는 통합 로깅 시스템을 제공합니다:
 * - 파일 기반 로깅 (일별 로테이션)
 * - WordPress 디버그 로그 연동 (error_log)
 * - 로그 레벨 필터링 (DEBUG, INFO, WARNING, ERROR, FATAL)
 * - 로그 파일 크기 제한 및 자동 정리
 * - 콘솔 출력 (선택적)
 *
 * @package Vinetrimmer_DRM
 * @author Bread & Sonion
 * @version 1.5.1
 */

if (!defined('ABSPATH')) {
    exit;
}

class VT_Logger {

    /**
     * 로그 레벨 상수
     */
    const DEBUG   = 0;
    const INFO    = 1;
    const WARNING = 2;
    const ERROR   = 3;
    const FATAL   = 4;

    /**
     * 현재 설정된 로그 레벨 (이 레벨 이상만 기록)
     *
     * @var int
     */
    private $log_level = self::INFO;

    /**
     * 로그 파일 절대 경로
     *
     * @var string
     */
    private $log_file;

    /**
     * 최대 로그 파일 크기 (바이트) - 10MB
     */
    const MAX_LOG_SIZE = 10485760;

    /**
     * 보관할 로그 파일 개수
     */
    const MAX_BACKUP_FILES = 5;

    /**
     * 생성자: 로그 디렉토리 및 파일 경로 초기화
     */
    public function __construct() {
        $log_dir = defined('VT_LOG_DIR') ? VT_LOG_DIR : WP_CONTENT_DIR . '/logs/';
        if (!is_dir($log_dir)) {
            mkdir($log_dir, 0755, true);
        }
        $this->log_file = $log_dir . 'vinetrimmer.log';

        // 설정에서 로그 레벨 읽기 (선택)
        $this->log_level = defined('VT_LOG_LEVEL') ? constant('VT_LOG_LEVEL') : self::INFO;

        // WordPress 디버그 모드와 연동
        if (defined('WP_DEBUG') && WP_DEBUG === true) {
            $this->log_level = min($this->log_level, self::DEBUG);
        }

        // 생성 시 로그 파일 로테이션 체크
        $this->rotate_log_file();
    }

    /**
     * 로그 파일 로테이션 (크기 초과 시 백업)
     */
    private function rotate_log_file() {
        if (!file_exists($this->log_file)) {
            return;
        }
        if (filesize($this->log_file) < self::MAX_LOG_SIZE) {
            return;
        }

        // 백업 파일 생성
        for ($i = self::MAX_BACKUP_FILES - 1; $i >= 0; $i--) {
            $backup = $this->log_file . '.' . ($i + 1);
            $source = $i === 0 ? $this->log_file : $this->log_file . '.' . $i;
            if (file_exists($source)) {
                if ($i === self::MAX_BACKUP_FILES - 1) {
                    @unlink($source);
                } else {
                    @rename($source, $backup);
                }
            }
        }
        // 현재 로그 파일 초기화
        @unlink($this->log_file);
    }

    /**
     * 로그 메시지 기록 (메인 엔트리)
     *
     * @param string $message
     * @param int    $level   (self::DEBUG, INFO, WARNING, ERROR, FATAL)
     * @param array  $context 추가 컨텍스트 데이터 (배열, 객체 등)
     */
    public function log($message, $level = self::INFO, $context = array()) {
        if ($level < $this->log_level) {
            return; // 설정된 레벨보다 낮으면 무시
        }

        $level_name = $this->get_level_name($level);
        $timestamp = current_time('mysql');
        $pid = getmypid() ?: 'unknown';

        // 컨텍스트를 JSON으로 인코딩 (배열/객체 처리)
        $context_str = '';
        if (!empty($context)) {
            $context_str = ' ' . json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }

        $log_entry = sprintf(
            "[%s] [%s] [PID:%s] %s%s\n",
            $timestamp,
            $level_name,
            $pid,
            $message,
            $context_str
        );

        // 파일에 기록
        @file_put_contents($this->log_file, $log_entry, FILE_APPEND | LOCK_EX);

        // WordPress 디버그 로그에도 기록 (WP_DEBUG_LOG 활성화 시)
        if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG === true) {
            error_log('[Vinetrimmer] ' . trim($log_entry));
        }

        // 치명적 오류는 별도로 이메일 알림 (선택)
        if ($level === self::FATAL && defined('VT_ALERT_EMAIL') && !empty(VT_ALERT_EMAIL)) {
            $this->send_alert_email($message, $context);
        }
    }

    /**
     * 편의 메서드: DEBUG 레벨 로그
     */
    public function debug($message, $context = array()) {
        $this->log($message, self::DEBUG, $context);
    }

    /**
     * 편의 메서드: INFO 레벨 로그
     */
    public function info($message, $context = array()) {
        $this->log($message, self::INFO, $context);
    }

    /**
     * 편의 메서드: WARNING 레벨 로그
     */
    public function warning($message, $context = array()) {
        $this->log($message, self::WARNING, $context);
    }

    /**
     * 편의 메서드: ERROR 레벨 로그
     */
    public function error($message, $context = array()) {
        $this->log($message, self::ERROR, $context);
    }

    /**
     * 편의 메서드: FATAL 레벨 로그
     */
    public function fatal($message, $context = array()) {
        $this->log($message, self::FATAL, $context);
    }

    /**
     * 예외를 로그로 기록
     *
     * @param Exception $e
     * @param string    $prefix
     */
    public function log_exception($e, $prefix = '') {
        $message = $prefix . ' ' . get_class($e) . ': ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine();
        $context = array(
            'trace' => $e->getTraceAsString(),
            'code'  => $e->getCode()
        );
        $this->error($message, $context);
    }

    /**
     * 로그 레벨을 문자열로 변환
     *
     * @param int $level
     * @return string
     */
    private function get_level_name($level) {
        $map = array(
            self::DEBUG   => 'DEBUG',
            self::INFO    => 'INFO',
            self::WARNING => 'WARNING',
            self::ERROR   => 'ERROR',
            self::FATAL   => 'FATAL'
        );
        return isset($map[$level]) ? $map[$level] : 'UNKNOWN';
    }

    /**
     * 이메일 알림 전송 (FATAL 레벨)
     *
     * @param string $message
     * @param array  $context
     */
    private function send_alert_email($message, $context = array()) {
        $to = defined('VT_ALERT_EMAIL') ? VT_ALERT_EMAIL : get_option('admin_email');
        $subject = '[Vinetrimmer] 치명적 오류 발생';
        $body = "시간: " . current_time('mysql') . "\n";
        $body .= "메시지: " . $message . "\n";
        if (!empty($context)) {
            $body .= "컨텍스트: " . print_r($context, true) . "\n";
        }
        $body .= "서버: " . $_SERVER['SERVER_NAME'] . "\n";
        wp_mail($to, $subject, $body, array('Content-Type: text/plain; charset=UTF-8'));
    }

    /**
     * 로그 파일 읽기 (최신 N줄)
     *
     * @param int $lines 반환할 줄 수
     * @return string
     */
    public function tail($lines = 50) {
        if (!file_exists($this->log_file)) {
            return "로그 파일이 없습니다.";
        }
        $content = file_get_contents($this->log_file);
        if ($content === false) {
            return "로그 파일을 읽을 수 없습니다.";
        }
        $array = explode("\n", $content);
        $array = array_filter($array);
        $total = count($array);
        $start = max(0, $total - $lines);
        $result = array_slice($array, $start);
        return implode("\n", $result);
    }

    /**
     * 로그 파일 크기 반환 (사람이 읽기 쉬운 형식)
     *
     * @return string
     */
    public function get_log_size() {
        if (!file_exists($this->log_file)) {
            return '0 B';
        }
        return size_format(filesize($this->log_file), 2);
    }

    /**
     * 로그 파일 삭제 (초기화)
     *
     * @return bool
     */
    public function clear_log() {
        if (file_exists($this->log_file)) {
            return @unlink($this->log_file);
        }
        return true;
    }

    /**
     * 로그 레벨 동적 변경
     *
     * @param int $level
     */
    public function set_level($level) {
        if (in_array($level, array(self::DEBUG, self::INFO, self::WARNING, self::ERROR, self::FATAL))) {
            $this->log_level = $level;
        }
    }

    /**
     * 현재 로그 레벨 반환
     *
     * @return int
     */
    public function get_level() {
        return $this->log_level;
    }

    /**
     * 로그 파일 경로 반환
     *
     * @return string
     */
    public function get_log_file_path() {
        return $this->log_file;
    }
}