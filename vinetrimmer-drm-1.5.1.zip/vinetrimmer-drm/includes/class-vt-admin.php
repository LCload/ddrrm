<?php
/**
 * Vinetrimmer Playready DRM Tool - Admin Class
 * 
 * 이 클래스는 WordPress 관리자 대시보드에 메뉴를 추가하고,
 * 설정 페이지를 렌더링하며, 사용자 입력을 처리하고,
 * 실행 결과를 표시하는 모든 관리자 기능을 제공합니다.
 *
 * @package Vinetrimmer_DRM
 * @author Bread & Sonion
 * @version 1.5.1
 */

if (!defined('ABSPATH')) {
    exit;
}

class VT_Admin {

    /**
     * 플러그인 슬러그 (메뉴 식별자)
     *
     * @var string
     */
    private $slug = 'vinetrimmer-drm';

    /**
     * Loader 인스턴스 (실행 엔진)
     *
     * @var VT_Loader
     */
    private $loader;

    /**
     * File Manager 인스턴스 (파일 목록/삭제/임포트)
     *
     * @var VT_File_Manager|null
     */
    private $file_manager;

    /**
     * 생성자: Loader / File Manager 인스턴스 주입 및 훅 등록
     *
     * @param VT_Loader           $loader
     * @param VT_File_Manager|null $file_manager
     */
    public function __construct(VT_Loader $loader, $file_manager = null) {
        $this->loader       = $loader;
        $this->file_manager = $file_manager;
        $this->init_hooks();
    }

    /**
     * WordPress 훅 등록
     */
    private function init_hooks() {
        add_action('admin_menu', array($this, 'register_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('admin_post_vt_settings_save', array($this, 'save_settings'));
        add_action('admin_post_vt_cookie_save', array($this, 'save_cookie'));   // v1.4.0: 쿠키 업로드/붙여넣기
        add_action('admin_post_vt_cookie_delete', array($this, 'delete_cookie')); // v1.4.0: 쿠키 삭제
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_notices', array($this, 'display_notices'));
    }

    /**
     * 관리자 메뉴 등록
     */
    public function register_menu() {
        add_menu_page(
            'Vinetrimmer DRM',                     // 페이지 타이틀
            'Vinetrimmer',                         // 메뉴 이름
            'manage_options',                      // 권한
            $this->slug,                           // 슬러그
            array($this, 'render_main_page'),      // 콜백
            'dashicons-download',                  // 아이콘
            30                                     // 위치
        );

        add_submenu_page(
            $this->slug,
            '설정',
            '설정',
            'manage_options',
            $this->slug . '-settings',
            array($this, 'render_settings_page')
        );
    }

    /**
     * 메인 페이지 렌더링 (실행 인터페이스)
     *
     * v1.2.0: SaaS급 카드 기반 레이아웃으로 재설계.
     */
    public function render_main_page() {
        // POST 처리 (실행 버튼) — 결과는 버퍼에 담아 카드 안에서 표시
        $run_result_html = '';
        if (isset($_POST['vt_run']) && check_admin_referer('vt_run_action', 'vt_nonce')) {
            ob_start();
            $this->handle_run_request();
            $run_result_html = ob_get_clean();
        }

        $file_count = 0;
        if ($this->file_manager instanceof VT_File_Manager) {
            $file_count = count($this->file_manager->get_files('date', 'desc'));
        }
        ?>
        <div class="wrap vt-wrap">

            <!-- ============ App Bar (헤더) ============ -->
            <header class="vt-appbar">
                <div class="vt-appbar__brand">
                    <span class="vt-appbar__logo" aria-hidden="true">
                        <span class="dashicons dashicons-download"></span>
                    </span>
                    <div class="vt-appbar__titles">
                        <h1 class="vt-appbar__title">Vinetrimmer <span class="vt-appbar__accent">Playready</span></h1>
                        <p class="vt-appbar__subtitle">Playready · Widevine DRM 다운로드 &amp; 해독 콘솔</p>
                    </div>
                </div>
                <div class="vt-appbar__meta">
                    <span class="vt-badge vt-badge--version">v<?php echo esc_html(VT_VERSION); ?></span>
                    <a class="vt-badge vt-badge--ghost" href="<?php echo esc_url(admin_url('admin.php?page=' . $this->slug . '-settings')); ?>">
                        <span class="dashicons dashicons-admin-generic"></span> 설정
                    </a>
                </div>
            </header>

            <!-- ============ KPI 통계 카드 ============ -->
            <section class="vt-stats" aria-label="현황 요약">
                <div class="vt-stat-card">
                    <div class="vt-stat-card__icon vt-stat-card__icon--blue"><span class="dashicons dashicons-media-video"></span></div>
                    <div class="vt-stat-card__body">
                        <span class="vt-stat-card__value"><?php echo esc_html(number_format_i18n($file_count)); ?></span>
                        <span class="vt-stat-card__label">저장된 파일</span>
                    </div>
                </div>
                <div class="vt-stat-card">
                    <div class="vt-stat-card__icon vt-stat-card__icon--green"><span class="dashicons dashicons-translation"></span></div>
                    <div class="vt-stat-card__body">
                        <span class="vt-stat-card__value">한국어</span>
                        <span class="vt-stat-card__label">기본 자막 언어</span>
                    </div>
                </div>
                <div class="vt-stat-card">
                    <div class="vt-stat-card__icon vt-stat-card__icon--purple"><span class="dashicons dashicons-shield-alt"></span></div>
                    <div class="vt-stat-card__body">
                        <span class="vt-stat-card__value">10개</span>
                        <span class="vt-stat-card__label">지원 서비스</span>
                    </div>
                </div>
                <div class="vt-stat-card">
                    <div class="vt-stat-card__icon vt-stat-card__icon--amber"><span class="dashicons dashicons-cloud"></span></div>
                    <div class="vt-stat-card__body">
                        <span class="vt-stat-card__value" id="vt-engine-state">준비됨</span>
                        <span class="vt-stat-card__label">실행 엔진</span>
                    </div>
                </div>
            </section>

            <?php
            // 동기 실행 결과(있다면) 표시
            if (!empty($run_result_html)) {
                echo '<div class="vt-run-result">' . $run_result_html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
            }
            ?>

            <!-- ============ 메인 그리드: 실행 폼 + 파일 목록 ============ -->
            <div class="vt-grid">
                <div class="vt-col vt-col--main">
                    <?php $this->render_run_form(); ?>
                    <?php $this->render_cookie_card(); // v1.4.0: 로그인 쿠키 업로드/붙여넣기 ?>
                </div>
                <div class="vt-col vt-col--side">
                    <?php $this->render_file_list(); ?>
                </div>
            </div>

            <footer class="vt-footer">
                <span>🍞 Vinetrimmer Playready DRM Tool · v<?php echo esc_html(VT_VERSION); ?></span>
                <span class="vt-footer__dim">본 도구는 교육/연구 목적의 DRM 상호운용성 검증용입니다. 적법한 권한이 있는 콘텐츠에만 사용하세요.</span>
            </footer>
        </div>
        <?php
    }

    /**
     * 실행 폼 렌더링 (SaaS 카드 스타일)
     */
    private function render_run_form() {
        // 기본값 (옵션에서 로드)
        $default_service  = get_option('vt_service_default', 'disney');
        $default_quality  = get_option('vt_quality_default', 'best');
        $default_sub_lang = get_option('vt_sub_lang_default', 'ko');
        $default_sub_mode = get_option('vt_sub_mode_default', 'mux');
        ?>
        <section class="vt-card vt-card--form" aria-labelledby="vt-form-title">
            <div class="vt-card__header">
                <h2 id="vt-form-title" class="vt-card__title">
                    <span class="dashicons dashicons-controls-play"></span> 새 다운로드 작업
                </h2>
                <p class="vt-card__desc">서비스와 콘텐츠 URL을 입력하면 DRM을 해독하고 한국어 자막이 포함된 영상을 생성합니다.</p>
            </div>

            <form id="vt-run-form" method="post" action="" class="vt-form">
                <?php wp_nonce_field('vt_run_action', 'vt_nonce'); ?>

                <div class="vt-field">
                    <label class="vt-label" for="vt_service">
                        <span class="dashicons dashicons-video-alt3"></span> 스트리밍 서비스
                    </label>
                    <select name="vt_service" id="vt_service" class="vt-input vt-select">
                        <option value="netflix" <?php selected($default_service, 'netflix'); ?>>Netflix</option>
                        <option value="disney" <?php selected($default_service, 'disney'); ?>>Disney+</option>
                        <option value="amzn" <?php selected($default_service, 'amzn'); ?>>Amazon Prime Video</option>
                        <option value="apple" <?php selected($default_service, 'apple'); ?>>Apple TV+</option>
                        <option value="nowtv" <?php selected($default_service, 'nowtv'); ?>>NOW TV</option>
                        <option value="hulu" <?php selected($default_service, 'hulu'); ?>>Hulu</option>
                        <option value="itunes" <?php selected($default_service, 'itunes'); ?>>iTunes</option>
                        <option value="canal" <?php selected($default_service, 'canal'); ?>>Canal+</option>
                        <option value="paramount" <?php selected($default_service, 'paramount'); ?>>Paramount+</option>
                        <option value="max" <?php selected($default_service, 'max'); ?>>Max (HBO)</option>
                        <optgroup label="국내 OTT (v1.5.0)">
                            <option value="tving" <?php selected($default_service, 'tving'); ?>>TVING (티빙)</option>
                            <option value="wavve" <?php selected($default_service, 'wavve'); ?>>WAVVE (웨이브)</option>
                            <option value="watcha" <?php selected($default_service, 'watcha'); ?>>WATCHA (왓챠)</option>
                            <option value="coupang" <?php selected($default_service, 'coupang'); ?>>Coupang Play (쿠팡플레이)</option>
                        </optgroup>
                    </select>
                    <p class="vt-help">콘텐츠를 제공하는 스트리밍 서비스를 선택하세요.</p>
                </div>

                <div class="vt-field">
                    <label class="vt-label" for="vt_url">
                        <span class="dashicons dashicons-admin-links"></span> 콘텐츠 URL
                    </label>
                    <input type="url" name="vt_url" id="vt_url" class="vt-input"
                           placeholder="https://www.disneyplus.com/ko-kr/video/..." required>
                    <p class="vt-help">재생 페이지의 전체 URL을 입력하세요.</p>
                </div>

                <div class="vt-field-row">
                    <div class="vt-field">
                        <label class="vt-label" for="vt_quality">
                            <span class="dashicons dashicons-format-video"></span> 화질
                        </label>
                        <select name="vt_quality" id="vt_quality" class="vt-input vt-select">
                            <option value="best" <?php selected($default_quality, 'best'); ?>>Best Available</option>
                            <option value="2160p" <?php selected($default_quality, '2160p'); ?>>4K (2160p)</option>
                            <option value="1080p" <?php selected($default_quality, '1080p'); ?>>1080p</option>
                            <option value="720p" <?php selected($default_quality, '720p'); ?>>720p</option>
                            <option value="480p" <?php selected($default_quality, '480p'); ?>>480p</option>
                        </select>
                        <p class="vt-help">원하는 해상도(콘텐츠에 따라 미지원 가능).</p>
                    </div>

                    <div class="vt-field">
                        <label class="vt-label" for="vt_sub_lang">
                            <span class="dashicons dashicons-translation"></span> 자막 언어
                        </label>
                        <select name="vt_sub_lang" id="vt_sub_lang" class="vt-input vt-select">
                            <option value="ko" <?php selected($default_sub_lang, 'ko'); ?>>한국어 (ko) — 권장</option>
                            <option value="ko,en" <?php selected($default_sub_lang, 'ko,en'); ?>>한국어 + 영어 (ko,en)</option>
                            <option value="en" <?php selected($default_sub_lang, 'en'); ?>>영어 (en)</option>
                            <option value="ja" <?php selected($default_sub_lang, 'ja'); ?>>일본어 (ja)</option>
                            <option value="zh" <?php selected($default_sub_lang, 'zh'); ?>>중국어 (zh)</option>
                            <option value="all" <?php selected($default_sub_lang, 'all'); ?>>모든 언어 (all)</option>
                        </select>
                        <p class="vt-help">영상에 포함/표시될 자막 언어입니다. 기본값은 <strong>한국어</strong>.</p>
                    </div>
                </div>

                <div class="vt-field">
                    <label class="vt-label"><span class="dashicons dashicons-editor-textcolor"></span> 자막 처리 방식</label>
                    <div class="vt-segmented" role="radiogroup" aria-label="자막 처리 방식">
                        <label class="vt-seg">
                            <input type="radio" name="vt_sub_mode" value="mux" <?php checked($default_sub_mode, 'mux'); ?>>
                            <span class="vt-seg__box">
                                <span class="vt-seg__title">먹싱 (권장)</span>
                                <span class="vt-seg__desc">별도 자막 트랙 · 한국어 기본 표시</span>
                            </span>
                        </label>
                        <label class="vt-seg">
                            <input type="radio" name="vt_sub_mode" value="burn" <?php checked($default_sub_mode, 'burn'); ?>>
                            <span class="vt-seg__box">
                                <span class="vt-seg__title">하드섭</span>
                                <span class="vt-seg__desc">영상에 자막을 직접 굽기</span>
                            </span>
                        </label>
                        <label class="vt-seg">
                            <input type="radio" name="vt_sub_mode" value="none" <?php checked($default_sub_mode, 'none'); ?>>
                            <span class="vt-seg__box">
                                <span class="vt-seg__title">자막 없음</span>
                                <span class="vt-seg__desc">자막을 다운로드하지 않음</span>
                            </span>
                        </label>
                    </div>
                </div>

                <div class="vt-form__actions">
                    <button type="submit" name="vt_run" id="vt_run" class="vt-btn vt-btn--primary">
                        <span class="dashicons dashicons-download"></span> DRM 해독 &amp; 다운로드 실행
                    </button>
                </div>
            </form>

            <!-- 진행률 표시줄 (AJAX용) -->
            <div class="vt-progress-wrapper" aria-live="polite">
                <div class="vt-progress-head">
                    <span class="vt-progress-status">준비 중...</span>
                    <span class="vt-progress-pct">0%</span>
                </div>
                <div class="vt-progress-bar">
                    <div class="vt-progress-fill" style="width:0%;"></div>
                </div>
            </div>
        </section>
        <?php
    }

    /**
     * 파일 목록 렌더링
     */
    private function render_file_list() {
        // File Manager 가 있으면 이를 통해 정렬된 파일 목록을 얻는다.
        if ($this->file_manager instanceof VT_File_Manager) {
            $files = $this->file_manager->get_files('date', 'desc');
        } else {
            // 폴백: Loader 의 출력 디렉토리를 직접 스캔
            $output_dir = $this->loader->get_output_dir();
            $glob = glob($output_dir . '*.{mp4,mkv,webm,ts,m4v}', GLOB_BRACE);
            $files = array();
            if (!empty($glob)) {
                foreach ($glob as $file) {
                    if (!is_file($file)) {
                        continue;
                    }
                    $basename = basename($file);
                    $files[] = array(
                        'name'           => $basename,
                        'url'            => content_url('uploads/vinetrimmer/' . $basename),
                        'size_human'     => size_format(filesize($file), 2),
                        'modified_human' => date_i18n(get_option('date_format') . ' ' . get_option('time_format'), filemtime($file)),
                    );
                }
            }
        }

        echo '<section class="vt-card vt-card--files" aria-labelledby="vt-files-title">';
        echo '<div class="vt-card__header">';
        echo '<h2 id="vt-files-title" class="vt-card__title"><span class="dashicons dashicons-portfolio"></span> 저장된 파일 <span class="vt-count">' . esc_html(count($files)) . '</span></h2>';
        echo '<p class="vt-card__desc">다운로드가 완료된 미디어 파일 목록입니다.</p>';
        echo '</div>';

        if (!empty($files)) {
            echo '<ul class="vt-file-list">';
            foreach ($files as $file) {
                $basename    = $file['name'];
                $file_url    = isset($file['url']) ? $file['url'] : content_url('uploads/vinetrimmer/' . $basename);
                $size        = isset($file['size_human']) ? $file['size_human'] : '';
                $mtime       = isset($file['modified_human']) ? $file['modified_human'] : '';
                $ext         = strtoupper(pathinfo($basename, PATHINFO_EXTENSION));

                // 삭제 / 임포트 액션 URL (각각 전용 nonce 로 보호)
                $delete_url = wp_nonce_url(
                    admin_url('admin-post.php?action=vt_delete_file&file=' . rawurlencode($basename)),
                    'vt_delete_file',
                    'vt_nonce'
                );
                $import_url = wp_nonce_url(
                    admin_url('admin-post.php?action=vt_import_file&file=' . rawurlencode($basename)),
                    'vt_import_file',
                    'vt_nonce'
                );

                echo '<li class="vt-file">';
                echo '<span class="vt-file__thumb" aria-hidden="true"><span class="dashicons dashicons-media-video"></span><em class="vt-file__ext">' . esc_html($ext) . '</em></span>';
                echo '<div class="vt-file__info">';
                echo '<a class="vt-file__name" href="' . esc_url($file_url) . '" target="_blank" rel="noopener">' . esc_html($basename) . '</a>';
                echo '<span class="vt-file__meta">' . esc_html($size) . ' &middot; ' . esc_html($mtime) . '</span>';
                echo '</div>';
                echo '<div class="vt-file__actions">';
                echo '<a class="vt-btn vt-btn--tiny vt-btn--import" href="' . esc_url($import_url) . '" title="미디어 라이브러리에 추가"><span class="dashicons dashicons-database-import"></span></a>';
                echo '<a class="vt-btn vt-btn--tiny vt-btn--danger" href="' . esc_url($delete_url) . '" title="삭제" onclick="return confirm(\'' . esc_js(__('정말 이 파일을 삭제하시겠습니까?', 'vinetrimmer-drm')) . '\');"><span class="dashicons dashicons-trash"></span></a>';
                echo '</div>';
                echo '</li>';
            }
            echo '</ul>';
        } else {
            echo '<div class="vt-empty">';
            echo '<span class="vt-empty__icon dashicons dashicons-open-folder"></span>';
            echo '<p class="vt-empty__title">아직 다운로드된 파일이 없습니다</p>';
            echo '<p class="vt-empty__desc">왼쪽 폼에서 새 작업을 실행하면 결과 파일이 여기에 표시됩니다.</p>';
            echo '</div>';
        }
        echo '</section>';
    }

    /**
     * 실행 요청 처리
     */
    private function handle_run_request() {
        // 권한 검사
        if (!current_user_can('manage_options')) {
            wp_die('권한이 없습니다.');
        }

        // 입력값 획득 및 정리
        $service  = sanitize_text_field(wp_unslash($_POST['vt_service']));
        $url      = esc_url_raw(wp_unslash($_POST['vt_url']));
        $quality  = sanitize_text_field(wp_unslash($_POST['vt_quality']));
        $sub_lang = isset($_POST['vt_sub_lang']) ? sanitize_text_field(wp_unslash($_POST['vt_sub_lang'])) : 'ko';
        $sub_mode = isset($_POST['vt_sub_mode']) ? sanitize_text_field(wp_unslash($_POST['vt_sub_mode'])) : 'mux';

        // 유효성 검사
        if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
            echo '<div class="notice notice-error"><p>❌ 유효한 URL을 입력하세요.</p></div>';
            return;
        }

        // 실행 (Loader 호출, 자막 언어/모드 포함)
        $result = $this->loader->run($service, $url, $quality, $sub_lang, $sub_mode);

        // 결과 표시
        if ($result) {
            echo '<div class="notice notice-success is-dismissible"><p><strong>✅ 실행 완료</strong></p>';
            echo '<pre style="background:#f1f1f1;padding:12px;max-height:400px;overflow:auto;white-space:pre-wrap;word-wrap:break-word;">';
            echo esc_html($result);
            echo '</pre></div>';
        } else {
            echo '<div class="notice notice-error"><p>❌ 실행 중 오류가 발생했습니다. 로그를 확인하세요.</p></div>';
        }
    }

    /**
     * 설정 페이지 렌더링
     */
    public function render_settings_page() {
        $service  = get_option('vt_service_default', 'disney');
        $quality  = get_option('vt_quality_default', 'best');
        $sub_lang = get_option('vt_sub_lang_default', 'ko');
        $sub_mode = get_option('vt_sub_mode_default', 'mux');
        ?>
        <div class="wrap vt-wrap">
            <header class="vt-appbar">
                <div class="vt-appbar__brand">
                    <span class="vt-appbar__logo" aria-hidden="true"><span class="dashicons dashicons-admin-generic"></span></span>
                    <div class="vt-appbar__titles">
                        <h1 class="vt-appbar__title">설정</h1>
                        <p class="vt-appbar__subtitle">기본 실행 옵션 및 자막 정책을 구성합니다.</p>
                    </div>
                </div>
                <div class="vt-appbar__meta">
                    <a class="vt-badge vt-badge--ghost" href="<?php echo esc_url(admin_url('admin.php?page=' . $this->slug)); ?>">
                        <span class="dashicons dashicons-arrow-left-alt"></span> 콘솔로
                    </a>
                </div>
            </header>

            <form method="post" action="admin-post.php" class="vt-form">
                <input type="hidden" name="action" value="vt_settings_save">
                <?php wp_nonce_field('vt_settings_save', 'vt_settings_nonce'); ?>

                <section class="vt-card">
                    <div class="vt-card__header">
                        <h2 class="vt-card__title"><span class="dashicons dashicons-admin-settings"></span> 기본 실행 옵션</h2>
                        <p class="vt-card__desc">콘솔 페이지를 열 때 미리 선택될 값입니다.</p>
                    </div>

                    <div class="vt-field-row">
                        <div class="vt-field">
                            <label class="vt-label" for="vt_service_default">기본 서비스</label>
                            <select name="vt_service_default" id="vt_service_default" class="vt-input vt-select">
                                <option value="netflix" <?php selected($service, 'netflix'); ?>>Netflix</option>
                                <option value="disney" <?php selected($service, 'disney'); ?>>Disney+</option>
                                <option value="amzn" <?php selected($service, 'amzn'); ?>>Amazon Prime Video</option>
                                <option value="apple" <?php selected($service, 'apple'); ?>>Apple TV+</option>
                                <option value="nowtv" <?php selected($service, 'nowtv'); ?>>NOW TV</option>
                                <option value="hulu" <?php selected($service, 'hulu'); ?>>Hulu</option>
                                <option value="itunes" <?php selected($service, 'itunes'); ?>>iTunes</option>
                                <option value="canal" <?php selected($service, 'canal'); ?>>Canal+</option>
                                <option value="paramount" <?php selected($service, 'paramount'); ?>>Paramount+</option>
                                <option value="max" <?php selected($service, 'max'); ?>>Max (HBO)</option>
                                <optgroup label="국내 OTT (v1.5.0)">
                                    <option value="tving" <?php selected($service, 'tving'); ?>>TVING (티빙)</option>
                                    <option value="wavve" <?php selected($service, 'wavve'); ?>>WAVVE (웨이브)</option>
                                    <option value="watcha" <?php selected($service, 'watcha'); ?>>WATCHA (왓챠)</option>
                                    <option value="coupang" <?php selected($service, 'coupang'); ?>>Coupang Play (쿠팡플레이)</option>
                                </optgroup>
                            </select>
                        </div>
                        <div class="vt-field">
                            <label class="vt-label" for="vt_quality_default">기본 화질</label>
                            <select name="vt_quality_default" id="vt_quality_default" class="vt-input vt-select">
                                <option value="best" <?php selected($quality, 'best'); ?>>Best Available</option>
                                <option value="2160p" <?php selected($quality, '2160p'); ?>>4K (2160p)</option>
                                <option value="1080p" <?php selected($quality, '1080p'); ?>>1080p</option>
                                <option value="720p" <?php selected($quality, '720p'); ?>>720p</option>
                                <option value="480p" <?php selected($quality, '480p'); ?>>480p</option>
                            </select>
                        </div>
                    </div>
                </section>

                <section class="vt-card">
                    <div class="vt-card__header">
                        <h2 class="vt-card__title"><span class="dashicons dashicons-translation"></span> 자막 정책</h2>
                        <p class="vt-card__desc">다운로드되는 영상 자막의 기본 언어와 처리 방식을 지정합니다. 기본값은 <strong>한국어 · 먹싱</strong>입니다.</p>
                    </div>

                    <div class="vt-field-row">
                        <div class="vt-field">
                            <label class="vt-label" for="vt_sub_lang_default">기본 자막 언어</label>
                            <select name="vt_sub_lang_default" id="vt_sub_lang_default" class="vt-input vt-select">
                                <option value="ko" <?php selected($sub_lang, 'ko'); ?>>한국어 (ko) — 권장</option>
                                <option value="ko,en" <?php selected($sub_lang, 'ko,en'); ?>>한국어 + 영어 (ko,en)</option>
                                <option value="en" <?php selected($sub_lang, 'en'); ?>>영어 (en)</option>
                                <option value="ja" <?php selected($sub_lang, 'ja'); ?>>일본어 (ja)</option>
                                <option value="zh" <?php selected($sub_lang, 'zh'); ?>>중국어 (zh)</option>
                                <option value="all" <?php selected($sub_lang, 'all'); ?>>모든 언어 (all)</option>
                            </select>
                            <p class="vt-help">Vinetrimmer CLI의 <code>-sl</code> 옵션으로 전달됩니다.</p>
                        </div>
                        <div class="vt-field">
                            <label class="vt-label" for="vt_sub_mode_default">기본 자막 처리 방식</label>
                            <select name="vt_sub_mode_default" id="vt_sub_mode_default" class="vt-input vt-select">
                                <option value="mux" <?php selected($sub_mode, 'mux'); ?>>먹싱 (권장) — 한국어 기본 표시</option>
                                <option value="burn" <?php selected($sub_mode, 'burn'); ?>>하드섭 — 영상에 굽기</option>
                                <option value="none" <?php selected($sub_mode, 'none'); ?>>자막 없음</option>
                            </select>
                            <p class="vt-help">하드섭은 CLI가 지원할 때만 적용되고, 미지원 시 먹싱으로 안전 폴백됩니다.</p>
                        </div>
                    </div>
                </section>

                <section class="vt-card">
                    <div class="vt-card__header">
                        <h2 class="vt-card__title"><span class="dashicons dashicons-info-outline"></span> 시스템 정보</h2>
                        <p class="vt-card__desc">읽기 전용 · 변경하려면 <code>wp-config.php</code>에서 상수를 재정의하세요.</p>
                    </div>
                    <ul class="vt-kv">
                        <li><span class="vt-kv__k">출력 디렉토리</span><code class="vt-kv__v"><?php echo esc_html($this->loader->get_output_dir()); ?></code></li>
                        <li><span class="vt-kv__k">Python 경로</span><code class="vt-kv__v"><?php echo esc_html($this->loader->get_python_path()); ?></code></li>
                        <li><span class="vt-kv__k">플러그인 버전</span><code class="vt-kv__v">v<?php echo esc_html(VT_VERSION); ?></code></li>
                    </ul>
                </section>

                <div class="vt-form__actions">
                    <button type="submit" class="vt-btn vt-btn--primary"><span class="dashicons dashicons-saved"></span> 설정 저장</button>
                </div>
            </form>
        </div>
        <?php
    }

    /**
     * 설정 저장 처리
     */
    public function save_settings() {
        if (!current_user_can('manage_options')) {
            wp_die('권한이 없습니다.');
        }
        check_admin_referer('vt_settings_save', 'vt_settings_nonce');

        if (isset($_POST['vt_service_default'])) {
            update_option('vt_service_default', sanitize_text_field(wp_unslash($_POST['vt_service_default'])));
        }
        if (isset($_POST['vt_quality_default'])) {
            update_option('vt_quality_default', sanitize_text_field(wp_unslash($_POST['vt_quality_default'])));
        }
        if (isset($_POST['vt_sub_lang_default'])) {
            update_option('vt_sub_lang_default', sanitize_text_field(wp_unslash($_POST['vt_sub_lang_default'])));
        }
        if (isset($_POST['vt_sub_mode_default'])) {
            $mode = sanitize_text_field(wp_unslash($_POST['vt_sub_mode_default']));
            update_option('vt_sub_mode_default', in_array($mode, array('mux', 'burn', 'none'), true) ? $mode : 'mux');
        }

        wp_safe_redirect(add_query_arg(array('page' => $this->slug . '-settings', 'updated' => 'true'), admin_url('admin.php')));
        exit;
    }

    /**
     * 설정 등록 (WordPress Settings API)
     */
    public function register_settings() {
        register_setting('vt_settings_group', 'vt_service_default', 'sanitize_text_field');
        register_setting('vt_settings_group', 'vt_quality_default', 'sanitize_text_field');
        register_setting('vt_settings_group', 'vt_sub_lang_default', 'sanitize_text_field');
        register_setting('vt_settings_group', 'vt_sub_mode_default', 'sanitize_text_field');
    }

    /**
     * 관리자 페이지 에셋 로드
     */
    public function enqueue_assets($hook) {
        if (strpos($hook, $this->slug) === false) {
            return;
        }

        wp_enqueue_style('vt-admin-style', VT_PLUGIN_URL . 'assets/css/admin-style.css', array(), VT_VERSION);
        wp_enqueue_script('vt-admin-script', VT_PLUGIN_URL . 'assets/js/admin-script.js', array('jquery'), VT_VERSION, true);
        wp_localize_script('vt-admin-script', 'vt_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('vt_ajax_nonce'),
            'loading'  => '처리 중...'
        ));
    }

    /**
     * 관리자 알림 표시 (설정 저장 완료 등)
     */
    public function display_notices() {
        // 현재 플러그인 페이지에서만 알림 표시
        $page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
        if (strpos($page, $this->slug) === false) {
            return;
        }

        // 설정 저장 완료
        if (isset($_GET['updated']) && $_GET['updated'] === 'true') {
            echo '<div class="notice notice-success is-dismissible"><p>✅ 설정이 저장되었습니다.</p></div>';
        }

        // 파일 삭제 결과
        if (isset($_GET['deleted'])) {
            $deleted = sanitize_text_field(wp_unslash($_GET['deleted']));
            if ($deleted === 'true') {
                echo '<div class="notice notice-success is-dismissible"><p>🗑️ 파일이 삭제되었습니다.</p></div>';
            } elseif ($deleted === 'notfound') {
                echo '<div class="notice notice-warning is-dismissible"><p>⚠️ 삭제할 파일을 찾을 수 없습니다.</p></div>';
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>❌ 파일 삭제에 실패했습니다.</p></div>';
            }
        }

        // 미디어 라이브러리 임포트 결과
        if (isset($_GET['imported'])) {
            $imported = sanitize_text_field(wp_unslash($_GET['imported']));
            if ($imported === 'true') {
                echo '<div class="notice notice-success is-dismissible"><p>📥 파일이 미디어 라이브러리에 추가되었습니다.</p></div>';
            } elseif ($imported === 'notfound') {
                echo '<div class="notice notice-warning is-dismissible"><p>⚠️ 임포트할 파일을 찾을 수 없습니다.</p></div>';
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>❌ 미디어 라이브러리 임포트에 실패했습니다.</p></div>';
            }
        }

        // v1.4.0: 쿠키 저장 결과
        if (isset($_GET['cookie'])) {
            $cookie = sanitize_text_field(wp_unslash($_GET['cookie']));
            switch ($cookie) {
                case 'saved':
                    echo '<div class="notice notice-success is-dismissible"><p>🍪 쿠키가 저장되었습니다. 이제 ID/비밀번호 없이 로그인 세션을 사용할 수 있습니다.</p></div>';
                    break;
                case 'deleted':
                    echo '<div class="notice notice-success is-dismissible"><p>🗑️ 저장된 쿠키를 삭제했습니다.</p></div>';
                    break;
                case 'empty':
                    echo '<div class="notice notice-error is-dismissible"><p>❌ 쿠키 내용이 비어 있습니다. 파일을 업로드하거나 텍스트를 붙여넣으세요.</p></div>';
                    break;
                case 'invalid':
                    echo '<div class="notice notice-error is-dismissible"><p>❌ 쿠키 형식이 올바르지 않습니다. Netscape/Mozilla 쿠키 형식(탭 구분)이어야 합니다. 크롬 확장 프로그램으로 내보낸 .txt 파일을 사용하세요.</p></div>';
                    break;
                case 'missing_auth':
                    echo '<div class="notice notice-warning is-dismissible"><p>⚠️ 쿠키는 저장되었지만 <code>NetflixId</code> 및 <code>SecureNetflixId</code> 항목이 보이지 않습니다. Netflix에 로그인한 상태에서 쿠키를 다시 추출하세요.</p></div>';
                    break;
                case 'writefail':
                    echo '<div class="notice notice-error is-dismissible"><p>❌ 쿠키 파일 저장에 실패했습니다. 디렉토리 쓰기 권한을 확인하세요.</p></div>';
                    break;
            }
        }
    }

    /* =====================================================================
     * v1.4.0 — 쿠키 업로드 / 붙여넣기 관리
     *
     * vinetrimmer 는 로그인 세션을 아래 경로의 Netscape/Mozilla 쿠키 파일에서
     * 읽습니다 (dl.py::get_cookie_jar -> MozillaCookieJar):
     *
     *     vinetrimmer/cookies/<service.lower()>/<profile>.txt   (기본 profile = 'default')
     *
     * Netflix 의 경우 NetflixId / SecureNetflixId 쿠키만 있으면
     * netflix.py::configure() 가 NetflixIDCookies 인증을 사용하므로
     * ID/비밀번호 없이 동작합니다.
     * ===================================================================== */

    /**
     * 쿠키를 지원하는 서비스 목록 (슬러그 => 표시 이름)
     *
     * @return array
     */
    private function cookie_services() {
        return array(
            'netflix' => 'Netflix',
            'disney'  => 'Disney+',
            'amzn'    => 'Amazon Prime Video',
            'apple'   => 'Apple TV+',
            'nowtv'   => 'NOW TV',
            'hulu'    => 'Hulu',
            'itunes'  => 'iTunes',
            'canal'   => 'Canal+',
            'paramount' => 'Paramount+',
            'max'     => 'Max (HBO)',
            // v1.5.0 국내 OTT (인증/메타데이터까지 지원, DRM 라이선스는 미지원)
            'tving'   => 'TVING (티빙)',
            'wavve'   => 'WAVVE (웨이브)',
            'watcha'  => 'WATCHA (왓챠)',
            'coupang' => 'Coupang Play (쿠팡플레이)',
        );
    }

    /**
     * 특정 서비스의 쿠키 파일 절대 경로를 반환.
     * (profile 은 항상 기본값 'default' — runner.py 가 --profile 을 넘기지 않음)
     *
     * @param string $service
     * @return string
     */
    private function cookie_path($service) {
        $service = strtolower(preg_replace('/[^a-z0-9_\-]/i', '', $service));
        return VT_PLUGIN_DIR . 'vinetrimmer/cookies/' . $service . '/default.txt';
    }

    /**
     * 쿠키 파일 현재 상태 조회.
     *
     * @param string $service
     * @return array {exists:bool, path:string, size:int, mtime:int, has_netflix_auth:bool, line_count:int}
     */
    private function cookie_status($service) {
        $path = $this->cookie_path($service);
        $status = array(
            'exists'           => false,
            'path'             => $path,
            'size'             => 0,
            'mtime'            => 0,
            'has_netflix_auth' => false,
            'line_count'       => 0,
        );
        if (is_file($path)) {
            $status['exists'] = true;
            $status['size']   = filesize($path);
            $status['mtime']  = filemtime($path);
            $content = @file_get_contents($path);
            if ($content !== false) {
                // 주석/빈 줄 제외한 실제 쿠키 라인 수
                $lines = preg_split('/\r\n|\r|\n/', trim($content));
                foreach ($lines as $line) {
                    $line = trim($line);
                    if ($line === '' || strpos($line, '#') === 0) {
                        continue;
                    }
                    $status['line_count']++;
                }
                // Netflix 인증 쿠키 존재 여부
                if (strpos($content, 'NetflixId') !== false && strpos($content, 'SecureNetflixId') !== false) {
                    $status['has_netflix_auth'] = true;
                }
            }
        }
        return $status;
    }

    /**
     * 쿠키 텍스트가 Netscape/Mozilla 형식으로 유효한지 검사.
     * MozillaCookieJar 가 읽을 수 있는 최소 조건: 탭으로 구분된 7개 필드를 가진
     * 데이터 라인이 하나 이상 존재.
     *
     * @param string $content
     * @return bool
     */
    private function is_valid_netscape_cookie($content) {
        $content = str_replace(array("\r\n", "\r"), "\n", $content);
        $lines = explode("\n", $content);
        foreach ($lines as $line) {
            $trimmed = trim($line);
            if ($trimmed === '' || strpos($trimmed, '#') === 0) {
                continue;
            }
            // Netscape 형식: domain \t flag \t path \t secure \t expiry \t name \t value
            $fields = explode("\t", $line);
            if (count($fields) >= 6) {
                return true;
            }
        }
        return false;
    }

    /**
     * 쿠키 관리 카드 렌더링 (메인 콘솔에 표시)
     */
    private function render_cookie_card() {
        $services = $this->cookie_services();
        // 어떤 서비스 상태를 볼지: GET 파라미터 or 기본값 netflix
        $selected = isset($_GET['cookie_service'])
            ? sanitize_text_field(wp_unslash($_GET['cookie_service']))
            : 'netflix';
        if (!isset($services[$selected])) {
            $selected = 'netflix';
        }
        $status = $this->cookie_status($selected);
        ?>
        <section class="vt-card vt-card--cookie" aria-labelledby="vt-cookie-title" id="vt-cookie-section">
            <div class="vt-card__header">
                <h2 id="vt-cookie-title" class="vt-card__title">
                    <span class="dashicons dashicons-privacy"></span> 로그인 쿠키 관리
                </h2>
                <p class="vt-card__desc">
                    스트리밍 사이트에 로그인한 브라우저 쿠키를 업로드하면 <strong>ID/비밀번호 없이</strong> DRM 다운로드가 동작합니다.
                    아래 <em>크롬 확장 프로그램</em>으로 쉽게 추출한 <code>.txt</code> 파일을 그대로 업로드하세요.
                </p>
            </div>

            <!-- 서비스 선택 (상태 확인용) -->
            <form method="get" action="" class="vt-cookie-switch">
                <input type="hidden" name="page" value="<?php echo esc_attr($this->slug); ?>">
                <label class="vt-label" for="vt_cookie_service_view">
                    <span class="dashicons dashicons-video-alt3"></span> 서비스
                </label>
                <select name="cookie_service" id="vt_cookie_service_view" class="vt-input vt-select" onchange="this.form.submit()">
                    <?php foreach ($services as $slug => $name) : ?>
                        <option value="<?php echo esc_attr($slug); ?>" <?php selected($selected, $slug); ?>><?php echo esc_html($name); ?></option>
                    <?php endforeach; ?>
                </select>
            </form>

            <!-- 현재 쿠키 상태 -->
            <div class="vt-cookie-status <?php echo $status['exists'] ? 'vt-cookie-status--ok' : 'vt-cookie-status--none'; ?>">
                <?php if ($status['exists']) : ?>
                    <span class="dashicons dashicons-yes-alt"></span>
                    <div class="vt-cookie-status__body">
                        <strong><?php echo esc_html($services[$selected]); ?> 쿠키 저장됨</strong>
                        <span class="vt-cookie-status__meta">
                            <?php echo esc_html(size_format($status['size'], 1)); ?> ·
                            쿠키 <?php echo esc_html(number_format_i18n($status['line_count'])); ?>개 ·
                            <?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $status['mtime'])); ?>
                        </span>
                        <?php if ($selected === 'netflix') : ?>
                            <?php if ($status['has_netflix_auth']) : ?>
                                <span class="vt-cookie-badge vt-cookie-badge--ok"><span class="dashicons dashicons-shield"></span> NetflixId / SecureNetflixId 확인됨 — ID/PW 불필요</span>
                            <?php else : ?>
                                <span class="vt-cookie-badge vt-cookie-badge--warn"><span class="dashicons dashicons-warning"></span> 인증 쿠키(NetflixId) 미검출 — 로그인 상태에서 다시 추출 필요</span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <a class="vt-btn vt-btn--tiny vt-btn--danger"
                       href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=vt_cookie_delete&cookie_service=' . rawurlencode($selected)), 'vt_cookie_delete', 'vt_cookie_nonce')); ?>"
                       onclick="return confirm('<?php echo esc_js('저장된 쿠키를 삭제할까요?'); ?>');"
                       title="쿠키 삭제">
                        <span class="dashicons dashicons-trash"></span>
                    </a>
                <?php else : ?>
                    <span class="dashicons dashicons-info-outline"></span>
                    <div class="vt-cookie-status__body">
                        <strong><?php echo esc_html($services[$selected]); ?> 쿠키 없음</strong>
                        <span class="vt-cookie-status__meta">아직 쿠키가 업로드되지 않았습니다. 아래에서 파일을 업로드하거나 텍스트를 붙여넣으세요.</span>
                    </div>
                <?php endif; ?>
            </div>

            <!-- 업로드 / 붙여넣기 폼 -->
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data" class="vt-form vt-cookie-form">
                <input type="hidden" name="action" value="vt_cookie_save">
                <?php wp_nonce_field('vt_cookie_save', 'vt_cookie_nonce'); ?>

                <div class="vt-field">
                    <label class="vt-label" for="vt_cookie_service">
                        <span class="dashicons dashicons-video-alt3"></span> 대상 서비스
                    </label>
                    <select name="vt_cookie_service" id="vt_cookie_service" class="vt-input vt-select">
                        <?php foreach ($services as $slug => $name) : ?>
                            <option value="<?php echo esc_attr($slug); ?>" <?php selected($selected, $slug); ?>><?php echo esc_html($name); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="vt-help">쿠키를 저장할 스트리밍 서비스를 선택하세요. (기본: 방금 확인 중인 서비스)</p>
                </div>

                <div class="vt-cookie-tabs" role="tablist">
                    <button type="button" class="vt-cookie-tab is-active" data-cookie-tab="upload">
                        <span class="dashicons dashicons-upload"></span> 파일 업로드
                    </button>
                    <button type="button" class="vt-cookie-tab" data-cookie-tab="paste">
                        <span class="dashicons dashicons-clipboard"></span> 텍스트 붙여넣기
                    </button>
                </div>

                <!-- 파일 업로드 패널 -->
                <div class="vt-cookie-panel" data-cookie-panel="upload">
                    <div class="vt-field">
                        <label class="vt-label" for="vt_cookie_file">
                            <span class="dashicons dashicons-media-text"></span> 쿠키 파일 (.txt)
                        </label>
                        <input type="file" name="vt_cookie_file" id="vt_cookie_file" class="vt-input" accept=".txt,text/plain">
                        <p class="vt-help">크롬 확장 프로그램으로 내보낸 Netscape 형식 <code>.txt</code> 파일을 선택하세요.</p>
                    </div>
                </div>

                <!-- 붙여넣기 패널 -->
                <div class="vt-cookie-panel" data-cookie-panel="paste" hidden>
                    <div class="vt-field">
                        <label class="vt-label" for="vt_cookie_text">
                            <span class="dashicons dashicons-editor-code"></span> 쿠키 텍스트
                        </label>
                        <textarea name="vt_cookie_text" id="vt_cookie_text" class="vt-input vt-textarea" rows="8"
                                  placeholder="# Netscape HTTP Cookie File&#10;.netflix.com&#9;TRUE&#9;/&#9;TRUE&#9;0&#9;NetflixId&#9;v%3D2..."></textarea>
                        <p class="vt-help">쿠키 파일 내용을 그대로 붙여넣으세요. 탭으로 구분된 Netscape/Mozilla 형식이어야 합니다.</p>
                    </div>
                </div>

                <div class="vt-form__actions">
                    <button type="submit" class="vt-btn vt-btn--primary">
                        <span class="dashicons dashicons-saved"></span> 쿠키 저장
                    </button>
                </div>
            </form>

            <details class="vt-cookie-guide">
                <summary><span class="dashicons dashicons-lightbulb"></span> 쿠키를 어떻게 추출하나요? (크롬 확장 프로그램 · 모든 서비스 지원)</summary>
                <ol>
                    <li><strong>크롬 확장 프로그램</strong>(<code>vinetrimmer-cookie-exporter-x.y.z.zip</code>, 플러그인과 <em>별도 배포</em>)을 내려받아 압축을 풉니다.</li>
                    <li>크롬 주소창에 <code>chrome://extensions</code> 입력 → 우측 상단 <strong>개발자 모드</strong> 켜기.</li>
                    <li><strong>압축해제된 확장 프로그램을 로드</strong> 클릭 → 압축 푼 <code>vinetrimmer-cookie-exporter/</code> 폴더 선택.</li>
                    <li>대상 사이트(Netflix · Disney+ · Amazon 등 <strong>어떤 사이트든</strong>)에 <strong>로그인</strong>한 상태에서 확장 아이콘(🍪) 클릭.</li>
                    <li>확장이 현재 사이트를 <strong>자동 감지</strong>해 서비스 이름을 골라줍니다. <strong>💾 .txt 다운로드</strong> → <code>&lt;service&gt;_default.txt</code> 저장, 또는 <strong>📋 클립보드로 복사</strong>.</li>
                    <li>다운로드한 파일을 위 <em>파일 업로드</em>에 넣거나, 복사한 내용을 <em>텍스트 붙여넣기</em> 탭에 붙여넣으면 끝!</li>
                </ol>
                <p class="vt-help" style="margin-top:8px;">
                    이 확장이 만드는 <code>.txt</code>는 표준 Netscape 형식이라 <code>yt-dlp</code>, <code>curl</code> 등 다른 도구에서도 그대로 사용할 수 있습니다.
                </p>
            </details>
        </section>
        <?php
    }

    /**
     * 쿠키 저장 처리 (admin_post_vt_cookie_save)
     */
    public function save_cookie() {
        if (!current_user_can('manage_options')) {
            wp_die('권한이 없습니다.');
        }
        check_admin_referer('vt_cookie_save', 'vt_cookie_nonce');

        $services = $this->cookie_services();
        $service  = isset($_POST['vt_cookie_service'])
            ? sanitize_text_field(wp_unslash($_POST['vt_cookie_service']))
            : 'netflix';
        if (!isset($services[$service])) {
            $service = 'netflix';
        }

        // 1) 콘텐츠 확보: 파일 업로드 우선, 없으면 붙여넣기 텍스트
        $content = '';
        if (!empty($_FILES['vt_cookie_file']['tmp_name']) && is_uploaded_file($_FILES['vt_cookie_file']['tmp_name'])) {
            $raw = file_get_contents($_FILES['vt_cookie_file']['tmp_name']);
            if ($raw !== false) {
                $content = $raw;
            }
        } elseif (!empty($_POST['vt_cookie_text'])) {
            // 붙여넣기: 슬래시 해제만 하고 원본(탭/개행) 보존
            $content = wp_unslash($_POST['vt_cookie_text']);
        }

        $content = trim($content);
        if ($content === '') {
            $this->cookie_redirect($service, 'empty');
            return;
        }

        // 2) 형식 검증 (Netscape/Mozilla)
        if (!$this->is_valid_netscape_cookie($content)) {
            $this->cookie_redirect($service, 'invalid');
            return;
        }

        // 3) Netscape 헤더가 없으면 추가 (MozillaCookieJar 호환성 강화)
        if (strpos($content, '# Netscape HTTP Cookie File') === false
            && strpos($content, '# HTTP Cookie File') === false) {
            $content = "# Netscape HTTP Cookie File\n" . $content;
        }
        // 개행 정규화 (LF)
        $content = str_replace(array("\r\n", "\r"), "\n", $content);
        if (substr($content, -1) !== "\n") {
            $content .= "\n";
        }

        // 4) 디렉토리 생성 및 파일 기록
        $path = $this->cookie_path($service);
        $dir  = dirname($path);
        if (!is_dir($dir)) {
            wp_mkdir_p($dir);
        }
        $written = @file_put_contents($path, $content);
        if ($written === false) {
            $this->cookie_redirect($service, 'writefail');
            return;
        }
        @chmod($path, 0600);

        // 5) Netflix 인증 쿠키 존재 여부에 따라 상태 메시지 분기
        if ($service === 'netflix'
            && (strpos($content, 'NetflixId') === false || strpos($content, 'SecureNetflixId') === false)) {
            $this->cookie_redirect($service, 'missing_auth');
            return;
        }

        $this->cookie_redirect($service, 'saved');
    }

    /**
     * 쿠키 삭제 처리 (admin_post_vt_cookie_delete)
     */
    public function delete_cookie() {
        if (!current_user_can('manage_options')) {
            wp_die('권한이 없습니다.');
        }
        check_admin_referer('vt_cookie_delete', 'vt_cookie_nonce');

        $services = $this->cookie_services();
        $service  = isset($_GET['cookie_service'])
            ? sanitize_text_field(wp_unslash($_GET['cookie_service']))
            : 'netflix';
        if (!isset($services[$service])) {
            $service = 'netflix';
        }

        $path = $this->cookie_path($service);
        if (is_file($path)) {
            @unlink($path);
        }
        $this->cookie_redirect($service, 'deleted');
    }

    /**
     * 쿠키 처리 결과와 함께 콘솔로 리다이렉트.
     *
     * @param string $service
     * @param string $result
     */
    private function cookie_redirect($service, $result) {
        wp_safe_redirect(add_query_arg(
            array(
                'page'           => $this->slug,
                'cookie'         => $result,
                'cookie_service' => $service,
            ),
            admin_url('admin.php')
        ) . '#vt-cookie-section');
        exit;
    }
}