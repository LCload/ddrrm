<?php
/**
 * Vinetrimmer Playready DRM Tool - File Manager Class
 * 
 * 이 클래스는 다운로드된 파일을 관리합니다:
 * - 파일 목록 스캔 및 필터링
 * - 파일 크기, 수정일 등 메타데이터 제공
 * - WordPress 미디어 라이브러리로 자동 임포트
 * - 파일 삭제 및 정리
 * - 다운로드 URL 생성
 *
 * @package Vinetrimmer_DRM
 * @author Bread & Sonion
 * @version 1.5.1
 */

if (!defined('ABSPATH')) {
    exit;
}

class VT_File_Manager {

    /**
     * 출력 디렉토리 절대 경로
     *
     * @var string
     */
    private $output_dir;

    /**
     * 허용되는 파일 확장자 (비디오/컨테이너)
     *
     * @var array
     */
    private $allowed_extensions = array('mp4', 'mkv', 'webm', 'ts', 'm4v');

    /**
     * 생성자: 출력 디렉토리 초기화
     */
    public function __construct() {
        $this->output_dir = defined('VT_OUTPUT_DIR') ? VT_OUTPUT_DIR : WP_CONTENT_DIR . '/uploads/vinetrimmer/';
        // 디렉토리가 없으면 생성
        if (!is_dir($this->output_dir)) {
            mkdir($this->output_dir, 0755, true);
        }
        $this->init_hooks();
    }

    /**
     * WordPress 훅 등록
     */
    private function init_hooks() {
        add_action('vt_download_complete', array($this, 'import_to_media_library'), 10, 1);
        add_action('vt_job_completed', array($this, 'on_job_completed'), 10, 2);
        add_action('admin_post_vt_delete_file', array($this, 'handle_delete_file'));
        add_action('admin_post_vt_import_file', array($this, 'handle_import_file'));
        add_filter('upload_mimes', array($this, 'add_video_mime_types'));
    }

    /**
     * 출력 디렉토리 내 모든 파일 스캔 (허용 확장자만)
     *
     * @param string $sort 정렬 기준 (name, size, date)
     * @param string $order 정렬 방향 (asc, desc)
     * @return array 파일 정보 배열
     */
    public function get_files($sort = 'date', $order = 'desc') {
        $files = array();
        $pattern = $this->output_dir . '*.{' . implode(',', $this->allowed_extensions) . '}';
        $glob = glob($pattern, GLOB_BRACE);

        if (empty($glob)) {
            return $files;
        }

        foreach ($glob as $filepath) {
            if (!is_file($filepath)) {
                continue;
            }
            $basename = basename($filepath);
            $files[] = array(
                'name'      => $basename,
                'path'      => $filepath,
                'url'       => $this->get_file_url($basename),
                'size'      => filesize($filepath),
                'size_human'=> size_format(filesize($filepath), 2),
                'modified'  => filemtime($filepath),
                'modified_human' => date_i18n(get_option('date_format') . ' ' . get_option('time_format'), filemtime($filepath)),
                'extension' => pathinfo($filepath, PATHINFO_EXTENSION),
                'mime_type' => $this->detect_mime_type($filepath)
            );
        }

        // 정렬
        usort($files, function($a, $b) use ($sort, $order) {
            $key = $sort;
            if ($key === 'name') {
                $cmp = strcmp($a['name'], $b['name']);
            } elseif ($key === 'size') {
                $cmp = $a['size'] - $b['size'];
            } else { // date
                $cmp = $a['modified'] - $b['modified'];
            }
            return ($order === 'asc') ? $cmp : -$cmp;
        });

        return $files;
    }

    /**
     * 파일의 공개 URL 반환
     *
     * @param string $filename
     * @return string
     */
    public function get_file_url($filename) {
        return content_url('uploads/vinetrimmer/' . ltrim($filename, '/'));
    }

    /**
     * MIME 타입 안전 감지 (fileinfo 확장 미설치 서버 대비)
     *
     * @param string $filepath
     * @return string
     */
    private function detect_mime_type($filepath) {
        // 1순위: WordPress 내장 (확장자 기반, 항상 사용 가능)
        $checked = wp_check_filetype(basename($filepath));
        if (!empty($checked['type'])) {
            return $checked['type'];
        }
        // 2순위: fileinfo 확장이 있으면 실제 내용 기반 감지
        if (function_exists('mime_content_type')) {
            $detected = @mime_content_type($filepath);
            if (!empty($detected)) {
                return $detected;
            }
        }
        // 폴백
        return 'application/octet-stream';
    }

    /**
     * 파일을 WordPress 미디어 라이브러리에 임포트
     *
     * @param string $file_path 파일 절대 경로 또는 파일명
     * @return int|false 첨부 ID, 실패 시 false
     */
    public function import_to_media_library($file_path) {
        // 파일 경로 확인
        if (!file_exists($file_path)) {
            // 파일명만 제공된 경우 출력 디렉토리와 결합
            $full_path = $this->output_dir . ltrim($file_path, '/');
            if (file_exists($full_path)) {
                $file_path = $full_path;
            } else {
                return false;
            }
        }

        // 파일이 이미 미디어 라이브러리에 있는지 확인 (중복 방지)
        $existing = $this->find_attachment_by_file($file_path);
        if ($existing) {
            return $existing;
        }

        // 업로드 디렉토리로 복사
        $upload_dir = wp_upload_dir();
        $dest_path = $upload_dir['path'] . '/' . basename($file_path);
        copy($file_path, $dest_path);

        // 파일 타입 확인
        $file_type = wp_check_filetype($dest_path);
        if (!$file_type['ext'] || !in_array($file_type['ext'], $this->allowed_extensions)) {
            @unlink($dest_path);
            return false;
        }

        // 첨부 데이터 구성
        $attachment = array(
            'guid'           => $upload_dir['url'] . '/' . basename($file_path),
            'post_mime_type' => $file_type['type'],
            'post_title'     => preg_replace('/\.[^.]+$/', '', basename($file_path)),
            'post_content'   => '',
            'post_status'    => 'inherit'
        );

        $attach_id = wp_insert_attachment($attachment, $dest_path);
        if (is_wp_error($attach_id) || $attach_id === 0) {
            @unlink($dest_path);
            return false;
        }

        // 필요한 WordPress 파일 포함
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attach_data = wp_generate_attachment_metadata($attach_id, $dest_path);
        wp_update_attachment_metadata($attach_id, $attach_data);

        // 로그 기록
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[Vinetrimmer] 파일 임포트 완료: ' . basename($file_path) . ' (ID: ' . $attach_id . ')');
        }

        return $attach_id;
    }

    /**
     * 파일 경로로 미디어 라이브러리 첨부 찾기
     *
     * @param string $file_path
     * @return int|false
     */
    private function find_attachment_by_file($file_path) {
        global $wpdb;
        $filename = basename($file_path);
        $query = $wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE post_type = 'attachment' AND post_title = %s", preg_replace('/\.[^.]+$/', '', $filename));
        $result = $wpdb->get_var($query);
        return $result ? intval($result) : false;
    }

    /**
     * 관리자 액션 리다이렉트 기준 URL 반환 (referer 없으면 메인 페이지로 폴백)
     *
     * @return string
     */
    private function get_redirect_base() {
        $referer = wp_get_referer();
        if (!empty($referer)) {
            return $referer;
        }
        return admin_url('admin.php?page=vinetrimmer-drm');
    }

    /**
     * 파일 삭제 처리 (관리자 POST 액션)
     */
    public function handle_delete_file() {
        if (!current_user_can('manage_options')) {
            wp_die('권한이 없습니다.');
        }
        check_admin_referer('vt_delete_file', 'vt_nonce');

        $base = $this->get_redirect_base();
        $filename = isset($_GET['file']) ? basename(sanitize_file_name(wp_unslash($_GET['file']))) : '';
        if (empty($filename)) {
            wp_safe_redirect(add_query_arg(array('deleted' => 'false'), $base));
            exit;
        }

        $filepath = $this->output_dir . $filename;
        if (!file_exists($filepath)) {
            wp_safe_redirect(add_query_arg(array('deleted' => 'notfound'), $base));
            exit;
        }

        // 미디어 라이브러리에서 연결된 첨부 삭제
        $attachment_id = $this->find_attachment_by_file($filepath);
        if ($attachment_id) {
            wp_delete_attachment($attachment_id, true);
        }

        // 파일 삭제
        if (@unlink($filepath)) {
            wp_safe_redirect(add_query_arg(array('deleted' => 'true'), $base));
        } else {
            wp_safe_redirect(add_query_arg(array('deleted' => 'false'), $base));
        }
        exit;
    }

    /**
     * 파일 수동 임포트 처리
     */
    public function handle_import_file() {
        if (!current_user_can('manage_options')) {
            wp_die('권한이 없습니다.');
        }
        check_admin_referer('vt_import_file', 'vt_nonce');

        $base = $this->get_redirect_base();
        $filename = isset($_GET['file']) ? basename(sanitize_file_name(wp_unslash($_GET['file']))) : '';
        if (empty($filename)) {
            wp_safe_redirect(add_query_arg(array('imported' => 'false'), $base));
            exit;
        }

        $filepath = $this->output_dir . $filename;
        if (!file_exists($filepath)) {
            wp_safe_redirect(add_query_arg(array('imported' => 'notfound'), $base));
            exit;
        }

        $attachment_id = $this->import_to_media_library($filepath);
        if ($attachment_id) {
            wp_safe_redirect(add_query_arg(array('imported' => 'true', 'attachment_id' => $attachment_id), $base));
        } else {
            wp_safe_redirect(add_query_arg(array('imported' => 'false'), $base));
        }
        exit;
    }

    /**
     * 작업 완료 시 파일 임포트 (자동)
     *
     * @param string $job_id
     * @param array  $job_data
     */
    public function on_job_completed($job_id, $job_data) {
        // 출력 디렉토리에서 최신 파일 찾아 임포트
        $files = $this->get_files('date', 'desc');
        if (!empty($files)) {
            $latest = $files[0];
            $this->import_to_media_library($latest['path']);
        }
    }

    /**
     * 추가 비디오 MIME 타입 등록
     *
     * @param array $mimes
     * @return array
     */
    public function add_video_mime_types($mimes) {
        $mimes['mkv'] = 'video/x-matroska';
        $mimes['webm'] = 'video/webm';
        $mimes['ts'] = 'video/mp2t';
        $mimes['m4v'] = 'video/x-m4v';
        return $mimes;
    }

    /**
     * 디스크 사용량 반환 (MB)
     *
     * @return float
     */
    public function get_disk_usage() {
        $total = 0;
        $files = $this->get_files();
        foreach ($files as $file) {
            $total += $file['size'];
        }
        return round($total / (1024 * 1024), 2);
    }

    /**
     * 오래된 파일 정리 (일수 기준)
     *
     * @param int $days 30일 이상 된 파일 삭제
     * @return int 삭제된 파일 수
     */
    public function cleanup_old_files($days = 30) {
        $cutoff = time() - ($days * DAY_IN_SECONDS);
        $deleted = 0;
        $files = $this->get_files();
        foreach ($files as $file) {
            if ($file['modified'] < $cutoff) {
                if (unlink($file['path'])) {
                    $deleted++;
                }
            }
        }
        return $deleted;
    }
}