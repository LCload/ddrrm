<?php
/**
 * Plugin Name: Vinetrimmer Playready DRM Tool
 * Plugin URI: https://github.com/widevineleak/Vinetrimmer-Playready-V1.0
 * Description: WordPress 플러그인으로 통합된 Playready DRM 다운로드 및 해독 도구
 * Version: 1.5.1
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author: Bread & Sonion
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: vinetrimmer-drm
 *
 * @package Vinetrimmer_DRM
 *
 * ---------------------------------------------------------------------------
 * 아키텍처 개요 (v1.5.1)
 * ---------------------------------------------------------------------------
 * 이 파일은 "부트스트랩(bootstrap)" 역할만 담당합니다.
 *   1. 전역 상수 정의
 *   2. 활성화 / 비활성화 훅 등록
 *   3. includes/ 의 클래스 파일 로드
 *   4. 싱글턴 컨테이너(VT_Plugin)를 통해 각 컴포넌트 인스턴스화
 *
 * 실제 기능(메뉴, AJAX, 파일 관리, 로깅, 실행 엔진)은 모두
 * includes/ 디렉토리의 전용 클래스에서 처리됩니다. 이렇게 하여
 * 이전 버전에서 발생하던 "메인 파일 절차적 코드 ↔ 클래스" 간의
 * 중복 훅 등록 충돌을 근본적으로 제거했습니다.
 * ---------------------------------------------------------------------------
 */

// 직접 접근 차단
if (!defined('ABSPATH')) {
    exit;
}

// =========================================================================
// 1. 상수 정의 (절대 경로 및 URL)
// =========================================================================
if (!defined('VT_VERSION')) {
    define('VT_VERSION', '1.5.1');
}
if (!defined('VT_PLUGIN_FILE')) {
    define('VT_PLUGIN_FILE', __FILE__);
}
if (!defined('VT_PLUGIN_DIR')) {
    define('VT_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('VT_PLUGIN_URL')) {
    define('VT_PLUGIN_URL', plugin_dir_url(__FILE__));
}
if (!defined('VT_PLUGIN_BASENAME')) {
    define('VT_PLUGIN_BASENAME', plugin_basename(__FILE__));
}
if (!defined('VT_PYTHON_SCRIPT')) {
    define('VT_PYTHON_SCRIPT', VT_PLUGIN_DIR . 'runner.py');
}
// 출력 디렉토리 / URL: wp-config.php 에서 재정의 가능하도록 방어적으로 정의
if (!defined('VT_OUTPUT_DIR')) {
    define('VT_OUTPUT_DIR', trailingslashit(WP_CONTENT_DIR) . 'uploads/vinetrimmer/');
}
if (!defined('VT_OUTPUT_URL')) {
    define('VT_OUTPUT_URL', content_url('uploads/vinetrimmer/'));
}
if (!defined('VT_LOG_DIR')) {
    define('VT_LOG_DIR', trailingslashit(WP_CONTENT_DIR) . 'logs/');
}
if (!defined('VT_VENV_PYTHON')) {
    define('VT_VENV_PYTHON', VT_PLUGIN_DIR . 'venv/bin/python3');
}

// =========================================================================
// 2. 클래스 파일 로드 (오토로드)
// =========================================================================
$vt_includes = array(
    'includes/class-vt-logger.php',
    'includes/class-vt-loader.php',
    'includes/class-vt-file-manager.php',
    'includes/class-vt-admin.php',
    'includes/class-vt-ajax-handler.php',
);
foreach ($vt_includes as $vt_file) {
    $vt_path = VT_PLUGIN_DIR . $vt_file;
    if (file_exists($vt_path)) {
        require_once $vt_path;
    }
}

// =========================================================================
// 3. 커스텀 Cron 스케줄 등록 (1분 간격) — WP 기본에는 'minute'가 없음
// =========================================================================
add_filter('cron_schedules', 'vt_register_cron_schedules');
function vt_register_cron_schedules($schedules) {
    if (!isset($schedules['vt_minute'])) {
        $schedules['vt_minute'] = array(
            'interval' => 60,
            'display'  => __('Every Minute (Vinetrimmer)', 'vinetrimmer-drm'),
        );
    }
    return $schedules;
}

// =========================================================================
// 4. 메인 플러그인 컨테이너 (싱글턴)
// =========================================================================
final class VT_Plugin {

    /** @var VT_Plugin|null */
    private static $instance = null;

    /** @var VT_Logger */
    public $logger;

    /** @var VT_Loader */
    public $loader;

    /** @var VT_File_Manager */
    public $file_manager;

    /** @var VT_Admin */
    public $admin;

    /** @var VT_Ajax_Handler */
    public $ajax;

    /**
     * 싱글턴 인스턴스 반환
     *
     * @return VT_Plugin
     */
    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * 생성자: 각 컴포넌트를 순서대로 인스턴스화하고 의존성을 주입
     */
    private function __construct() {
        // 순서 중요: Logger → Loader → 나머지
        if (class_exists('VT_Logger')) {
            $this->logger = new VT_Logger();
        }
        if (class_exists('VT_Loader')) {
            $this->loader = new VT_Loader($this->logger);
        }
        if (class_exists('VT_File_Manager')) {
            $this->file_manager = new VT_File_Manager();
        }
        // Admin / Ajax 는 Loader 인스턴스를 필요로 함
        if (class_exists('VT_Admin') && $this->loader) {
            $this->admin = new VT_Admin($this->loader, $this->file_manager);
        }
        if (class_exists('VT_Ajax_Handler') && $this->loader) {
            $this->ajax = new VT_Ajax_Handler($this->loader);
        }
    }

    /** 복제 및 역직렬화 방지 (싱글턴 무결성) */
    public function __clone() {}
    public function __wakeup() {}
}

// =========================================================================
// 5. 부트스트랩: plugins_loaded 시점에 초기화
// =========================================================================
add_action('plugins_loaded', 'vt_bootstrap');
function vt_bootstrap() {
    // 텍스트 도메인 로드 (i18n)
    load_plugin_textdomain('vinetrimmer-drm', false, dirname(VT_PLUGIN_BASENAME) . '/languages');
    // 컨테이너 기동
    VT_Plugin::instance();
}

// =========================================================================
// 6. 활성화 / 비활성화 훅
// =========================================================================
register_activation_hook(__FILE__, 'vt_activate');
register_deactivation_hook(__FILE__, 'vt_deactivate');

function vt_activate() {
    // 출력 디렉토리 생성
    if (!file_exists(VT_OUTPUT_DIR)) {
        wp_mkdir_p(VT_OUTPUT_DIR);
    }
    // 로그 디렉토리 생성
    if (!file_exists(VT_LOG_DIR)) {
        wp_mkdir_p(VT_LOG_DIR);
    }

    // 출력 디렉토리에 인덱스 보호 파일 생성 (디렉토리 리스팅 방지)
    $index_file = trailingslashit(VT_OUTPUT_DIR) . 'index.php';
    if (!file_exists($index_file)) {
        @file_put_contents($index_file, "<?php // Silence is golden.\n");
    }

    // 기본 옵션 설정
    add_option('vt_quality_default', 'best');
    add_option('vt_service_default', 'disney');
    add_option('vt_sub_lang_default', 'ko');   // 기본 자막 언어: 한국어
    add_option('vt_sub_mode_default', 'mux');  // 기본 자막 처리: 먹싱
    add_option('vt_version', VT_VERSION);
    add_option('vt_installed_time', current_time('mysql'));

    // 버전 마이그레이션(향후 업그레이드 대비)
    update_option('vt_version', VT_VERSION);
}

function vt_deactivate() {
    // 예약된 백그라운드/하트비트 크론 정리
    wp_clear_scheduled_hook('vt_background_run');
    wp_clear_scheduled_hook('vt_heartbeat');
    // 실제 데이터/옵션 삭제는 uninstall.php 에서 수행
}
