#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Vinetrimmer Playready WordPress Runner
Bread & Sonion - 2026

이 스크립트는 WordPress 플러그인(PHP)으로부터 전달받은 인자를 기반으로
Vinetrimmer-Playready-V1.0 CLI를 실행하고, 결과를 표준 출력으로 반환합니다.

@version 1.5.1
"""

import sys
import os
import argparse
import subprocess
import json
import logging
import shutil
import tempfile
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional

# =========================================================================
# 1. 상수 및 기본 경로 설정
# =========================================================================
SCRIPT_DIR = Path(__file__).parent.resolve()
VT_CORE_DIR = SCRIPT_DIR / "vinetrimmer"
DEFAULT_OUTPUT = SCRIPT_DIR.parent / "wp-content" / "uploads" / "vinetrimmer"
LOG_FILE = SCRIPT_DIR.parent / "wp-content" / "logs" / "vinetrimmer.log"

# Python 경로에 Vinetrimmer 코어 추가 (임포트 가능하도록)
sys.path.insert(0, str(VT_CORE_DIR))

# =========================================================================
# 2. 로깅 설정 (파일 및 콘솔)
# =========================================================================
# 로그 디렉토리가 없으면 먼저 생성한다. (없을 경우 FileHandler 가 예외를 던져
# 스크립트가 시작조차 못 하던 문제를 방지)
_log_handlers = [logging.StreamHandler(sys.stdout)]
try:
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    # 회전 파일 핸들러: 10MB 초과 시 최대 5개 백업 (config.json 과 일치)
    from logging.handlers import RotatingFileHandler
    _log_handlers.insert(0, RotatingFileHandler(
        str(LOG_FILE), maxBytes=10 * 1024 * 1024, backupCount=5, encoding='utf-8'
    ))
except OSError:
    # 파일 로깅이 불가능해도(권한 등) 콘솔 로깅으로 계속 진행
    pass

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=_log_handlers
)
logger = logging.getLogger(__name__)

# =========================================================================
# 3. 인자 파서
# =========================================================================
def parse_args():
    parser = argparse.ArgumentParser(description='Vinetrimmer WordPress Runner')
    parser.add_argument(
        '--service',
        required=True,
        choices=['disney', 'amzn', 'apple', 'nowtv', 'hulu', 'itunes', 'canal', 'paramount', 'max', 'netflix',
                 'tving', 'wavve', 'watcha', 'coupang'],
        help='스트리밍 서비스 식별자'
    )
    parser.add_argument(
        '--url',
        required=True,
        help='콘텐츠의 전체 URL (예: https://www.disneyplus.com/ko-kr/video/...)'
    )
    parser.add_argument(
        '--quality',
        default='best',
        choices=['best', '2160p', '1080p', '720p', '480p'],
        help='원하는 화질 (기본값: best)'
    )
    parser.add_argument(
        '--output',
        required=True,
        help='출력 파일을 저장할 디렉토리 절대 경로'
    )
    parser.add_argument(
        '--config',
        default=str(SCRIPT_DIR / 'config.json'),
        help='설정 파일 경로 (기본값: config.json)'
    )
    parser.add_argument(
        '--sub-lang',
        default='ko',
        help=(
            "원하는 자막 언어 코드 (기본값: ko). "
            "Vinetrimmer CLI 의 -sl/--slang 로 전달됩니다. "
            "쉼표로 여러 언어를 지정할 수 있습니다 (예: ko,en). 'all' 이면 모든 자막."
        )
    )
    parser.add_argument(
        '--sub-mode',
        default='mux',
        choices=['mux', 'burn', 'none'],
        help=(
            "자막 처리 방식 (기본값: mux). "
            "mux=별도 자막 트랙으로 먹싱(기본 표시 언어로 설정), "
            "burn=영상에 자막을 굽기(하드섭), none=자막 없음."
        )
    )
    parser.add_argument(
        '--no-clean',
        action='store_true',
        help='임시 파일을 삭제하지 않고 유지 (디버깅용)'
    )
    return parser.parse_args()

# =========================================================================
# 4. 환경 설정 로드
# =========================================================================
def load_config(config_path: str) -> Dict[str, Any]:
    """config.json을 읽어 환경 설정을 반환합니다."""
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        logger.warning(f"설정 파일이 없습니다: {config_path}. 기본값을 사용합니다.")
        return {}
    except json.JSONDecodeError as e:
        logger.error(f"설정 파일 JSON 파싱 오류: {e}")
        return {}

# =========================================================================
# 4-b. CLI 기능(플래그) 탐지 헬퍼
# =========================================================================
# vinetrimmer 버전에 따라 --burn-subs / --sub-default 같은 자막 관련 플래그
# 지원 여부가 다르다. `vinetrimmer dl --help` 출력을 1회 파싱하여 어떤 플래그가
# 실제로 존재하는지 캐시한다. 탐지에 실패해도(도움말 호출 불가 등) 절대 예외를
# 던지지 않고 빈 집합을 반환하여, 호출부가 안전하게 폴백하도록 한다.
_CLI_FEATURES_CACHE: Optional[set] = None


def _detect_cli_features(env: Optional[Dict[str, str]] = None) -> set:
    """`vinetrimmer dl --help` 를 파싱해 지원되는 옵션 플래그 집합을 반환."""
    global _CLI_FEATURES_CACHE
    if _CLI_FEATURES_CACHE is not None:
        return _CLI_FEATURES_CACHE

    features: set = set()
    try:
        help_proc = subprocess.run(
            ["vinetrimmer", "dl", "--help"],
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=30,
            cwd=str(SCRIPT_DIR),
        )
        help_text = help_proc.stdout or ""
        for flag in ("--burn-subs", "--sub-default", "--slang", "--no-subs"):
            if flag in help_text:
                features.add(flag)
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as e:
        # 도움말 조회 실패: 알 수 있는 안전한 기본 플래그만 가정하지 않고 비워둔다.
        logger.warning(f"CLI 기능 탐지 실패(무시하고 계속): {e}")
    except Exception as e:  # noqa: BLE001 - 방어적 처리
        logger.warning(f"CLI 기능 탐지 중 예기치 않은 오류(무시): {e}")

    _CLI_FEATURES_CACHE = features
    return features


# =========================================================================
# 5. Vinetrimmer CLI 실행 함수
# =========================================================================
def run_vinetrimmer(service: str, url: str, quality: str, output_dir: str,
                    config: Dict, config_path: str = "", no_clean: bool = False,
                    sub_lang: str = "ko", sub_mode: str = "mux") -> int:
    """
    Vinetrimmer CLI를 서브프로세스로 실행합니다.

    :param service:     스트리밍 서비스 식별자
    :param url:         콘텐츠 URL
    :param quality:     화질
    :param output_dir:  출력 디렉토리
    :param config:      파싱된 설정(dict)
    :param config_path: 설정 파일의 절대 경로(환경변수로 하위 프로세스에 전달)
    :param no_clean:    True 이면 임시 디렉토리를 삭제하지 않음(디버깅)
    :param sub_lang:    원하는 자막 언어 코드(기본 ko). CLI 의 -sl/--slang 로 전달.
    :param sub_mode:    자막 처리 방식: 'mux'(기본), 'burn'(하드섭), 'none'(자막 제외).
    :return: 0=성공, 그 외=실패
    """
    # 출력 디렉토리 생성
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    # 임시 작업 디렉토리 (다운로드 중간 파일)
    temp_dir = tempfile.mkdtemp(prefix='vt_temp_', dir=out_path)
    logger.info(f"임시 작업 디렉토리: {temp_dir}")

    # Vinetrimmer CLI 명령어 구성
    # 참고: Vinetrimmer는 'vinetrimmer dl' 서브커맨드를 사용합니다.
    cmd = [
        "vinetrimmer", "dl",
        "--service", service,
        "--url", url,
        "--quality", quality,
        "--output", str(out_path),
        "--temp-dir", temp_dir,
        "--no-prompt"          # 대화형 입력 없이 실행
    ]

    # 환경 변수에 Python 경로와 설정 파일 전달
    # (자막 옵션 탐지 시 하위 프로세스 환경으로도 사용하므로 CLI 인자 구성 전에 준비)
    env = os.environ.copy()
    env["PYTHONPATH"] = str(VT_CORE_DIR) + os.pathsep + env.get("PYTHONPATH", "")
    # Vinetrimmer 하위 프로세스가 설정을 읽을 수 있도록 "파일 경로"를 전달한다.
    # (이전 버전은 dict 를 문자열화하여 잘못된 값을 넘겼음)
    if config_path:
        env["VT_CONFIG"] = str(config_path)

    # config.json에 CDM/Playready 인증서 경로가 있다면 환경 변수로 설정
    if "cdm" in config:
        cdm_cfg = config["cdm"]
        if "device" in cdm_cfg:
            env["VT_DEVICE"] = cdm_cfg["device"]
        if "keybox" in cdm_cfg:
            env["VT_KEYBOX"] = cdm_cfg["keybox"]

    if "playready" in config:
        pr_cfg = config["playready"]
        if "license_url" in pr_cfg:
            env["VT_PR_LICENSE_URL"] = pr_cfg["license_url"]
        if "client_id" in pr_cfg:
            env["VT_PR_CLIENT_ID"] = pr_cfg["client_id"]

    # -----------------------------------------------------------------
    # 자막(subtitle) 처리 옵션
    #
    # Vinetrimmer CLI 는 -sl/--slang 으로 원하는 자막 언어를 필터링한다.
    # 기본값은 'ko'(한국어)로 지정하여, 다운로드되는 영상의 자막이
    # 한국어로 나오도록 한다.
    #  - sub_mode == 'none' : 자막을 다운로드하지 않는다(--no-subs).
    #  - sub_mode == 'burn' : 자막을 영상에 굽는다(하드섭). CLI 가 --burn-subs
    #                         플래그를 지원하면 사용하고, 지원하지 않으면
    #                         mux 로 안전하게 폴백한다.
    #  - sub_mode == 'mux'  : 별도 자막 트랙으로 먹싱하고, 지정 언어를
    #                         기본 표시 트랙으로 설정한다(--sub-default).
    # 알 수 없는 옵션이 전달되어도 서브프로세스가 죽지 않도록,
    # 실제 지원 여부는 CLI 헬프를 통해 사전 탐지한다.
    # -----------------------------------------------------------------
    normalized_lang = (sub_lang or "ko").strip() or "ko"

    if sub_mode == "none":
        cmd.append("--no-subs")
        logger.info("자막 모드: none (자막 다운로드 안 함)")
    else:
        # 지정한 언어의 자막만 선택 (예: ko)
        cmd.extend(["--slang", normalized_lang])
        logger.info(f"자막 언어(-sl): {normalized_lang}")

        cli_features = _detect_cli_features(env=env)

        if sub_mode == "burn":
            if "--burn-subs" in cli_features:
                cmd.append("--burn-subs")
                logger.info("자막 모드: burn (영상에 하드섭)")
            else:
                logger.warning(
                    "CLI 가 --burn-subs 를 지원하지 않아 mux 모드로 폴백합니다."
                )
                sub_mode = "mux"

        if sub_mode == "mux":
            # 지정 언어를 기본 표시 자막으로 설정 (지원 시)
            if "--sub-default" in cli_features:
                cmd.extend(["--sub-default", normalized_lang])
                logger.info(f"기본 표시 자막 언어(--sub-default): {normalized_lang}")
            else:
                logger.info(
                    "CLI 가 --sub-default 를 지원하지 않습니다. "
                    "자막은 먹싱되지만 기본 표시 지정은 플레이어에 위임됩니다."
                )

    logger.info(f"실행 명령어: {' '.join(cmd)}")
    logger.info(f"자막 설정 요약 - 언어: {normalized_lang}, 모드: {sub_mode}")

    try:
        # 서브프로세스 실행 (실시간 출력 캡처)
        process = subprocess.Popen(
            cmd,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            cwd=str(SCRIPT_DIR)  # Vinetrimmer가 상대 경로를 올바르게 찾도록
        )

        # 출력을 실시간으로 로깅 및 콘솔 출력
        for line in process.stdout:
            logger.info(line.rstrip())
            print(line, end='')  # PHP가 읽을 수 있도록 표준 출력에도 전달

        # 프로세스 종료 대기
        return_code = process.wait()
        if return_code == 0:
            logger.info("✅ Vinetrimmer 실행 성공")
        else:
            logger.error(f"❌ Vinetrimmer 실행 실패 (코드 {return_code})")

        return return_code

    except FileNotFoundError:
        logger.error("Vinetrimmer 명령어를 찾을 수 없습니다. 가상환경이 활성화되었는지 확인하세요.")
        print("ERROR: vinetrimmer 명령어가 PATH에 없습니다. poetry 설치 및 가상환경을 확인하세요.")
        return 1
    except Exception as e:
        logger.exception(f"예기치 않은 오류 발생: {e}")
        print(f"ERROR: {e}")
        return 1
    finally:
        # 오류 발생 여부와 무관하게 임시 디렉토리 정리 (no_clean 이 아닐 때)
        if not no_clean and Path(temp_dir).exists():
            shutil.rmtree(temp_dir, ignore_errors=True)
            logger.info(f"임시 디렉토리 정리 완료: {temp_dir}")

# =========================================================================
# 6. 메인 엔트리
# =========================================================================
def main():
    args = parse_args()

    logger.info("=" * 60)
    logger.info(f"Vinetrimmer Runner 시작 - {datetime.now().isoformat()}")
    logger.info(f"서비스: {args.service}, URL: {args.url}, 화질: {args.quality}")
    logger.info(f"출력 디렉토리: {args.output}")
    logger.info(f"자막 언어: {args.sub_lang}, 자막 모드: {args.sub_mode}")

    # 설정 로드
    config = load_config(args.config)
    logger.info(f"설정 로드 완료 (키: {list(config.keys())})")

    # config.json 의 전역 자막 기본값을 CLI 인자보다 낮은 우선순위로 병합한다.
    # (명령행에서 명시적으로 준 값이 최우선; 없으면 config → 최종 폴백 'ko')
    sub_lang = args.sub_lang
    sub_mode = args.sub_mode
    subtitle_cfg = config.get("subtitle", {}) if isinstance(config, dict) else {}
    if isinstance(subtitle_cfg, dict):
        # 사용자가 CLI 기본값('ko')을 그대로 두었고 config 에 다른 값이 있으면 config 사용
        if args.sub_lang == "ko" and subtitle_cfg.get("default_language"):
            sub_lang = str(subtitle_cfg["default_language"])
        if args.sub_mode == "mux" and subtitle_cfg.get("mode") in ("mux", "burn", "none"):
            sub_mode = str(subtitle_cfg["mode"])

    # 실행
    exit_code = run_vinetrimmer(
        service=args.service,
        url=args.url,
        quality=args.quality,
        output_dir=args.output,
        config=config,
        config_path=args.config,
        no_clean=args.no_clean,
        sub_lang=sub_lang,
        sub_mode=sub_mode
    )

    logger.info(f"종료 코드: {exit_code}")
    logger.info("=" * 60)

    # 종료 코드를 셸로 반환 (PHP에서 확인 가능)
    sys.exit(exit_code)

if __name__ == "__main__":
    main()