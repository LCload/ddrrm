/**
 * Vinetrimmer Playready DRM Tool - Admin Script
 * 
 * 이 스크립트는 관리자 페이지에서 폼 제출을 가로채고,
 * AJAX를 통해 백그라운드 작업을 실행하며,
 * 진행 상태를 실시간으로 업데이트합니다.
 *
 * @package Vinetrimmer_DRM
 * @author Bread & Sonion
 * @version 1.2.0
 * @requires jQuery (WordPress 내장)
 */

(function($) {
    'use strict';

    // =========================================================================
    // 1. DOM 요소 캐싱 및 상태 변수
    // =========================================================================
    const $form = $('#vt-run-form');  // 관리자 페이지의 메인 실행 폼 (고유 ID)
    const $submitBtn = $('#vt_run');
    const $progressWrapper = $('.vt-progress-wrapper');
    const $progressFill = $('.vt-progress-fill');
    const $progressStatus = $('.vt-progress-status');
    const $progressPct = $('.vt-progress-pct');
    const $engineState = $('#vt-engine-state');
    const $resultContainer = $('.notice-success, .notice-error').parent(); // 결과를 표시할 컨테이너
    const $fileList = $('.vt-file-list'); // 파일 목록 영역

    // 실행 버튼의 원래 라벨 (아이콘 포함 HTML)을 보존하여 복원 시 사용
    const submitBtnHtml = $submitBtn.html();

    let isRunning = false;

    // =========================================================================
    // 2. AJAX 요청 함수 (비동기 실행)
    // =========================================================================
    function runVinetrimmer(service, url, quality, subLang, subMode) {
        if (isRunning) {
            alert('⚠️ 이미 실행 중입니다. 잠시만 기다려주세요.');
            return;
        }

        // 입력 검증 (클라이언트 측 2차 방어)
        if (!url || !url.startsWith('http')) {
            alert('❌ 유효한 URL을 입력하세요 (https://...).');
            return;
        }

        if (!service) {
            alert('❌ 서비스를 선택하세요.');
            return;
        }

        // 버튼 비활성화 및 진행 상태 표시
        isRunning = true;
        $submitBtn.prop('disabled', true).html('<span class="dashicons dashicons-update vt-spin"></span> 실행 중...');
        $progressWrapper.addClass('active');
        $progressFill.css('width', '0%');
        $progressStatus.text('연결 중...');
        if ($engineState.length) { $engineState.text('실행 중'); }

        // 기존 결과 알림 제거
        $('.notice-success, .notice-error').remove();

        // AJAX 데이터 구성 (자막 언어/모드 포함)
        const data = {
            action: 'vt_run_async',
            service: service,
            url: url,
            quality: quality,
            sub_lang: subLang || 'ko',
            sub_mode: subMode || 'mux',
            nonce: vt_ajax.nonce // wp_localize_script로 전달됨
        };

        // AJAX 요청 전송
        $.ajax({
            url: vt_ajax.ajax_url,
            type: 'POST',
            data: data,
            timeout: 300000, // 5분 타임아웃 (긴 작업 고려)
            xhr: function() {
                // 진행률 추적을 위한 XHR 객체 확장
                const xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener('progress', function(evt) {
                    if (evt.lengthComputable) {
                        const percent = Math.round((evt.loaded / evt.total) * 100);
                        updateProgress(percent, '업로드 중...');
                    }
                });
                // 다운로드 진행률 (서버 응답)
                xhr.addEventListener('progress', function(evt) {
                    if (evt.lengthComputable) {
                        const percent = Math.round((evt.loaded / evt.total) * 100);
                        updateProgress(Math.min(percent, 95), '처리 중...');
                    }
                });
                return xhr;
            },
            beforeSend: function() {
                updateProgress(10, '서버에 요청 전송 중...');
            },
            success: function(response) {
                isRunning = false;
                $submitBtn.prop('disabled', false).html(submitBtnHtml);
                if ($engineState.length) { $engineState.text('준비됨'); }

                if (response.success) {
                    updateProgress(100, '✅ 작업 완료!');
                    $progressStatus.text('✅ ' + response.data.message);
                    // 성공 메시지 표시
                    showNotice('success', response.data.message);
                    // 파일 목록 새로고침 (location.reload 또는 AJAX로 리로드)
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                } else {
                    updateProgress(0, '❌ 실패');
                    $progressWrapper.removeClass('active');
                    showNotice('error', response.data.message || '알 수 없는 오류가 발생했습니다.');
                }
            },
            error: function(xhr, status, error) {
                isRunning = false;
                $submitBtn.prop('disabled', false).html(submitBtnHtml);
                if ($engineState.length) { $engineState.text('오류'); }
                $progressWrapper.removeClass('active');

                let errorMsg = '서버와 통신 중 오류가 발생했습니다.';
                if (status === 'timeout') {
                    errorMsg = '⏱️ 요청 시간이 초과되었습니다. 서버 부하를 확인하거나 더 긴 타임아웃을 설정하세요.';
                } else if (xhr.responseText) {
                    try {
                        const json = JSON.parse(xhr.responseText);
                        errorMsg = json.data?.message || json.message || errorMsg;
                    } catch (e) {
                        errorMsg = xhr.responseText.substring(0, 200);
                    }
                }
                showNotice('error', errorMsg);
                console.error('[Vinetrimmer] AJAX Error:', status, error, xhr);
            }
        });
    }

    // =========================================================================
    // 3. 진행률 업데이트 함수
    // =========================================================================
    function updateProgress(percent, statusText) {
        const clamped = Math.min(100, Math.max(0, percent));
        $progressFill.css('width', clamped + '%');
        if ($progressPct.length) {
            $progressPct.text(clamped + '%');
        }
        if (statusText) {
            $progressStatus.text(statusText);
        }
        // 진행률이 100%면 색상 변경
        if (clamped >= 100) {
            $progressFill.css('background', 'linear-gradient(90deg, #00a32a, #46b450)');
        } else {
            $progressFill.css('background', 'linear-gradient(90deg, #2271b1, #52acf7)');
        }
    }

    // =========================================================================
    // 4. 알림 표시 함수
    // =========================================================================
    function showNotice(type, message) {
        // 기존 알림 제거
        $('.notice-success, .notice-error').remove();

        const $notice = $('<div class="notice ' + 
            (type === 'success' ? 'notice-success' : 'notice-error') + 
            ' is-dismissible"><p><strong>' + 
            (type === 'success' ? '✅ ' : '❌ ') + 
            '</strong>' + message + '</p></div>');

        // 알림을 폼 위에 삽입
        $form.before($notice);

        // 자동 닫기 (성공 시 5초, 오류 시 10초)
        const timeout = type === 'success' ? 5000 : 10000;
        setTimeout(function() {
            $notice.fadeOut(400, function() {
                $(this).remove();
            });
        }, timeout);

        // 닫기 버튼 이벤트 (WordPress 기본 dismiss)
        $notice.on('click', '.notice-dismiss', function() {
            $notice.fadeOut(400, function() {
                $(this).remove();
            });
        });
    }

    // =========================================================================
    // 5. 파일 목록 새로고침 (AJAX로 갱신)
    // =========================================================================
    function refreshFileList() {
        if (!$fileList.length) return;
        // 간단히 페이지 새로고침으로 대체 (또는 AJAX GET 구현 가능)
        // 여기서는 성능을 위해 location.reload()를 사용하지만,
        // 더 우아한 방법: admin-ajax.php로 파일 목록을 JSON으로 받아 렌더링
        // 하지만 WordPress의 기본 파일 목록은 PHP에서 렌더링하므로 새로고침이 가장 안전함
        location.reload();
    }

    // =========================================================================
    // 6. 이벤트 바인딩
    // =========================================================================
    $form.on('submit', function(e) {
        e.preventDefault();

        // 폼 데이터 읽기
        const service = $('#vt_service').val();
        const url = $('#vt_url').val().trim();
        const quality = $('#vt_quality').val();
        const subLang = $('#vt_sub_lang').val();
        const subMode = $form.find('input[name="vt_sub_mode"]:checked').val() || 'mux';

        // 실행 함수 호출
        runVinetrimmer(service, url, quality, subLang, subMode);
    });

    // =========================================================================
    // 7. 엔터 키로 폼 제출 방지 (중복 실행 방지)
    // =========================================================================
    $form.find('input[type="url"]').on('keypress', function(e) {
        if (e.which === 13) {
            e.preventDefault();
            $form.submit();
        }
    });

    // =========================================================================
    // 8. 선택적: 상태 확인 폴링 (장시간 작업 모니터링)
    //      - 백그라운드에서 WP-Cron이 실행 중인지 주기적으로 확인
    //      - 현재는 간단히 구현, 필요 시 확장 가능
    // =========================================================================
    function checkStatus() {
        // 추후 확장을 위한 빈 함수 (예: 진행률 폴링)
        // if (isRunning) {
        //     $.post(vt_ajax.ajax_url, { action: 'vt_check_status', nonce: vt_ajax.nonce }, function(res) {
        //         if (res.data.progress) updateProgress(res.data.progress, res.data.status);
        //     });
        // }
    }

    // =========================================================================
    // 9. 페이지 로드 시 이전 실행 상태 복원 (선택적)
    // =========================================================================
    $(document).ready(function() {
        // 폼이 제출되었을 때 진행률 표시줄이 보이도록 초기화
        $progressWrapper.removeClass('active');
        updateProgress(0, '준비 완료');

        console.log('🍞 Vinetrimmer Admin Script loaded successfully. (Bread & Sonion, 2026)');
    });

    // =========================================================================
    // 10. v1.4.0: 쿠키 업로드/붙여넣기 탭 전환
    // =========================================================================
    $(document).on('click', '.vt-cookie-tab', function() {
        var target = $(this).data('cookie-tab');
        var $section = $(this).closest('.vt-card--cookie');

        // 탭 활성 상태 토글
        $section.find('.vt-cookie-tab').removeClass('is-active');
        $(this).addClass('is-active');

        // 패널 표시/숨김
        $section.find('.vt-cookie-panel').each(function() {
            if ($(this).data('cookie-panel') === target) {
                $(this).prop('hidden', false);
            } else {
                $(this).prop('hidden', true);
            }
        });
    });

    // 쿠키 저장 결과가 있으면 쿠키 섹션으로 부드럽게 스크롤
    if (window.location.hash === '#vt-cookie-section') {
        var $cookieSection = $('#vt-cookie-section');
        if ($cookieSection.length) {
            $('html, body').animate({ scrollTop: $cookieSection.offset().top - 40 }, 400);
        }
    }

})(jQuery);