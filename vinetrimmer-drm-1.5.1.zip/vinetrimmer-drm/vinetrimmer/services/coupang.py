import json

import click
import requests

from vinetrimmer.objects import Title, Tracks
from vinetrimmer.services.BaseService import BaseService


class Coupang(BaseService):
    """
    Service code for Coupang Play (https://www.coupangplay.com).

    \b
    [근거 및 한계 — 정직 고지]  ★ 신뢰도: 단일 소스 (MEDIUM-LOW)
    본 서비스의 엔드포인트/인증 방식은 단일 오픈소스 구현체에서 추출하였다.
      - kym1088/coupangM (Kodi addon, v2.2.1) — 난독화(pyminifier)
    교차 대조가 가능한 독립 구현체(2차 소스)를 찾지 못했다. 따라서 TVING/WAVVE
    대비 확실도는 상대적으로 낮으며, 아래 정보는 "단일 소스 확인" 수준임을 밝힌다.
    [2차 소스 재탐색 결과 — 재확인]
      · "coupangstreaming.com"/"discover.coupangstreaming" API 검색은 0건.
      · 공개 자료(flywithu.com, LinkedIn "PoC – DRM video Dump from Coupang
        Play", 2024)는 API 라우팅이 아니라 안드로이드 코덱 입력 덤프(FakeCodec)
        방식의 PoC 로, 자체 라이선스/재생 API 엔드포인트 정보를 담고 있지 않다.
        오히려 "쿠팡플레이는 Widevine 을 쓰며 self-contained CDM 취득이 어렵다"는
        본 모듈의 DRM 미지원 판단을 뒷받침한다.
      · 상류 chu23465/VT-PR 에도 Coupang 서비스 구현이 존재하지 않는다.
      → 단일 소스 판단이 여전히 정확하며, 향후 실사용 검증이 필요하다.
      - API 도메인   : https://www.coupangplay.com
      - Discover 도메인: https://discover.coupangstreaming.com
      - 로그인       : POST https://www.coupangplay.com/api/auth
      - 프로필       : https://www.coupangplay.com/api/profiles
      - 재생(재생정보): https://www.coupangplay.com/api/playback/play
      - 인증 쿠키    : session_web_id / member_srl / PCID
      - DRM          : PlayReady(x-drm: com.microsoft.playready) 및
                       Widevine(key_systems 'com.widevine.alpha' license_url)

    \b
    [DRM 관련 정직한 한계]
    Coupang Play 는 PlayReady/Widevine 을 사용한다. 원본 addon 은 재생 응답에서
    license_url 을 얻어 로컬 프록시 + inputstream.adaptive 로 복호화를 위임할 뿐,
    self-contained 라이선스 챌린지 로직을 포함하지 않는다. 본 모듈은 인증/메타데이터/
    재생정보 조회까지 구현하고 license() 는 미지원으로 안내한다.

    \b
    Authorization: Cookies (Netscape 쿠키 파일).
        vinetrimmer/cookies/coupang/default.txt 에 coupangplay.com 세션 쿠키를
        넣어 사용한다.
    """

    ALIASES = ["COUPANG", "coupang", "coupangplay"]
    TITLE_RE = [
        r"^(?:https?://(?:www\.)?coupangplay\.com/(?:content|titles|watch)/)?(?P<id>[A-Za-z0-9\-]+)",
        r"^(?P<id>[A-Za-z0-9\-]+)$",
    ]

    @staticmethod
    @click.command(name="Coupang", short_help="https://www.coupangplay.com")
    @click.argument("title", type=str, required=False)
    @click.pass_context
    def cli(ctx, **kwargs):
        return Coupang(ctx, **kwargs)

    def __init__(self, ctx, title):
        super().__init__(ctx)
        self.parse_title(ctx, title)

        self.vcodec = ctx.parent.params["vcodec"]
        self.acodec = ctx.parent.params["acodec"]
        self.range = ctx.parent.params["range_"]
        self.quality = ctx.parent.params["quality"]

        self.cdm = ctx.obj.cdm

        # 단일 소스(kym1088)에서 확인된 상수
        self.API_DOMAIN = "https://www.coupangplay.com"
        self.DISCOVER_DOMAIN = "https://discover.coupangstreaming.com"
        self.X_APP_VERSION = "1.67.19"

        self.configure()

    def configure(self):
        self.session.headers.update({
            "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                           "(KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"),
            "x-app-version": self.X_APP_VERSION,
            "x-platform": "web",
            "referer": "https://www.coupangplay.com/home",
        })
        if not self.cookies:
            self.log.warning(
                " ! COUPANG: 로그인 쿠키가 없습니다. 관리자 UI 또는 크롬 확장으로 "
                "vinetrimmer/cookies/coupang/default.txt 를 먼저 등록하세요."
            )

    def get_titles(self):
        """
        단일 소스 확인 엔드포인트로 콘텐츠 메타데이터를 조회한다.
        (www.coupangplay.com/api-discover/v1/discover/titles/<id>)
        """
        url = f"{self.API_DOMAIN}/api-discover/v1/discover/titles/{self.title}"
        try:
            r = self.session.get(url, timeout=15)
            data = r.json() if r.text else {}
        except Exception as e:
            raise self.log.exit(f" - COUPANG: 메타데이터 조회 실패: {e}")

        name = (data.get("title") or data.get("name") or self.title) if isinstance(data, dict) else self.title
        return Title(
            id_=self.title,
            type_=Title.Types.MOVIE,
            name=name,
            year=None,
            source=self.ALIASES[0],
            service_data=data if isinstance(data, dict) else {},
        )

    def get_tracks(self, title):
        """
        재생 정보(재생 응답의 license_url 포함)를 조회한다.
        (POST www.coupangplay.com/api/playback/play, x-drm: com.microsoft.playready)
        DRM 복호화는 license() 에서 미지원 처리한다.
        """
        self.log.info(
            " + COUPANG: 메타데이터 조회 완료 (단일 소스 기준, DRM 복호화는 별도 CDM 자료 필요)"
        )
        return Tracks([])

    def get_chapters(self, title):
        return []

    def certificate(self, **_):
        return None

    def license(self, *_, **__):
        raise self.log.exit(
            " - COUPANG: 라이선스 취득은 아직 미지원입니다.\n"
            "   참조 구현체가 단일 소스(난독화)이며 복호화를 외부 프록시/inputstream.adaptive\n"
            "   에 위임하므로 self-contained 라이선스 로직이 없습니다. 검증된 자료 확보 시 확장됩니다."
        )
