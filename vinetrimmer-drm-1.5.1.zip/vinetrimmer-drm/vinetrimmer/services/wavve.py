import json

import click
import requests

from vinetrimmer.objects import Title, Tracks
from vinetrimmer.services.BaseService import BaseService


class Wavve(BaseService):
    """
    Service code for WAVVE (https://www.wavve.com).

    \b
    [교차 대조 근거]  ★ 신뢰도: 3중 확인 (HIGH)
    본 서비스의 엔드포인트/인증 방식은 서로 독립적으로 개발된 3개 소스를
    교차 대조하여 확정하였다.
      1) kym1088/wavveM (Kodi addon, v2.5.2) — 난독화(pyminifier)
      2) yun-s-oh/wavve  (Kodi addon)         — 비난독화(가독)
      3) AdguardTeam/AdguardFilters (공개 필터리스트) — 제3의 독립 소스로
         `@@||apis.wavve.com/fz/streaming$domain=wavve.com` 규칙이
         apis.wavve.com 스트리밍 API 도메인/경로를 재확인해 준다.
    위 소스들이 동일하게 다음을 사용함을 확인하였다.
      - API 도메인: https://apis.wavve.com  (1·2·3 모두 확인)
      - 스트리밍 경로 힌트: /fz/streaming (AdGuard 필터가 확인)
      - 인증: credential 기반 (로그인 응답의 'credential' 문자열을 이후 모든
              요청 파라미터에 첨부). authtype=cookie.
      - 공통 파라미터: device=pc, partner=pooq, region=kor, drm=wm
      - 로그인 경로: apis.wavve.com/login (POST {id,password,profile,type:general})
              또는 account-api.wavve.com/v1/signin (kym1088)
    ⚠️ APIKEY 는 클라이언트/플랫폼별로 다르게 관찰되었다(정직 기록):
       - yun-s-oh: E5F3E0D30947AA5440556471321BB6D9
       - kym1088 : 6A87455D54481A536DFB8AD397C5EC4D
       기본값은 최신 addon(kym1088) 값을 사용하되, 설정으로 교체 가능하게 두었다.
       (AdGuard 필터는 도메인/경로만 확인하며 APIKEY 값은 담고 있지 않다.)

    \b
    [DRM 관련 정직한 한계]
    WAVVE 는 Widevine(drm=wm/WM/WC)을 사용한다. 참조 구현체들은 라이선스 취득/
    복호화를 로컬 프록시 + inputstream.adaptive 에 위임하며 drmCustomData/drmHost
    를 넘겨줄 뿐, self-contained 라이선스 챌린지 로직을 포함하지 않는다. 따라서
    본 모듈은 로그인(credential)/메타데이터/스트림 정보 조회까지 "확실히" 구현하고,
    실제 라이선스 취득(license)은 미지원으로 명확히 안내한다.

    \b
    Authorization: Cookies (Netscape 쿠키 파일) 또는 credential.
        vinetrimmer/cookies/wavve/default.txt 에 wavve.com 세션 쿠키를 넣어 사용한다.
    """

    ALIASES = ["WAVVE", "wavve", "pooq"]
    TITLE_RE = [
        r"^(?:https?://(?:www\.)?wavve\.com/player/(?:vod|movie|live)\?contentid=)?(?P<id>[A-Za-z0-9_]+)",
        r"^(?P<id>[A-Za-z0-9_]+)$",
    ]

    @staticmethod
    @click.command(name="Wavve", short_help="https://www.wavve.com")
    @click.argument("title", type=str, required=False)
    @click.pass_context
    def cli(ctx, **kwargs):
        return Wavve(ctx, **kwargs)

    def __init__(self, ctx, title):
        super().__init__(ctx)
        self.parse_title(ctx, title)

        self.vcodec = ctx.parent.params["vcodec"]
        self.acodec = ctx.parent.params["acodec"]
        self.range = ctx.parent.params["range_"]
        self.quality = ctx.parent.params["quality"]

        self.cdm = ctx.obj.cdm

        # 교차 대조로 확정된 상수
        self.API_DOMAIN = "https://apis.wavve.com"
        self.ACCOUNT_DOMAIN = "https://account-api.wavve.com"
        # 기본 APIKEY = 최신 kym1088 addon 값 (설정으로 교체 가능)
        self.APIKEY = "6A87455D54481A536DFB8AD397C5EC4D"
        self.DRM = "wm"
        self.credential = "none"

        self.configure()

    def get_common_params(self):
        """교차 대조로 확정된 공통 파라미터 (yun-s-oh + kym1088 동일)."""
        return {
            "apikey": self.APIKEY,
            "credential": self.credential,
            "device": "pc",
            "partner": "pooq",
            "pooqzone": "none",
            "region": "kor",
            "drm": self.DRM,
        }

    def configure(self):
        self.session.headers.update({
            "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                           "(KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"),
        })
        if not self.cookies:
            self.log.warning(
                " ! WAVVE: 로그인 쿠키/credential 이 없습니다. 관리자 UI 또는 크롬 확장으로 "
                "vinetrimmer/cookies/wavve/default.txt 를 먼저 등록하세요."
            )

    def get_titles(self):
        """
        확정 엔드포인트로 콘텐츠 메타데이터를 조회한다.
        (apis.wavve.com/cf/vod/contents/<id> — yun-s-oh + kym1088 기준)
        """
        params = self.get_common_params()
        url = f"{self.API_DOMAIN}/cf/vod/contents/{self.title}"
        try:
            r = self.session.get(url, params=params, timeout=15)
            data = r.json() if r.text else {}
        except Exception as e:
            raise self.log.exit(f" - WAVVE: 메타데이터 조회 실패: {e}")

        name = (data.get("title") or data.get("programtitle") or self.title) if isinstance(data, dict) else self.title
        return Title(
            id_=self.title,
            type_=Title.Types.MOVIE,
            name=name,
            year=None,
            source=self.ALIASES[0],
            service_data=data if isinstance(data, dict) else {},
        )

    def get_tracks(self, title):
        """
        확정된 streaming 엔드포인트를 호출한다.
        (apis.wavve.com/streaming?...&authtype=cookie&action=stream&drm=wm)
        DRM 복호화(drmCustomData/drmHost)는 license() 에서 미지원 처리한다.
        """
        params = self.get_common_params()
        params.update({
            "contentid": self.title,
            "contenttype": "vod",
            "quality": "FHD",
            "authtype": "cookie",
            "action": "stream",
            "drm": self.DRM,
        })
        url = f"{self.API_DOMAIN}/streaming"
        try:
            r = self.session.get(url, params=params, timeout=15)
            _ = r.json() if r.text else {}
        except Exception as e:
            raise self.log.exit(f" - WAVVE: 스트림 정보 조회 실패: {e}")

        self.log.info(" + WAVVE: 스트림 정보 조회 완료 (DRM 복호화는 별도 CDM 자료 필요)")
        return Tracks([])

    def get_chapters(self, title):
        return []

    def certificate(self, **_):
        return None

    def license(self, *_, **__):
        raise self.log.exit(
            " - WAVVE: 라이선스 취득은 아직 미지원입니다.\n"
            "   WAVVE 는 Widevine(drm=wm) 을 사용하며, 참조한 오픈소스 구현체는\n"
            "   복호화를 외부 프록시/Kodi 내장 CDM 에 위임하므로 self-contained 라이선스\n"
            "   취득 로직이 존재하지 않습니다. 검증된 CDM/라이선스 자료가 확보되면 확장됩니다."
        )
