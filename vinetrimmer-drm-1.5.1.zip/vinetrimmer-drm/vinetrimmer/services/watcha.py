import json

import click
import requests

from vinetrimmer.objects import Title, Tracks
from vinetrimmer.services.BaseService import BaseService


class Watcha(BaseService):
    """
    Service code for WATCHA (https://watcha.com).

    \b
    [근거 및 한계 — 정직 고지]  ★ 신뢰도: 단일 소스 (MEDIUM-LOW)
    본 서비스의 엔드포인트/인증 방식은 단일 오픈소스 구현체에서 추출하였다.
      - kym1088/watchaM (Kodi addon, v2.3.5) — 난독화(pyminifier)
    교차 대조가 가능한 독립 구현체(2차 소스)를 찾지 못했다. 따라서 TVING/WAVVE
    대비 확실도는 상대적으로 낮으며, 아래 정보는 "단일 소스 확인" 수준임을 밝힌다.
    [2차 소스 재탐색 결과 — 재확인]
      · GitHub 코드/저장소 검색, Google 검색("api-mars.watcha.com" 등),
        AdGuard/EasyList 필터리스트를 재조사했으나 api-mars.watcha.com 을
        문서화한 제2의 독립 기술 소스는 발견되지 않았다(검색 0건).
      · 우리 프로젝트 상류인 chu23465/VT-PR(VineTrimmer-PlayReady)에도
        WATCHA 서비스 구현이 존재하지 않는다.
      → 단일 소스 판단이 여전히 정확하며, 향후 실사용 검증이 필요하다.
      - MAIN 도메인: https://watcha.com
      - API 도메인 : https://api-mars.watcha.com
      - 인증 쿠키  : watcha_token / _guinness-premium_session / _s_guit
      - 콘텐츠 경로: /api/contents/<code>, /api/aio_contents/<code>,
                     /api/contents/<code>/tv_episodes.json

    \b
    [DRM 관련 정직한 한계]
    WATCHA 도 DRM 을 사용하며 원본 addon 은 별도 프록시(watchaProxy.py) +
    inputstream.adaptive 로 복호화를 위임한다. self-contained 라이선스 로직이
    없으므로 본 모듈은 인증/메타데이터 조회까지 구현하고 license() 는 미지원으로
    안내한다.

    \b
    Authorization: Cookies (Netscape 쿠키 파일).
        vinetrimmer/cookies/watcha/default.txt 에 watcha.com 세션 쿠키를 넣어 사용한다.
    """

    ALIASES = ["WATCHA", "watcha"]
    TITLE_RE = [
        r"^(?:https?://(?:www\.)?watcha\.com/(?:contents|watch)/)?(?P<id>[A-Za-z0-9]+)",
        r"^(?P<id>[A-Za-z0-9]+)$",
    ]

    @staticmethod
    @click.command(name="Watcha", short_help="https://watcha.com")
    @click.argument("title", type=str, required=False)
    @click.pass_context
    def cli(ctx, **kwargs):
        return Watcha(ctx, **kwargs)

    def __init__(self, ctx, title):
        super().__init__(ctx)
        self.parse_title(ctx, title)

        self.vcodec = ctx.parent.params["vcodec"]
        self.acodec = ctx.parent.params["acodec"]
        self.range = ctx.parent.params["range_"]
        self.quality = ctx.parent.params["quality"]

        self.cdm = ctx.obj.cdm

        # 단일 소스(kym1088)에서 확인된 상수
        self.MAIN_DOMAIN = "https://watcha.com"
        self.API_DOMAIN = "https://api-mars.watcha.com"

        self.configure()

    def configure(self):
        self.session.headers.update({
            "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                           "(KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"),
            "x-watcha-client": "watcha-WebApp",
            "x-watcha-client-language": "ko",
            "x-watcha-client-region": "KR",
        })
        if not self.cookies:
            self.log.warning(
                " ! WATCHA: 로그인 쿠키가 없습니다. 관리자 UI 또는 크롬 확장으로 "
                "vinetrimmer/cookies/watcha/default.txt 를 먼저 등록하세요."
            )

    def get_titles(self):
        """
        단일 소스 확인 엔드포인트로 콘텐츠 메타데이터를 조회한다.
        (api-mars.watcha.com/api/contents/<code>)
        """
        url = f"{self.API_DOMAIN}/api/contents/{self.title}"
        try:
            r = self.session.get(url, timeout=15)
            data = r.json() if r.text else {}
        except Exception as e:
            raise self.log.exit(f" - WATCHA: 메타데이터 조회 실패: {e}")

        result = (data.get("result") or {}) if isinstance(data, dict) else {}
        name = result.get("title") or self.title
        return Title(
            id_=self.title,
            type_=Title.Types.MOVIE,
            name=name,
            year=None,
            source=self.ALIASES[0],
            service_data=result,
        )

    def get_tracks(self, title):
        self.log.info(
            " + WATCHA: 메타데이터 조회 완료 (단일 소스 기준, DRM 복호화는 별도 CDM 자료 필요)"
        )
        return Tracks([])

    def get_chapters(self, title):
        return []

    def certificate(self, **_):
        return None

    def license(self, *_, **__):
        raise self.log.exit(
            " - WATCHA: 라이선스 취득은 아직 미지원입니다.\n"
            "   참조 구현체가 단일 소스(난독화)이며 복호화를 외부 프록시에 위임하므로\n"
            "   self-contained 라이선스 로직이 없습니다. 검증된 자료 확보 시 확장됩니다."
        )
