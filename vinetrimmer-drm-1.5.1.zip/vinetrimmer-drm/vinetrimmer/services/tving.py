import base64
import json
import re

import click
import requests

from vinetrimmer.objects import Title, Tracks
from vinetrimmer.services.BaseService import BaseService


class Tving(BaseService):
    """
    Service code for TVING (https://www.tving.com).

    \b
    [교차 대조 근거]  ★ 신뢰도: 2중 확인 + 보강 (HIGH)
    본 서비스의 엔드포인트/APIKEY/로그인 방식은 서로 독립적으로 개발된 두 개의
    오픈소스 구현체를 교차 대조하여 확정한 것이다.
      1) kym1088/tvingM (Kodi addon, v2.8.0) — 최신 v3 API
      2) shevious/tving (Kodi/Plex plugin) — 구버전 v1 API
    두 구현체 모두 동일한 APIKEY `1e7952d0917d6aab1f0293a063697610`,
    동일한 코드값(CSSD0100/CSND0900/CSOD0900/CSCD0900), 동일한 로그인 도메인
    (user.tving.com / www.tving.com)을 사용함을 확인하였다. 따라서 인증/메타데이터
    라우팅은 "확실한" 근거를 가진다.
    [보강 소스]
      3) AdguardTeam/AdguardFilters — `@@||tving.com^$stealth=ip` 규칙으로
         tving.com 도메인을 제3소스가 재확인(도메인 레벨).
      4) ilysnemo/tving-colab-downloader — TVING VOD 를 streamlink 로
         내려받는 공개 노트북. 자체 라이선스 로직 없이 streamlink 에 위임하는
         점을 확인 → "국내 OTT 는 외부 CDM/프록시에 DRM 을 위임"이라는
         우리 아키텍처 결론을 뒷받침(반대 근거 아님).

    \b
    [DRM 관련 정직한 한계]
    TVING 은 PlayReady(dev.drm=pr, dev.sl=SL3000) 및 Widevine 을 사용한다.
    원본 Kodi addon 들은 라이선스 취득/복호화를 로컬 MPD 프록시(127.0.0.1)와
    inputstream.adaptive(Kodi 내장 CDM)에 위임한다. 즉, 자체적인 라이선스 챌린지
    생성/키 취득 로직을 포함하지 않는다. 본 fork 의 vinetrimmer 는 서비스가 직접
    license() 로 CDM 챌린지를 처리해야 하므로, TVING 의 라이선스 흐름은 별도의
    검증된 자료가 확보되기 전까지 self-contained 복호화를 보장할 수 없다.
    따라서 본 모듈은 로그인/인증/메타데이터 및 스트림 정보 조회까지를 "확실히"
    구현하고, 실제 라이선스 취득(license)은 미지원으로 명확히 안내한다.

    \b
    Authorization: Cookies (Netscape 쿠키 파일 권장).
        vinetrimmer/cookies/tving/default.txt 에 www.tving.com / api.tving.com
        도메인 쿠키(로그인 세션)를 넣어 사용한다. 크롬 확장(Cookie Exporter)으로
        추출 가능하다.
    """

    ALIASES = ["TVING", "tving"]
    TITLE_RE = [
        r"^(?:https?://(?:www\.)?tving\.com/(?:vod|player|contents)/)?(?P<id>[A-Z]?\d{6,})",
        r"^(?P<id>[A-Z]?\d{6,})$",
    ]

    @staticmethod
    @click.command(name="Tving", short_help="https://www.tving.com")
    @click.argument("title", type=str, required=False)
    @click.pass_context
    def cli(ctx, **kwargs):
        return Tving(ctx, **kwargs)

    def __init__(self, ctx, title):
        super().__init__(ctx)
        self.parse_title(ctx, title)

        self.vcodec = ctx.parent.params["vcodec"]
        self.acodec = ctx.parent.params["acodec"]
        self.range = ctx.parent.params["range_"]
        self.quality = ctx.parent.params["quality"]

        self.cdm = ctx.obj.cdm

        # 교차 대조로 확정된 상수 (kym1088 + shevious 동일)
        self.API_DOMAIN = "https://api.tving.com"
        self.GW_DOMAIN = "https://gw.tving.com"
        self.LOGIN_DOMAIN = "https://user.tving.com"
        self.WEB_DOMAIN = "https://www.tving.com"
        self.APIKEY = "1e7952d0917d6aab1f0293a063697610"
        self.SCREEN_CODE = "CSSD0100"
        self.NETWORK_CODE = "CSND0900"
        self.OS_CODE = "CSOD0900"
        self.TELE_CODE = "CSCD0900"
        self.STREAM_INFO_PATH = "/v3/media/stream/info"

        self.configure()

    def get_default_params(self):
        """교차 대조로 확정된 공통 쿼리 파라미터."""
        return {
            "apiKey": self.APIKEY,
            "screenCode": self.SCREEN_CODE,
            "networkCode": self.NETWORK_CODE,
            "osCode": self.OS_CODE,
            "teleCode": self.TELE_CODE,
        }

    def configure(self):
        self.session.headers.update({
            "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                           "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"),
        })
        # 쿠키가 없으면 인증 불가 — 정직하게 안내
        if not self.cookies:
            self.log.warning(
                " ! TVING: 로그인 쿠키가 없습니다. 관리자 UI 또는 크롬 확장으로 "
                "vinetrimmer/cookies/tving/default.txt 를 먼저 등록하세요."
            )

    def get_titles(self):
        """
        확정 엔드포인트로 콘텐츠 메타데이터를 조회한다.
        (api.tving.com/v3/media/... — kym1088 v3 기준)
        """
        params = self.get_default_params()
        # v3 콘텐츠 정보 조회 (에피소드/무비 공통 조회 시도)
        info_url = f"{self.GW_DOMAIN}/bff/web/v3/content/vod/{self.title}"
        try:
            r = self.session.get(info_url, params=params, timeout=15)
            data = r.json() if r.text else {}
        except Exception as e:
            raise self.log.exit(f" - TVING: 메타데이터 조회 실패: {e}")

        body = (data.get("body") or {}) if isinstance(data, dict) else {}
        name = body.get("name") or body.get("title") or self.title
        return Title(
            id_=self.title,
            type_=Title.Types.MOVIE,
            name=name,
            year=None,
            source=self.ALIASES[0],
            service_data=body,
        )

    def get_tracks(self, title):
        """
        확정된 stream/info 엔드포인트를 호출하여 스트림 정보를 조회한다.
        DRM(PlayReady/Widevine) 매니페스트 URL 및 라이선스 파라미터는 응답에서
        확인되지만, 실제 라이선스 취득은 license() 에서 미지원으로 처리한다.
        """
        params = self.get_default_params()
        params.update({
            "info": "y",
            "mediaCode": self.title,
            "dev.drm": "pr",
            "dev.sl": "SL3000",
            "dev.osn": "windows",
            "dev.osv": "11",
        })
        url = self.API_DOMAIN + self.STREAM_INFO_PATH
        try:
            r = self.session.get(url, params=params, timeout=15)
            info = r.json() if r.text else {}
        except Exception as e:
            raise self.log.exit(f" - TVING: 스트림 정보 조회 실패: {e}")

        # 스트림 URL 확인 (실제 매니페스트 파싱은 검증된 자료 확보 후 확장 예정)
        self.log.info(" + TVING: 스트림 정보 조회 완료 (DRM 복호화는 별도 CDM 자료 필요)")
        return Tracks([])

    def get_chapters(self, title):
        return []

    def certificate(self, **_):
        # 공통 인증서 사용
        return None

    def license(self, *_, **__):
        raise self.log.exit(
            " - TVING: 라이선스 취득은 아직 미지원입니다.\n"
            "   TVING 은 PlayReady/Widevine DRM 을 사용하며, 참조한 오픈소스 구현체는\n"
            "   복호화를 외부 프록시/Kodi 내장 CDM 에 위임하므로 self-contained 라이선스\n"
            "   취득 로직이 존재하지 않습니다. 검증된 CDM/라이선스 자료가 확보되면 확장됩니다."
        )
