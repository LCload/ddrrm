<?php
/**
 * 통합 검증 스크립트: 실제 WordPress 없이 플러그인 부트스트랩을 로드하여
 *  1) 치명적 오류(fatal) 없이 로드되는지
 *  2) 클래스가 모두 인스턴스화되는지
 *  3) 훅이 중복 등록되지 않는지 (메뉴/AJAX)
 *  4) 커스텀 cron 스케줄이 등록되는지
 * 를 검사한다.
 */

require __DIR__ . '/mock-wp-bootstrap.php';

$plugin_dir = dirname(__DIR__) . '/';
$fail = 0;
function check($cond, $label) {
    global $fail;
    if ($cond) {
        echo "  ✅ $label\n";
    } else {
        echo "  ❌ $label\n";
        $fail++;
    }
}

echo "== 1. 플러그인 메인 파일 로드 ==\n";
try {
    require $plugin_dir . 'vinetrimmer-plugin.php';
    check(true, '메인 파일 로드 (fatal 없음)');
} catch (Throwable $e) {
    check(false, '메인 파일 로드 실패: ' . $e->getMessage());
    exit(1);
}

echo "== 2. 상수 정의 확인 ==\n";
check(defined('VT_VERSION') && VT_VERSION === '1.5.1', 'VT_VERSION = 1.5.1');
check(defined('VT_PLUGIN_DIR'), 'VT_PLUGIN_DIR 정의됨');
check(defined('VT_OUTPUT_DIR'), 'VT_OUTPUT_DIR 정의됨');

echo "== 3. 클래스 존재 확인 ==\n";
foreach (array('VT_Logger','VT_Loader','VT_File_Manager','VT_Admin','VT_Ajax_Handler','VT_Plugin') as $c) {
    check(class_exists($c), "클래스 $c 로드됨");
}

echo "== 4. 부트스트랩 실행 (plugins_loaded 시뮬레이션) ==\n";
try {
    vt_register_cron_schedules(array());
    $schedules = vt_register_cron_schedules(array());
    check(isset($schedules['vt_minute']) && $schedules['vt_minute']['interval'] === 60, "커스텀 cron 'vt_minute' 등록 (60초)");

    vt_bootstrap();
    $p = VT_Plugin::instance();
    check($p instanceof VT_Plugin, 'VT_Plugin 싱글턴 생성');
    check($p->logger instanceof VT_Logger, 'Logger 인스턴스');
    check($p->loader instanceof VT_Loader, 'Loader 인스턴스');
    check($p->file_manager instanceof VT_File_Manager, 'File_Manager 인스턴스');
    check($p->admin instanceof VT_Admin, 'Admin 인스턴스');
    check($p->ajax instanceof VT_Ajax_Handler, 'Ajax_Handler 인스턴스');

    // 싱글턴 무결성
    check(VT_Plugin::instance() === $p, 'VT_Plugin 싱글턴 동일 인스턴스 반환');
} catch (Throwable $e) {
    check(false, '부트스트랩 실행 실패: ' . $e->getMessage());
}

echo "== 5. 훅 중복 등록 검사 ==\n";
// admin_menu 훅을 발화하여 메뉴 등록 콜백을 실제로 실행
__fire_action('admin_menu');
$actions = $GLOBALS['__actions'];

// 관리자 메뉴는 정확히 1회만 등록되어야 함
$menu_count = isset($actions['__menu_pages']) ? count(array_filter($actions['__menu_pages'], fn($s) => $s === 'vinetrimmer-drm')) : 0;
check($menu_count === 1, "메인 관리자 메뉴 등록 횟수 = 1 (실제: $menu_count)");

// AJAX 핸들러 vt_run_async 는 정확히 1회
$ajax_count = isset($actions['wp_ajax_vt_run_async']) ? count($actions['wp_ajax_vt_run_async']) : 0;
check($ajax_count === 1, "wp_ajax_vt_run_async 등록 횟수 = 1 (실제: $ajax_count)");

// vt_background_run 은 정확히 1회 (이전 버전엔 메인+클래스 2회였음)
$bg_count = isset($actions['vt_background_run']) ? count($actions['vt_background_run']) : 0;
check($bg_count === 1, "vt_background_run 등록 횟수 = 1 (실제: $bg_count)");

// vt_download_complete 미디어 임포트: File_Manager 1회
$dc_count = isset($actions['vt_download_complete']) ? count($actions['vt_download_complete']) : 0;
check($dc_count <= 1, "vt_download_complete 등록 횟수 <= 1 (실제: $dc_count)");

echo "== 6. Loader 환경 검사 로직 ==\n";
$loader = $p->loader;
check(method_exists($loader, 'run'), 'Loader::run() 존재');
check(method_exists($loader, 'get_output_dir'), 'Loader::get_output_dir() 존재');
check(is_string($loader->get_output_dir()), 'get_output_dir() 문자열 반환');

echo "== 7. Logger 동작 ==\n";
try {
    $p->logger->info('통합 테스트 로그 항목');
    $p->logger->error('통합 테스트 에러 항목');
    check(true, 'Logger info/error 호출 (예외 없음)');
    check(is_string($p->logger->tail(5)), 'Logger::tail() 문자열 반환');
} catch (Throwable $e) {
    check(false, 'Logger 호출 실패: ' . $e->getMessage());
}

echo "== 8. 자막 기능 (v1.2.0) ==\n";
try {
    $ref = new ReflectionClass('VT_Loader');

    // run() 시그니처에 sub_lang / sub_mode 파라미터 포함
    $params = $ref->getMethod('run')->getParameters();
    $names  = array_map(fn($p) => $p->getName(), $params);
    check(in_array('sub_lang', $names, true), "Loader::run() sub_lang 파라미터 존재");
    check(in_array('sub_mode', $names, true), "Loader::run() sub_mode 파라미터 존재");

    // sanitize_sub_lang: 유효/무효 값 처리
    check($ref->hasMethod('sanitize_sub_lang'), 'sanitize_sub_lang() 존재');
    check($ref->hasMethod('sanitize_sub_mode'), 'sanitize_sub_mode() 존재');

    $mLang = $ref->getMethod('sanitize_sub_lang'); $mLang->setAccessible(true);
    $mMode = $ref->getMethod('sanitize_sub_mode'); $mMode->setAccessible(true);

    check($mLang->invoke($loader, 'ko') === 'ko', "sub_lang 'ko' 유지");
    check($mLang->invoke($loader, 'ko,en') === 'ko,en', "sub_lang 'ko,en' 유지");
    check($mLang->invoke($loader, 'all') === 'all', "sub_lang 'all' 유지");
    check($mLang->invoke($loader, '한글!!') === 'ko', "sub_lang 잘못된 값 → 'ko' 폴백");

    check($mMode->invoke($loader, 'mux') === 'mux', "sub_mode 'mux' 유지");
    check($mMode->invoke($loader, 'burn') === 'burn', "sub_mode 'burn' 유지");
    check($mMode->invoke($loader, 'none') === 'none', "sub_mode 'none' 유지");
    check($mMode->invoke($loader, 'xxx') === 'mux', "sub_mode 잘못된 값 → 'mux' 폴백");
} catch (Throwable $e) {
    check(false, '자막 기능 검증 실패: ' . $e->getMessage());
}

echo "== 9. config.json 자막 정책 ==\n";
try {
    $cfg = json_decode(file_get_contents(__DIR__ . '/../config.json'), true);
    check(is_array($cfg) && isset($cfg['subtitle']), 'config.json subtitle 블록 존재');
    check(($cfg['subtitle']['default_language'] ?? '') === 'ko', "subtitle.default_language = ko");
    check(($cfg['subtitle']['mode'] ?? '') === 'mux', "subtitle.mode = mux");
} catch (Throwable $e) {
    check(false, 'config.json 검증 실패: ' . $e->getMessage());
}

echo "== 10. Netflix 서비스 통합 (v1.3.0+) ==\n";
try {
    // 10-1. loader 의 sanitize_service 가 netflix 를 허용하는지
    $rc = new ReflectionClass('VT_Loader');
    $inst = $rc->newInstanceWithoutConstructor();
    $mSvc = $rc->getMethod('sanitize_service');
    $mSvc->setAccessible(true);
    check($mSvc->invoke($inst, 'netflix') === 'netflix', "sanitize_service 'netflix' 허용");
    check($mSvc->invoke($inst, 'NETFLIX') === 'netflix', "sanitize_service 대문자 'NETFLIX' → 'netflix'");
    check($mSvc->invoke($inst, 'disney') === 'disney', "sanitize_service 기존 'disney' 유지(회귀 없음)");
    check($mSvc->invoke($inst, '해킹') === 'disney', "sanitize_service 잘못된 값 → 'disney' 폴백");

    // 10-2. netflix 서비스 파일 존재
    $nfPy  = __DIR__ . '/../vinetrimmer/services/netflix.py';
    $nfYml = __DIR__ . '/../vinetrimmer/config/services/netflix.yml';
    check(file_exists($nfPy),  'vinetrimmer/services/netflix.py 존재');
    check(file_exists($nfYml), 'vinetrimmer/config/services/netflix.yml 존재');

    // 10-3. netflix.py 가 PlayReady fork 로 이식되어 Widevine LocalDevice 를
    //       실제 코드에서 참조하지 않는지(주석 제외) 확인
    $src = file_get_contents($nfPy);
    check(strpos($src, 'class Netflix(BaseService)') !== false, 'netflix.py: Netflix(BaseService) 클래스 정의');
    check(strpos($src, 'import LocalDevice') === false, 'netflix.py: Widevine LocalDevice import 제거됨');
    check(strpos($src, 'sel.log') === false, 'netflix.py: sel.log 오타 버그 수정됨');
    check(strpos($src, 'KeyExchangeSchemes.AsymmetricWrapped') !== false, 'netflix.py: AsymmetricWrapped 키교환 사용');

    // 10-4. netflix.yml 필수 키 (간이 검증)
    $yml = file_get_contents($nfYml);
    foreach (['certificate:', 'endpoints:', 'manifest:', 'licence:', 'profiles:', 'payload_challenge:'] as $k) {
        check(strpos($yml, $k) !== false, "netflix.yml: '$k' 키 존재");
    }

    // 10-5. config.json 에 netflix 서비스 등록
    $cfg2 = json_decode(file_get_contents(__DIR__ . '/../config.json'), true);
    check(isset($cfg2['services']['netflix']), 'config.json: services.netflix 등록됨');
} catch (Throwable $e) {
    check(false, 'Netflix 서비스 검증 실패: ' . $e->getMessage());
}

echo "== 11. 쿠키 업로드/붙여넣기 기능 (v1.4.0) ==\n";
try {
    $rcA = new ReflectionClass('VT_Admin');

    // 11-1. admin_post 훅 등록 확인 (init_hooks 발화 후 $__actions 확인)
    $acts = $GLOBALS['__actions'];
    check(isset($acts['admin_post_vt_cookie_save']),   "admin_post_vt_cookie_save 훅 등록됨");
    check(isset($acts['admin_post_vt_cookie_delete']), "admin_post_vt_cookie_delete 훅 등록됨");

    // 11-2. 필수 메서드 존재
    foreach (['save_cookie','delete_cookie','render_cookie_card','cookie_path','cookie_status','cookie_services','is_valid_netscape_cookie'] as $m) {
        check($rcA->hasMethod($m), "VT_Admin::$m() 메서드 존재");
    }

    // 11-3. cookie_services 가 10개 서비스를 모두 지원하는지 (범용성)
    $adminInst = $rcA->newInstanceWithoutConstructor();
    $mServices = $rcA->getMethod('cookie_services');
    $mServices->setAccessible(true);
    $svcMap = $mServices->invoke($adminInst);
    foreach (['netflix','disney','amzn','apple','nowtv','hulu','itunes','canal','paramount','max'] as $s) {
        check(isset($svcMap[$s]), "cookie_services: '$s' 지원");
    }

    // 11-4. cookie_path 가 올바른 Netscape 경로를 생성하는지
    $mPath = $rcA->getMethod('cookie_path');
    $mPath->setAccessible(true);
    $p = $mPath->invoke($adminInst, 'netflix');
    check(substr($p, -strlen('vinetrimmer/cookies/netflix/default.txt')) === 'vinetrimmer/cookies/netflix/default.txt',
        "cookie_path('netflix') = …/vinetrimmer/cookies/netflix/default.txt");
    // 경로 인젝션 방지: 이상한 서비스명은 정규화
    $p2 = $mPath->invoke($adminInst, '../../etc');
    check(strpos($p2, '..') === false, "cookie_path: 경로 인젝션(../) 제거됨");

    // 11-5. Netscape 형식 검증기 동작
    $mValid = $rcA->getMethod('is_valid_netscape_cookie');
    $mValid->setAccessible(true);
    $goodCookie = ".netflix.com\tTRUE\t/\tTRUE\t0\tNetflixId\tv%3D2";
    $badCookie  = "이건 그냥 텍스트일 뿐 탭이 없어요";
    check($mValid->invoke($adminInst, $goodCookie) === true,  "is_valid_netscape_cookie: 유효 쿠키 통과");
    check($mValid->invoke($adminInst, $badCookie)  === false, "is_valid_netscape_cookie: 무효 텍스트 거부");

    // 11-6. 크롬 확장 프로그램 파일 존재 + manifest 유효성
    $extDir = __DIR__ . '/../chrome-extension';
    check(is_dir($extDir), 'chrome-extension/ 디렉토리 존재');
    foreach (['manifest.json','popup.html','popup.css','popup.js','README.md'] as $ef) {
        check(file_exists("$extDir/$ef"), "chrome-extension/$ef 존재");
    }
    $man = json_decode(file_get_contents("$extDir/manifest.json"), true);
    check(is_array($man) && ($man['manifest_version'] ?? 0) === 3, 'manifest.json: MV3');
    check(in_array('cookies', $man['permissions'] ?? [], true), "manifest.json: 'cookies' 권한 포함");
    check(in_array('<all_urls>', $man['host_permissions'] ?? [], true), "manifest.json: <all_urls> (모든 사이트 범용)");

    // 11-7. popup.js 가 Netscape 헤더/필드를 생성하는지
    $pjs = file_get_contents("$extDir/popup.js");
    check(strpos($pjs, '# Netscape HTTP Cookie File') !== false, 'popup.js: Netscape 헤더 생성');
    check(strpos($pjs, 'chrome.cookies.getAll') !== false, 'popup.js: chrome.cookies.getAll 사용');
    check(strpos($pjs, 'SERVICE_MAP') !== false, 'popup.js: 서비스 자동 매핑 테이블 포함');
} catch (Throwable $e) {
    check(false, '쿠키 기능 검증 실패: ' . $e->getMessage());
}

// =====================================================================
echo "\n== 12. 국내 OTT 서비스 추가 (v1.5.0: 티빙/웨이브/왓챠/쿠팡) ==\n";
// =====================================================================
try {
    $svcDir = __DIR__ . '/../vinetrimmer/services';
    $cfgDir = __DIR__ . '/../vinetrimmer/config/services';
    $newServices = ['tving', 'wavve', 'watcha', 'coupang'];

    // 12-1. 서비스 .py 파일 + .yml config 존재
    foreach ($newServices as $svc) {
        check(file_exists("$svcDir/$svc.py"), "services/$svc.py 존재");
        check(file_exists("$cfgDir/$svc.yml"), "config/services/$svc.yml 존재");
    }

    // 12-2. 각 서비스 .py 가 BaseService 상속 + super().__init__ 패턴(자동등록 호환)
    foreach ($newServices as $svc) {
        $code = file_get_contents("$svcDir/$svc.py");
        check(strpos($code, 'BaseService') !== false, "$svc.py: BaseService 상속");
        check(preg_match('/super\(\)\.__init__\(/', $code) === 1, "$svc.py: super().__init__ 패턴(자동등록 호환)");
        check(strpos($code, 'license_supported') !== false || strpos($code, '미지원') !== false,
              "$svc.py: DRM 라이선스 미지원 정직 고지");
    }

    // 12-3. 교차 대조로 확정된 핵심 상수 존재 (TVING/WAVVE)
    $tv = file_get_contents("$svcDir/tving.py");
    check(strpos($tv, '1e7952d0917d6aab1f0293a063697610') !== false, 'tving.py: 교차대조 확정 APIKEY');
    check(strpos($tv, 'api.tving.com') !== false, 'tving.py: api.tving.com 엔드포인트');
    check(strpos($tv, '/v3/media/stream/info') !== false, 'tving.py: stream/info 엔드포인트');

    $wv = file_get_contents("$svcDir/wavve.py");
    check(strpos($wv, 'apis.wavve.com') !== false, 'wavve.py: apis.wavve.com 엔드포인트');
    check(strpos($wv, 'credential') !== false, 'wavve.py: credential 인증');
    check(strpos($wv, 'partner') !== false, 'wavve.py: partner=pooq 공통 파라미터');

    // 12-4. WATCHA/COUPANG 단일 소스 핵심 상수
    $wc = file_get_contents("$svcDir/watcha.py");
    check(strpos($wc, 'api-mars.watcha.com') !== false, 'watcha.py: api-mars.watcha.com 엔드포인트');
    $cp = file_get_contents("$svcDir/coupang.py");
    check(strpos($cp, 'coupangplay.com') !== false, 'coupang.py: coupangplay.com 엔드포인트');
    check(strpos($cp, '/api/playback/play') !== false, 'coupang.py: playback/play 엔드포인트');

    // 12-5. runner.py --service choices 에 4개 포함
    $runner = file_get_contents(__DIR__ . '/../runner.py');
    foreach ($newServices as $svc) {
        check(strpos($runner, "'$svc'") !== false, "runner.py: --service choices 에 '$svc' 포함");
    }

    // 12-6. loader 화이트리스트에 4개 포함
    $loader = file_get_contents(__DIR__ . '/../includes/class-vt-loader.php');
    foreach ($newServices as $svc) {
        check(strpos($loader, "'$svc'") !== false, "class-vt-loader.php: sanitize_service 화이트리스트에 '$svc'");
    }

    // 12-7. admin cookie_services() + select 에 4개 포함
    $admin = file_get_contents(__DIR__ . '/../includes/class-vt-admin.php');
    foreach ($newServices as $svc) {
        check(substr_count($admin, "'$svc'") >= 1 || strpos($admin, "value=\"$svc\"") !== false,
              "class-vt-admin.php: '$svc' 서비스 UI/쿠키 등록");
    }
    check(strpos($admin, '국내 OTT') !== false, "class-vt-admin.php: 국내 OTT optgroup 라벨");

    // 12-8. config.json 에 4개 서비스 블록 + cross_referenced 플래그
    $cfg = json_decode(file_get_contents(__DIR__ . '/../config.json'), true);
    foreach ($newServices as $svc) {
        check(isset($cfg['services'][$svc]), "config.json: services.$svc 블록 존재");
    }
    check(($cfg['services']['tving']['cross_referenced'] ?? false) === true, 'config.json: tving 교차대조 플래그');
    check(($cfg['services']['watcha']['cross_referenced'] ?? true) === false, 'config.json: watcha 단일소스 플래그');

    // 12-9. 크롬 확장 SERVICE_MAP/OPTIONS 에 4개 도메인
    $pjs2 = file_get_contents(__DIR__ . '/../chrome-extension/popup.js');
    foreach ($newServices as $svc) {
        check(strpos($pjs2, "slug: '$svc'") !== false, "popup.js: SERVICE 목록에 '$svc'");
    }
    check(strpos($pjs2, 'coupangstreaming') !== false, 'popup.js: coupang 도메인 매칭 키워드');

    // 12-10. v1.5.1 교차대조 보강 근거 반영 검증
    // WAVVE 3중 확인: AdGuard fz/streaming 경로 + source_count
    check(strpos($wv, 'AdGuard') !== false || strpos($wv, 'fz/streaming') !== false,
          'wavve.py: 제3소스(AdGuard fz/streaming) 근거 기록');
    $wvYml = file_get_contents("$cfgDir/wavve.yml");
    check(strpos($wvYml, 'fz_streaming') !== false || strpos($wvYml, 'fz/streaming') !== false,
          'wavve.yml: fz_streaming 경로 추가');
    check(strpos($wvYml, 'source_count') !== false, 'wavve.yml: source_count 명시');

    // TVING 보강 근거(AdGuard/Colab/VT-PR)
    check(strpos($tv, 'AdGuard') !== false || strpos($tv, 'colab') !== false
          || strpos($tv, 'VT-PR') !== false, 'tving.py: 보강 소스(AdGuard/Colab/VT-PR) 기록');

    // WATCHA/COUPANG 2차 소스 재탐색 결과(단일 소스 재확인)
    check(strpos($wc, '재탐색') !== false || strpos($wc, 'VT-PR') !== false,
          'watcha.py: 2차 소스 재탐색 결과 기록');
    check(strpos($cp, '재탐색') !== false || strpos($cp, 'PoC') !== false
          || strpos($cp, 'VT-PR') !== false, 'coupang.py: 2차 소스 재탐색 결과 기록');

    // config.json source_count 반영
    check(($cfg['services']['wavve']['source_count'] ?? 0) === 3, 'config.json: wavve source_count=3');
    check(($cfg['services']['tving']['source_count'] ?? 0) === 2, 'config.json: tving source_count=2');
    check(($cfg['services']['watcha']['source_count'] ?? 0) === 1, 'config.json: watcha source_count=1');
    check(($cfg['services']['coupang']['source_count'] ?? 0) === 1, 'config.json: coupang source_count=1');
} catch (Throwable $e) {
    check(false, '국내 OTT 서비스 검증 실패: ' . $e->getMessage());
}

echo "\n";
if ($fail === 0) {
    echo "🎉 모든 통합 검증 통과 (0 실패)\n";
    exit(0);
} else {
    echo "⚠️  $fail 개 검증 실패\n";
    exit(1);
}
