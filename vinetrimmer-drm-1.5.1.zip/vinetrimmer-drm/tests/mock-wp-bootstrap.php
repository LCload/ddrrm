<?php
/**
 * WordPress 함수 목(mock) 구현 — 플러그인을 실제 WP 없이 로드/테스트하기 위한 하네스.
 * 이 파일은 배포 패키지에 포함되지 않으며 오직 CI/로컬 검증 용도이다.
 */

error_reporting(E_ALL);
ini_set('display_errors', '1');

if (!defined('ABSPATH'))       define('ABSPATH', sys_get_temp_dir() . '/wp/');
if (!defined('WP_CONTENT_DIR')) define('WP_CONTENT_DIR', sys_get_temp_dir() . '/wp/wp-content');
if (!defined('WPINC'))          define('WPINC', 'wp-includes');
if (!defined('HOUR_IN_SECONDS')) define('HOUR_IN_SECONDS', 3600);
if (!defined('DAY_IN_SECONDS'))  define('DAY_IN_SECONDS', 86400);
if (!defined('WP_PLUGIN_DIR'))   define('WP_PLUGIN_DIR', dirname(__DIR__, 1));

@mkdir(WP_CONTENT_DIR . '/uploads/vinetrimmer', 0755, true);
@mkdir(WP_CONTENT_DIR . '/logs', 0755, true);

// ---- 훅 레지스트리 (중복 등록 검출용) -------------------------------------
$GLOBALS['__actions'] = array();
$GLOBALS['__filters'] = array();
$GLOBALS['__options'] = array();
$GLOBALS['__transients'] = array();

function add_action($hook, $cb, $prio = 10, $args = 1) {
    $key = is_array($cb) ? (is_object($cb[0]) ? get_class($cb[0]) : $cb[0]) . '::' . $cb[1] : (is_string($cb) ? $cb : 'closure');
    $GLOBALS['__actions'][$hook][] = $key;
    // 콜백 자체도 저장하여 테스트에서 특정 훅을 발화할 수 있도록 함
    $GLOBALS['__action_cbs'][$hook][] = $cb;
    return true;
}
/** 테스트 전용: 특정 훅에 등록된 모든 콜백을 실행 */
function __fire_action($hook) {
    if (empty($GLOBALS['__action_cbs'][$hook])) return;
    foreach ($GLOBALS['__action_cbs'][$hook] as $cb) {
        if (is_callable($cb)) { call_user_func($cb); }
    }
}
function add_filter($hook, $cb, $prio = 10, $args = 1) {
    $key = is_array($cb) ? (is_object($cb[0]) ? get_class($cb[0]) : $cb[0]) . '::' . $cb[1] : (is_string($cb) ? $cb : 'closure');
    $GLOBALS['__filters'][$hook][] = $key;
    return true;
}
function do_action($hook, ...$a) { return true; }
function apply_filters($hook, $v, ...$a) { return $v; }
function register_activation_hook($f, $cb) {}
function register_deactivation_hook($f, $cb) {}

function add_menu_page(...$a) { $GLOBALS['__actions']['__menu_pages'][] = $a[3]; return true; }
function add_submenu_page(...$a) { $GLOBALS['__actions']['__submenu_pages'][] = $a[4]; return true; }

function plugin_dir_path($f) { return rtrim(dirname($f), '/') . '/'; }
function plugin_dir_url($f)  { return 'http://example.test/wp-content/plugins/vinetrimmer-drm/'; }
function plugin_basename($f) { return 'vinetrimmer-drm/' . basename($f); }
function content_url($p = '') { return 'http://example.test/wp-content/' . ltrim($p, '/'); }
function admin_url($p = '')   { return 'http://example.test/wp-admin/' . ltrim($p, '/'); }
function trailingslashit($s)  { return rtrim($s, '/\\') . '/'; }
function wp_mkdir_p($d)       { return is_dir($d) || mkdir($d, 0755, true); }

function add_option($k, $v = '')    { if (!isset($GLOBALS['__options'][$k])) $GLOBALS['__options'][$k] = $v; return true; }
function update_option($k, $v)      { $GLOBALS['__options'][$k] = $v; return true; }
function get_option($k, $d = false) { return $GLOBALS['__options'][$k] ?? $d; }
function delete_option($k)          { unset($GLOBALS['__options'][$k]); return true; }
function delete_site_option($k)     { return true; }

function set_transient($k, $v, $t = 0) { $GLOBALS['__transients'][$k] = $v; return true; }
function get_transient($k)             { return $GLOBALS['__transients'][$k] ?? false; }
function delete_transient($k)          { unset($GLOBALS['__transients'][$k]); return true; }

function wp_next_scheduled($h, $a = array()) { return false; }
function wp_schedule_event($t, $r, $h, $a = array()) { return true; }
function wp_schedule_single_event($t, $h, $a = array()) { return true; }
function wp_unschedule_event($t, $h, $a = array()) { return true; }
function wp_clear_scheduled_hook($h, $a = array()) { return true; }
function _get_cron_array() { return array(); }

function current_time($t) { return $t === 'timestamp' ? time() : date('Y-m-d H:i:s'); }
function current_user_can($c) { return true; }
function wp_die($m = '') { throw new RuntimeException('wp_die: ' . $m); }
function esc_html($s) { return htmlspecialchars((string)$s, ENT_QUOTES); }
function esc_attr($s) { return htmlspecialchars((string)$s, ENT_QUOTES); }
function esc_url($s)  { return $s; }
function esc_url_raw($s) { return $s; }
function esc_js($s)  { return $s; }
function sanitize_text_field($s) { return trim(strip_tags((string)$s)); }
function sanitize_file_name($s)  { return preg_replace('/[^A-Za-z0-9._-]/', '', (string)$s); }
function wp_unslash($s) { return is_string($s) ? stripslashes($s) : $s; }
function selected($a, $b) { echo $a == $b ? ' selected' : ''; }
function submit_button($t = '', $type = 'primary', $name = 'submit') { echo '<button name="' . esc_attr($name) . '">' . esc_html($t) . '</button>'; }
function wp_nonce_field($a = -1, $n = '_wpnonce', $r = true, $e = true) { echo '<input type="hidden" name="' . esc_attr($n) . '" value="nonce">'; }
function wp_create_nonce($a = -1) { return 'nonce'; }
function wp_nonce_url($url, $a = -1, $n = '_wpnonce') { return $url . '&' . $n . '=nonce'; }
function check_admin_referer($a = -1, $n = '_wpnonce') { return true; }
function check_ajax_referer($a = -1, $n = false, $die = true) { return true; }
function wp_enqueue_style(...$a) {}
function wp_enqueue_script(...$a) {}
function wp_localize_script(...$a) {}
function wp_redirect($u, $s = 302) { return true; }
function wp_safe_redirect($u, $s = 302) { return true; }
function wp_get_referer() { return 'http://example.test/wp-admin/admin.php?page=vinetrimmer-drm'; }
function add_query_arg($args, $url = '') { return $url . '?' . http_build_query($args); }
function size_format($b, $d = 0) { return round($b / 1048576, $d) . ' MB'; }
function date_i18n($f, $t) { return date($f, $t); }
function register_setting(...$a) {}
function load_plugin_textdomain(...$a) { return true; }
function __($s, $d = 'default') { return $s; }
function is_multisite() { return false; }
function is_wp_error($t) { return false; }
function wp_upload_dir() { return array('path' => WP_CONTENT_DIR . '/uploads', 'url' => 'http://example.test/wp-content/uploads'); }
function wp_check_filetype($f, $m = null) {
    $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
    $map = array('mp4' => 'video/mp4', 'mkv' => 'video/x-matroska', 'webm' => 'video/webm', 'ts' => 'video/mp2t', 'm4v' => 'video/x-m4v');
    return array('ext' => isset($map[$ext]) ? $ext : false, 'type' => $map[$ext] ?? false);
}
function wp_insert_attachment(...$a) { return 1; }
function wp_generate_attachment_metadata(...$a) { return array(); }
function wp_update_attachment_metadata(...$a) { return true; }
function wp_delete_attachment(...$a) { return true; }
