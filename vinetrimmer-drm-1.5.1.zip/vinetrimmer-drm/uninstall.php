<?php
/**
 * Vinetrimmer Playready DRM Tool - Uninstall Handler
 * 
 * 이 파일은 WordPress 플러그인 삭제 시 자동으로 실행됩니다.
 * 모든 데이터, 옵션, 생성된 파일 및 디렉토리를 안전하게 제거합니다.
 *
 * @package Vinetrimmer_DRM
 * @author Bread & Sonion
 * @version 1.5.1
 */

// 직접 접근 차단: WordPress가 아닌 환경에서 실행 방지
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// =========================================================================
// 1. 상수 재정의 (플러그인 루트 경로)
// =========================================================================
define('VT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('VT_OUTPUT_DIR', WP_CONTENT_DIR . '/uploads/vinetrimmer/');
define('VT_LOG_DIR', WP_CONTENT_DIR . '/logs/');

// =========================================================================
// 2. 데이터베이스 옵션 삭제
// =========================================================================
delete_option('vt_quality_default');
delete_option('vt_service_default');
delete_option('vt_sub_lang_default');
delete_option('vt_sub_mode_default');
delete_option('vt_version');
delete_option('vt_installed_time');

// 다중 사이트에서도 옵션 삭제 (네트워크 활성화 시)
if (is_multisite()) {
    delete_site_option('vt_quality_default');
    delete_site_option('vt_service_default');
    delete_site_option('vt_sub_lang_default');
    delete_site_option('vt_sub_mode_default');
}

// =========================================================================
// 3. 생성된 디렉토리 및 파일 삭제 (재귀적)
// =========================================================================
function vt_recursive_remove($dir) {
    if (!file_exists($dir)) {
        return true;
    }
    if (!is_dir($dir)) {
        return unlink($dir);
    }
    $items = scandir($dir);
    if ($items === false) {
        return false;
    }
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path)) {
            vt_recursive_remove($path);
        } else {
            @unlink($path);
        }
    }
    return @rmdir($dir);
}

// 출력 디렉토리 (모든 다운로드 파일 및 임시 폴더) 삭제
if (defined('VT_OUTPUT_DIR') && file_exists(VT_OUTPUT_DIR)) {
    vt_recursive_remove(VT_OUTPUT_DIR);
}

// 로그 디렉토리 삭제 (로그 파일 포함)
if (defined('VT_LOG_DIR') && file_exists(VT_LOG_DIR)) {
    vt_recursive_remove(VT_LOG_DIR);
}

// =========================================================================
// 4. 가상환경 디렉토리 삭제 (선택적 - 사용자 데이터로 간주되지 않음)
//      주석 해제하면 venv 폴더도 삭제됨
// =========================================================================
/*
$venv_dir = VT_PLUGIN_DIR . 'venv';
if (file_exists($venv_dir)) {
    vt_recursive_remove($venv_dir);
}
*/

// =========================================================================
// 5. 추가 정리: cron 작업, 임시 파일 등
// =========================================================================
// 백그라운드 예약 작업 제거
wp_clear_scheduled_hook('vt_background_run');

// 크론 작업으로 등록된 모든 vt_ 접두어 이벤트 제거
$crons = _get_cron_array();
if (!empty($crons)) {
    foreach ($crons as $timestamp => $cron) {
        foreach ($cron as $hook => $data) {
            if (strpos($hook, 'vt_') === 0) {
                wp_unschedule_event($timestamp, $hook);
            }
        }
    }
}

// =========================================================================
// 6. 사용자 정의 테이블이 있다면 삭제 (현재 없음)
// =========================================================================
// global $wpdb;
// $table_name = $wpdb->prefix . 'vinetrimmer_queue';
// $wpdb->query("DROP TABLE IF EXISTS $table_name");

// =========================================================================
// 7. 완료 메시지 (디버그용, 실제 화면에 표시되지 않음)
// =========================================================================
if (defined('WP_DEBUG') && WP_DEBUG) {
    error_log('[Vinetrimmer] Uninstall completed successfully.');
}