<div align="center">

# 🍞 Vinetrimmer Playready DRM Tool

**WordPress 관리자 대시보드에서 Playready / Widevine 보호 콘텐츠를 다운로드·해독하는 통합 플러그인**

[![Version](https://img.shields.io/badge/version-1.5.1-4f46e5.svg)](#-변경-이력-changelog)
[![WordPress](https://img.shields.io/badge/WordPress-5.8%2B-21759b.svg)](https://wordpress.org)
[![PHP](https://img.shields.io/badge/PHP-7.4%2B-777bb4.svg)](https://php.net)
[![Python](https://img.shields.io/badge/Python-3.9%2B-3776ab.svg)](https://python.org)
[![License](https://img.shields.io/badge/license-GPLv2%2B-green.svg)](#-크레딧--라이선스)

**Netflix** · Disney+ · Amazon Prime Video · Apple TV+ · NOW TV · Hulu · iTunes · Canal+ · Paramount+ · Max(HBO)
**국내 OTT (v1.5.0 신규)**: TVING(티빙) · WAVVE(웨이브) · WATCHA(왓챠) · Coupang Play(쿠팡플레이)

</div>

---

> ⚠️ **법적 고지**
> 이 도구는 **교육·연구 및 DRM 상호운용성 검증** 목적으로만 제공됩니다.
> 반드시 **본인이 합법적으로 접근 권한을 가진 콘텐츠**에 대해서만 사용하십시오.
> 저작권 침해에 대한 책임은 전적으로 사용자에게 있습니다.

---

## ✨ 무엇을 하는 플러그인인가요?

Python 기반 DRM 해독 엔진(**Vinetrimmer**)을 WordPress 백엔드와 연결하여,
관리자가 코드 한 줄 없이 **관리 화면에서 직접** 스트리밍 콘텐츠를 다운로드/해독하고
결과 파일을 **미디어 라이브러리**로 가져올 수 있게 해줍니다.

* 🎬 **14개 스트리밍 서비스** 지원 (**국내 OTT 4종 v1.5.0 신규**: 티빙·웨이브·왓챠·쿠팡플레이)
* 🍪 **로그인 쿠키 업로드/붙여넣기** (v1.4.0 신규) — ID/비밀번호 없이 쿠키만으로 로그인 세션 사용
* 🧩 **범용 쿠키 추출 크롬 확장 프로그램** (v1.4.0 신규) — 모든 사이트에서 Netscape `.txt` 자동 내보내기
* 🌐 **한국어 자막** 우선 처리 (v1.2.0)
* 🎨 **SaaS급 관리자 UI** (v1.2.0 리디자인, v1.3.0 콤보박스 가독성 개선)
* ⚙️ **동기 실행** + **AJAX/WP-Cron 비동기 백그라운드 처리**
* 📦 결과 파일 **미디어 라이브러리 자동 임포트**
* 🔒 `manage_options` 권한 + Nonce + `escapeshellarg` 다중 방어

---

## 🍪 로그인 인증은 어떻게 하나요? (v1.4.0)

스트리밍 사이트는 로그인이 필요하므로, 이 플러그인은 **브라우저 로그인 쿠키**를 사용해
인증합니다. **아이디/비밀번호는 필요 없습니다.**

> **핵심**: Netflix의 경우 `NetflixId` + `SecureNetflixId` 쿠키만 있으면
> 이식된 `netflix.py`의 `configure()`가 `NetflixIDCookies` 인증을 사용합니다.
> ID/PW(`EmailPassword`)는 쿠키가 전혀 없을 때만 쓰이는 폴백입니다.

### 사용 흐름

1. **크롬 확장 프로그램**을 설치합니다. (플러그인과 **별도 zip**으로 배포 —
   `vinetrimmer-cookie-exporter-x.y.z.zip` 압축 해제 후 `chrome://extensions` → 개발자 모드 → 폴더 로드) → [설치법](chrome-extension/README.md)
2. 대상 사이트(Netflix·Disney+·Amazon 등 **어떤 사이트든**)에 **로그인**한 상태에서 확장 아이콘(🍪) 클릭.
3. 확장이 현재 사이트를 자동 감지 → **💾 .txt 다운로드** 또는 **📋 클립보드 복사**.
4. WordPress 관리자 → Vinetrimmer 콘솔 → **🔐 로그인 쿠키 관리** 카드에서
   **파일 업로드** 또는 **텍스트 붙여넣기**.
5. 쿠키는 `vinetrimmer/cookies/<서비스>/default.txt` (Netscape/Mozilla 형식)에 저장되어
   `dl.py`의 `MozillaCookieJar`가 읽습니다.

### 쿠키 관리 카드 기능

| 기능 | 설명 |
|------|------|
| 서비스 선택 | 10개 서비스 각각에 대해 쿠키를 개별 저장 (Netflix 기본) |
| 파일 업로드 | 확장이 만든 `.txt`를 그대로 업로드 (`$_FILES`, Nonce 보호) |
| 텍스트 붙여넣기 | 클립보드 내용을 textarea에 붙여넣기 |
| 형식 검증 | 탭 구분 Netscape 형식인지 검사 후 저장, 헤더 자동 보정 |
| 상태 표시 | 저장 여부·크기·쿠키 개수·수정 시각, Netflix 인증 쿠키(`NetflixId`) 존재 배지 |
| 삭제 | 저장된 쿠키 삭제 |

---

## 📸 관리자 화면 (v1.4.0)

```
┌───────────────────────────────────────────────────────────────┐
│  🍞 Vinetrimmer Playready       [ v1.4.0 ]  [ ⚙ 설정 ]         │  ← 그라디언트 앱바
├───────────────────────────────────────────────────────────────┤
│  [🎬 저장된 파일]  [🌐 기본 자막: 한국어]  [🛡 10개]  [☁ 준비됨]  │  ← KPI 카드
├──────────────────────────────────┬────────────────────────────┤
│  새 다운로드 작업                 │  저장된 파일 (3)            │
│   · 스트리밍 서비스               │   ▸ Loki.S02E01.mp4         │
│   · 콘텐츠 URL                    │   ▸ Andor.S01E12.mkv        │
│   · 화질 / 자막 언어              │        [임포트] [삭제]      │
│   · 자막 처리: (먹싱 | 하드섭 | 없음)                         │
│   [ DRM 해독 & 다운로드 실행 ]    │                            │
│   ▓▓▓▓▓▓▓░░░ 63%                  │                            │
└──────────────────────────────────┴────────────────────────────┘
```

> 반응형: 태블릿(≤1100px)에서 단일 컬럼, 모바일(≤782px)에서 KPI 2×2 재배치, `prefers-color-scheme: dark` 자동 대응.

---

## 📐 아키텍처 개요

```
vinetrimmer-plugin.php   ← 부트스트랩(상수 · 클래스 로드 · 싱글턴 컨테이너 · 활성/비활성 훅)
│
├── includes/
│   ├── class-vt-logger.php        # 통합 로깅(레벨/10MB 로테이션·백업5개/이메일 알림)
│   ├── class-vt-loader.php        # 실행 엔진: 환경검사 + 자막 인자 구성 + shell_exec 안전 래핑
│   ├── class-vt-file-manager.php  # 다운로드 파일 스캔·삭제·미디어 라이브러리 임포트
│   ├── class-vt-admin.php         # 관리자 메뉴·실행 폼·설정·파일 목록 (SaaS UI)
│   └── class-vt-ajax-handler.php  # 비동기 실행(AJAX + WP-Cron)·작업 상태 추적
│
├── runner.py               # PHP → Python 브리지. Vinetrimmer CLI 서브프로세스 실행 + 자막 로직
├── config.json             # CDM/Playready/서비스/다운로드/디코딩/로깅/자막 설정
├── vinetrimmer/            # Python DRM 코어 엔진 (services, parsers, objects, certs …)
├── assets/{css,js,images}  # 관리자 UI 스타일(SaaS 디자인 시스템)·스크립트·아이콘
├── .htaccess               # 민감 파일/디렉토리 웹 접근 차단(자산은 화이트리스트)
├── uninstall.php           # 삭제 시 옵션·파일·크론 정리
└── tests/                  # (개발 전용) WP 목 하네스 기반 통합 검증 스크립트 — 배포 제외
```

### 동작 흐름

```
① 관리자: 서비스 / URL / 화질 / 자막언어 / 자막모드 선택
        │
        ▼
② VT_Admin(동기) 또는 VT_Ajax_Handler(비동기, WP-Cron 'vt_minute')
        │  입력 화이트리스트 검증 + sanitize_sub_lang / sanitize_sub_mode
        ▼
③ VT_Loader::run(service, url, quality, sub_lang, sub_mode)
        │  escapeshellarg 로 안전하게 이스케이프한 명령 구성
        ▼
④ runner.py  --sub-lang <ko> --sub-mode <mux|burn|none>
        │  config.json 'subtitle' 블록 병합(CLI 인자가 우선)
        │  Vinetrimmer CLI --help 파싱으로 지원 플래그 자동 감지
        ▼
⑤ Vinetrimmer CLI 서브프로세스 실행 → 자막 트랙 처리 → 결과 파일 생성
        │
        ▼
⑥ VT_File_Manager: 결과 파일 스캔 → (옵션) 미디어 라이브러리 임포트
```

---

## 🌐 한국어 자막 기능 (v1.2.0 핵심)

관리자 폼과 설정 페이지에서 **자막 언어**와 **처리 방식**을 지정할 수 있으며,
지정하지 않으면 **한국어(`ko`) · 먹싱(`mux`)** 이 기본값으로 적용됩니다.

### 자막 처리 방식 3종

| 모드 | 설명 | 전달되는 CLI 인자 | 폴백 |
|------|------|-------------------|------|
| **`mux`** (기본·권장) | 별도 자막 트랙으로 먹싱하고 지정 언어를 **기본 표시 트랙**으로 설정 | `--slang <lang>` + `--sub-default <lang>` | `--sub-default` 미지원 시 언어 필터만 적용 |
| **`burn`** (하드섭) | 자막을 영상 픽셀에 **직접 굽기** | `--slang <lang>` + `--burn-subs` | `--burn-subs` 미지원 시 자동으로 `mux` 로 폴백 |
| **`none`** | 자막을 **다운로드하지 않음** | `--no-subs` | — |

### CLI 플래그 자동 감지

`runner.py` 의 `_detect_cli_features()` 는 실행 전 `vinetrimmer dl --help` 를 1회 파싱하여
설치된 Vinetrimmer 버전이 `--burn-subs` / `--sub-default` / `--slang` / `--no-subs` 를
지원하는지 확인하고, **미지원 플래그는 자동으로 안전하게 폴백**합니다. (감지 결과는 캐시)

### 설정 우선순위

```
관리자 폼/설정 옵션 (CLI 인자)  >  config.json "subtitle" 블록  >  코드 기본값(ko / mux)
```

```jsonc
// config.json
"subtitle": {
  "default_language": "ko",   // 기본 자막 언어
  "mode": "mux",              // mux | burn | none
  "description": "전역 자막 기본값. runner.py 가 CLI 인자보다 낮은 우선순위로 병합합니다."
}
```

### 입력 검증 (`class-vt-loader.php`)

* `sanitize_sub_lang()` — `all` 또는 `^[a-z]{2,3}$` 언어 코드(콤마 구분, 최대 5개)만 허용. 그 외에는 **`ko` 로 폴백**.
* `sanitize_sub_mode()` — `mux` / `burn` / `none` 화이트리스트. 그 외에는 **`mux` 로 폴백**.

---

## 🎨 SaaS 관리자 UI (v1.2.0 리디자인)

`assets/css/admin-style.css` 를 CSS 커스텀 프로퍼티(디자인 토큰) 기반의
디자인 시스템으로 전면 재작성했습니다.

* 🎨 **디자인 토큰**: `--vt-primary:#4f46e5` 등 색상·radius·shadow 변수화
* 🌈 **그라디언트 앱바** + 버전 배지 + 설정 바로가기
* 📊 **KPI 통계 카드** 4종(저장 파일 수 · 기본 자막 언어 · 지원 서비스 · 실행 엔진 상태)
* 🧩 **카드형 레이아웃** + `1.5fr / 1fr` 반응형 그리드
* 🔘 **세그먼트 컨트롤**(자막 처리 방식 라디오)
* 📈 **그라디언트 진행률 바** + 퍼센트 표시(AJAX 연동)
* 🌙 **다크 모드**(`prefers-color-scheme: dark`) 자동 대응
* 📱 **반응형 브레이크포인트**: 1100 / 782 / 480px

> 모든 아이콘은 WordPress 내장 **Dashicons** 를 사용하므로 외부 폰트 로드가 필요 없습니다.

---

## 🚀 설치

1. `vinetrimmer-drm` 폴더를 `/wp-content/plugins/` 에 업로드합니다.
2. WordPress **플러그인** 메뉴에서 활성화합니다.
3. 사이드바의 **Vinetrimmer** 메뉴로 이동합니다.
4. 플러그인 디렉토리의 `config.json` 에서 CDM/Playready 인증서 경로 및 디코딩 도구 경로를 설정합니다.
5. Python 3.9+ 가상환경(`venv/`)에 Vinetrimmer 를 설치합니다 (`poetry install`).

### 요구 사항

| 항목 | 최소 사양 |
|------|-----------|
| WordPress | 5.8+ |
| PHP | 7.4+ (8.x 호환) |
| Python | 3.9+ |
| 외부 도구 | FFmpeg, mp4decrypt, shaka-packager(packager), mkvmerge |
| 서버 | `shell_exec()` 허용 (VPS / 전용 서버 권장) |

---

## 🖥️ 기능 진입점 (URI / 액션)

| 유형 | 경로 / 액션 | 파라미터 | 설명 |
|------|-------------|----------|------|
| 관리자 페이지 | `wp-admin/admin.php?page=vinetrimmer-drm` | — | 실행 폼 + 파일 목록 |
| 관리자 페이지 | `wp-admin/admin.php?page=vinetrimmer-drm-settings` | — | 기본 서비스/화질/**자막 정책** 설정 |
| POST(실행) | 위 메인 페이지에 POST | `vt_service`, `vt_url`, `vt_quality`, `vt_sub_lang`, `vt_sub_mode`, `vt_nonce` | 동기 실행 |
| AJAX | `admin-ajax.php?action=vt_run_async` | `service`, `url`, `quality`, `sub_lang`, `sub_mode` | 비동기 실행 등록 |
| AJAX | `admin-ajax.php?action=vt_check_status` | `job_id` | 작업 진행률 폴링 |
| AJAX | `admin-ajax.php?action=vt_cancel_job` | `job_id` | 작업 취소 |
| POST 액션 | `admin-post.php?action=vt_delete_file&file=…` | `file`, `vt_nonce` | 파일 삭제 |
| POST 액션 | `admin-post.php?action=vt_import_file&file=…` | `file`, `vt_nonce` | 미디어 라이브러리 임포트 |

> 모든 요청은 `manage_options` 권한 + Nonce 검증으로 보호됩니다.

### `runner.py` CLI 인자

```bash
python runner.py <service> <url> \
  --quality best \
  --sub-lang ko \          # 자막 언어 (기본 ko, 'all' 또는 콤마 구분)
  --sub-mode mux \         # mux | burn | none (기본 mux)
  --config /path/config.json
```

---

## 🗂️ 데이터 / 저장

| 항목 | 위치 / 키 |
|------|-----------|
| 다운로드 파일 | `/wp-content/uploads/vinetrimmer/` |
| 로그 | `/wp-content/logs/vinetrimmer.log` (10MB 로테이션, 백업 5개) |
| 설정(옵션) | `vt_service_default`, `vt_quality_default`, **`vt_sub_lang_default`**, **`vt_sub_mode_default`**, `vt_version`, `vt_installed_time` |
| 작업 상태 | WordPress Transient (`vt_job_{id}`, 24시간 유지) |
| 크론 스케줄 | 커스텀 `vt_minute` (60초 하트비트) |

> 신규 옵션(`vt_sub_lang_default`, `vt_sub_mode_default`)은 활성화 시 등록되고 삭제 시 정리됩니다(멀티사이트 포함).

---

## 🧪 개발자 검증

WordPress 없이도 부트스트랩 · 훅 등록 · 클래스 인스턴스화 · **자막 기능**을 검증합니다.

```bash
php tests/run-integration-test.php
```

검증 항목(요약):
* 상수/클래스 로드, 싱글턴 무결성
* 훅 **중복 등록 방지**(메뉴/AJAX/크론 각 1회)
* `vt_minute` 크론 스케줄 등록
* **자막**: `run()` 시그니처(`sub_lang`/`sub_mode`), `sanitize_sub_lang`/`sanitize_sub_mode` 폴백
* `config.json` 자막 정책(`subtitle.default_language=ko`, `mode=mux`)

> `tests/` 디렉토리는 배포 패키지에 포함되지 않습니다(개발 전용).

추가 검증:
```bash
python3 -m py_compile runner.py         # Python 문법
python3 runner.py --help                # --sub-lang / --sub-mode 확인
node --check assets/js/admin-script.js  # 프런트 스크립트 문법
php -l includes/*.php                    # PHP 문법
```

---

## 📝 변경 이력 (Changelog)

### 1.5.1 (현재) — 4개 OTT 웹/GitHub 자료 추가 정밀 수집 & 교차 대조 보강

사용자 요청("다른 웹사이트에서도 데이터를 확보가능할지 모르니 아주 더 세밀하게 더 웹데이터를 취합")에 따라 4개 OTT의 추가 독립 소스를 정밀 재조사하고, 검증 결과를 코드/설정/문서에 정직하게 반영했습니다. **기능(엔드포인트) 자체는 그대로이며, 근거(신뢰도)만 보강**되었습니다.

**🔎 추가로 확보한 교차 대조 근거**
- **WAVVE → 2중 → 3중 확인(HIGH)**: 제3의 독립 소스인 **AdGuard 공개 필터리스트**의 규칙 `@@||apis.wavve.com/fz/streaming$domain=wavve.com` 이 `apis.wavve.com` 스트리밍 API 도메인/경로(`/fz/streaming`)를 재확인. → `wavve.yml` 에 `fz_streaming` 경로 및 `source_count: 3` 추가.
- **TVING → 보강(HIGH 유지)**: AdGuard 필터(`@@||tving.com^`)가 도메인을 제3소스로 확인. 추가로 `ilysnemo/tving-colab-downloader`(공개 Colab)가 **streamlink 위임 방식**임을 확인 — "국내 OTT는 DRM을 외부 CDM/프록시에 위임한다"는 본 프로젝트의 아키텍처 결론을 뒷받침(반대 근거 아님).
- **상류 프로젝트 대조**: 본 프로젝트가 기반한 **`chu23465/VT-PR`(VineTrimmer-PlayReady)** 의 지원 서비스 목록(AMZN·ATVP·DSNP·HS·HULU·iT·MAX·PCOK 등)에 **국내 OTT 4종이 전혀 없음**을 확인 → 검증된 국내 OTT VineTrimmer 서비스 구현이 공개적으로 부재함을 입증.

**🟡 단일 소스 재확인 (WATCHA / Coupang Play)**
- `"api-mars.watcha.com"`, `"coupangstreaming.com"` 등으로 GitHub·Google·AdGuard/EasyList를 재조사했으나 **API를 문서화한 제2의 독립 기술 소스는 0건**.
- Coupang의 공개 자료(flywithu.com / LinkedIn "PoC – DRM video Dump from Coupang Play", 2024)는 **안드로이드 코덱 입력 덤프(FakeCodec)** 방식의 PoC로, **재생/라이선스 API 엔드포인트 정보를 담고 있지 않음** → 오히려 self-contained CDM 취득이 어렵다는 DRM 미지원 판단을 뒷받침.
- 결론: 두 서비스의 **단일 소스(MEDIUM-LOW) 판단이 정확**하며, 실사용 검증 필요를 명시 유지.

**📄 반영 파일**
- `services/{tving,wavve,watcha,coupang}.py` — docstring에 신뢰도 등급(HIGH/MEDIUM-LOW), 신규 근거(AdGuard·Colab·VT-PR), "2차 소스 재탐색 결과" 기록.
- `config/services/*.yml` — `cross_referenced`/`source_count` 명시(tving=2, wavve=3, watcha=1, coupang=1), wavve에 `fz_streaming` 경로 추가.
- `config.json` — 4개 서비스 `note` 갱신 + `source_count` 추가.
- 통합 테스트 통과(147+), 버전 1.5.0 → **1.5.1**.

> 요약: **없는 근거를 지어내지 않고**, 확보 가능한 모든 공개 자료를 재수집하여 WAVVE는 3중, TVING은 보강 확인으로 확실도를 높였고, WATCHA/Coupang은 (그럼에도) 단일 소스임을 정직하게 재확인했습니다.

### 1.5.0 — 국내 OTT 4종 추가 (티빙·웨이브·왓챠·쿠팡플레이), 교차 대조 기반

**🇰🇷 국내 OTT 서비스 추가 (GitHub/웹 자료 교차 대조 후 이식)**

> **정직 고지 — 어디까지 "확실"한가**
> 국내 OTT는 오픈소스가 대부분 **Kodi 애드온(프록시 + `inputstream.adaptive` 내장 CDM 의존)** 형태라, DRM 복호화(라이선스 키 취득) 로직이 애드온 자체에 없습니다.
> 따라서 본 버전은 **로그인/인증 + 메타데이터/스트림 정보 조회까지를 "확실히" 구현**하고, **실제 DRM 라이선스 취득(`license()`)은 미지원으로 명확히 표기**했습니다. (근거 없는 추측 구현은 하지 않음)

- **교차 대조로 확실도를 높인 서비스 (2개 이상 독립 구현체 대조):**
  - **TVING(티빙)** — `kym1088/tvingM`(v3 API) ↔ `shevious/tving`(v1 API) 대조. 두 소스 모두 **동일 APIKEY `1e7952d0917d6aab1f0293a063697610`**, 동일 코드값(`CSSD0100`/`CSND0900`/`CSOD0900`/`CSCD0900`), 동일 로그인 도메인(`user.tving.com`/`www.tving.com`), `api.tving.com/v3/media/stream/info`, PlayReady(`dev.drm=pr`/`SL3000`) 확인.
  - **WAVVE(웨이브)** — `kym1088/wavveM`(난독화) ↔ `yun-s-oh/wavve`(비난독화) 대조. 두 소스 모두 **`apis.wavve.com` + `credential` 인증**, 공통 파라미터(`device=pc`/`partner=pooq`/`region=kor`/`drm=wm`), 로그인 `apis.wavve.com/login` 확인. ⚠️ APIKEY는 클라이언트별로 상이(`6A87…`/`E5F3…`) — 정직하게 두 값 모두 기록.
- **단일 소스 확인 서비스 (교차 대조용 2차 구현체를 찾지 못함 → 확실도 상대적으로 낮음, 정직 기록):**
  - **WATCHA(왓챠)** — `kym1088/watchaM`(난독화)에서만 확인. `api-mars.watcha.com`, 쿠키 `watcha_token`/`_guinness-premium_session`.
  - **Coupang Play(쿠팡플레이)** — `kym1088/coupangM`(난독화)에서만 확인. `coupangplay.com/api/auth`(로그인), `/api/playback/play`(재생, PlayReady `com.microsoft.playready` + Widevine `license_url`).

**추가/수정 파일**
- `vinetrimmer/services/{tving,wavve,watcha,coupang}.py`(신규) — 각 `BaseService` 이식. 인증/메타데이터/스트림정보 조회 구현, `license()`는 미지원 안내.
- `vinetrimmer/config/services/{tving,wavve,watcha,coupang}.yml`(신규) — 확정 엔드포인트/APIKEY/코드값. `cross_referenced`·`license_supported` 플래그로 확실도 명시.
- `config.json` — `services`에 4개 블록 추가(교차대조/단일소스 여부 `note`에 기록).
- WordPress 배선: `class-vt-admin.php` 실행/설정 폼 `<select>` 2곳에 **국내 OTT `optgroup`** 추가 + `cookie_services()`에 4종 추가, `class-vt-loader.php` `sanitize_service()` 화이트리스트, `runner.py` `--service` choices 확장.
- 크롬 확장 `popup.js` — `SERVICE_MAP`/`SERVICE_OPTIONS`에 `tving`/`wavve`/`watcha`/`coupang` 도메인 매핑 추가(`coupangstreaming` 포함).
- 통합 테스트 **Section 12** 추가(신규 서비스 .py/.yml 존재, 자동등록 패턴, 교차대조 상수, WordPress 배선, config/확장 반영) — **전 항목 통과**.
- 버전 1.4.0 → **1.5.0** 전체 반영.

### 1.4.0 — 로그인 쿠키 업로드/붙여넣기 + 범용 크롬 확장 프로그램

**🍪 관리자 UI 쿠키 관리 카드 추가 (`class-vt-admin.php`)**
- 메인 콘솔에 **🔐 로그인 쿠키 관리** 카드 신설. 스트리밍 사이트 로그인 세션을 **ID/PW 없이** 쿠키만으로 사용할 수 있게 함.
- **두 가지 입력 방식**:
  - **파일 업로드** — 크롬 확장이 만든 `.txt`를 `$_FILES`로 수신.
  - **텍스트 붙여넣기** — textarea에 쿠키 원문을 붙여넣기(탭 구분 보존을 위해 `wp_unslash`만 적용).
- **10개 전 서비스 지원**: 대상 서비스를 선택해 각각 `vinetrimmer/cookies/<서비스>/default.txt`에 개별 저장.
- **보안**: `current_user_can('manage_options')` + Nonce(`vt_cookie_save`/`vt_cookie_delete`) + 서비스명 정규화(경로 인젝션 `../` 차단) + 파일 권한 `0600`.
- **형식 검증**: 탭 구분 Netscape/Mozilla 형식인지 `is_valid_netscape_cookie()`로 검사 후 저장. `# Netscape HTTP Cookie File` 헤더가 없으면 자동 추가, 개행(LF) 정규화 → `dl.py`의 `MozillaCookieJar`가 확실히 읽도록 보정.
- **상태 표시**: 저장 여부·용량·쿠키 개수·수정 시각을 배너로 표시하고, Netflix의 경우 `NetflixId`/`SecureNetflixId` 존재 여부를 **배지**로 안내(“ID/PW 불필요” 또는 “인증 쿠키 미검출”). 쿠키 삭제 버튼 제공.
- 백엔드 훅: `admin_post_vt_cookie_save`, `admin_post_vt_cookie_delete` 등록. 처리 결과는 `?cookie=saved|deleted|empty|invalid|missing_auth|writefail`로 리다이렉트되어 관리자 알림으로 표시.
- **탭 전환 JS**(`admin-script.js`) + **카드 스타일 CSS**(`admin-style.css`, 다크모드 대응) 추가.

**🧩 범용 쿠키 추출 크롬 확장 프로그램 (`chrome-extension/`, MV3)**
- 특정 사이트에 종속되지 않는 **범용** 구조: 현재 활성 탭의 도메인을 자동 감지하고 그 도메인의 쿠키를 추출 → 목록에 없는 사이트도 “직접 입력”으로 저장 가능(`<all_urls>` 호스트 권한).
- **서비스 자동 매핑**(`SERVICE_MAP`): 도메인을 보고 Vinetrimmer 슬러그(`netflix`/`disney`/`amzn`…)를 자동 제안. 표준 목록 10종 + 직접 입력 드롭다운.
- **표준 Netscape 출력**: `# Netscape HTTP Cookie File` 헤더 + 탭 구분 7필드(domain/includeSub/path/secure/expiry/name/value). `MozillaCookieJar`뿐 아니라 `yt-dlp`·`curl` 등 다른 도구와도 호환.
- **쿠키 범위** 선택(현재 도메인 / 서브도메인 포함), **💾 .txt 다운로드**(`<슬러그>_default.txt`) 또는 **📋 클립보드 복사**. 컴팩트한 팝업 UI(`popup.html`/`popup.css`/`popup.js`) + 아이콘(16/48/128).
- 쿠키는 **외부 전송 없이** 로컬 다운로드/클립보드로만 처리.

**🧪 검증**
- 통합 테스트에 **쿠키 기능 검증 섹션(Section 11)** 추가: admin_post 훅 등록, 필수 메서드 존재, 10개 서비스 지원, 쿠키 경로/인젝션 방지, Netscape 검증기, 확장 파일 존재, manifest MV3/`cookies`/`<all_urls>`, popup.js Netscape 헤더·`chrome.cookies.getAll`·서비스 매핑 — **전 항목 통과**.
- PHP `-l`(전 파일) · `py_compile` · `node --check`(admin-script.js, popup.js) · JSON(manifest) 전부 통과.
- 내부 `@version` 태그 및 `VT_VERSION` 을 **1.4.0** 으로 통일.

### 1.3.0 — Netflix 지원 + 콤보박스 가독성 수정

**🎬 Netflix 서비스 추가 (GitHub 코드 심층 분석 후 이식)**
- 오픈소스(`Playreadydrm/Netflix-Playready-Tool`)의 Netflix 서비스 코드를 확보하여 **코드 레벨로 심층 분석**하고, 본 프로그램(**PlayReady fork**)에 맞게 **이식(포팅)**.
- 원본은 **Widevine 기반**(`vinetrimmer.utils.widevine.device.LocalDevice`, `CHROME`/`ANDROID` 타입, `system_id`)이었으나, 본 fork 는 `vinetrimmer.utils.playready.Device`/`Cdm` 을 사용하고 해당 속성이 존재하지 않음 → 아래와 같이 호환 이식:
  - **키 교환(Key Exchange)**: 항상 `AsymmetricWrapped` 스킴 사용. RSA 키쌍을 자체 생성하므로 Widevine CDM 없이도 **MSL(Message Security Layer) 핸드셰이크**가 성립 → PlayReady CDM 과 완전 호환.
  - **사용자 인증(User Auth)**: 브라우저 쿠키(`NetflixId`/`SecureNetflixId`) 기반 `NetflixIDCookies` 스킴 기본, 자격증명만 있을 땐 `EmailPassword` 폴백.
  - **ESN**: `chrome_esn_generator()` 기본 사용. `netflix.yml` 의 `esn_map` 에 값을 넣으면 우선 적용(4K용 Shield ESN 등 수동 지정 가능).
  - **device 식별자**: 원본의 `system_id` → PlayReady 에 없으므로 `Device.get_name()`/`security_level` 기반 식별자(`_device_cache_id()`)로 대체(MSL 캐시 키에 사용).
- 원본 코드의 **버그 수정**: `configure()` 의 `sel.log.info(...)` 오타 → `self.log.info(...)`.
- `vinetrimmer/services/netflix.py`(신규) — `Netflix(BaseService)`, `ALIASES=["NF","netflix"]`, `get_titles`/`get_tracks`/`get_chapters`/`certificate`/`license`/`get_manifest`/`manifest_as_tracks` 등 전체 이식.
- `vinetrimmer/config/services/netflix.yml`(신규) — `endpoints`(manifest/licence/metadata) · `certificate` · `configuration`(drm_system=playready) · `payload_challenge` · `profiles`(H264/H265/VP9/audio/subtitles) · `esn_map` 정의.
- WordPress 측 배선: `class-vt-admin.php` 실행/설정 폼의 서비스 `<select>` 에 **Netflix 옵션 추가**(2곳), `class-vt-loader.php` 의 `sanitize_service()` 화이트리스트 및 `runner.py` 의 `--service` choices 에 `netflix` 추가, `config.json` 의 `services` 에 `netflix` 등록.
- 서비스 자동 등록(`services/__init__.py`) 통과 확인 → `SERVICE_MAP` 에 `Netflix: ['NF','netflix']` 로 정상 인식.

**🎨 콤보박스(드롭다운) 가독성 수정**
- OS 다크 테마 환경에서 `<select>` 드롭다운 목록의 배경이 어둡게 렌더링되어 텍스트가 보이지 않던 문제 수정.
- 원인: `.vt-input` 이 `--vt-surface-2`(다크 모드에서 어두운 색)를 상속하고 `<option>` 에 명시적 색상이 없었음.
- 해결: `.vt-select` 및 `option`/`optgroup`/`:focus` 에 **밝은 배경(#ffffff)·어두운 텍스트(#1e2430)·`color-scheme: light`** 를 명시적으로 고정. 다크 모드 블록에서는 `!important` 로 강제하고, `.vt-input:focus` 다크 규칙에서 `select` 를 제외(`:not(.vt-select)`).

**🧪 검증**
- 통합 테스트에 **Netflix 통합 검증 섹션(Section 10)** 추가(sanitize_service 허용/폴백, 서비스 파일 존재, LocalDevice 제거·`sel.log` 버그 수정 확인, netflix.yml 필수 키, config.json 등록 등) — **전 항목 통과**.
- `py_compile`(netflix.py/runner.py) · PHP `-l`(전 파일) · `node --check` · JSON/YAML 유효성 전부 통과.
- 내부 `@version` 태그 및 `VT_VERSION` 을 1.3.0 으로 통일.

### 1.2.0 — 한국어 자막 + SaaS UI 리디자인

**🌐 자막(한국어) 기능**
- `runner.py` 에 `--sub-lang`(기본 `ko`) · `--sub-mode`(`mux`/`burn`/`none`) 인자 추가.
- `_detect_cli_features()` 로 Vinetrimmer CLI 의 자막 플래그(`--burn-subs`/`--sub-default`/`--slang`/`--no-subs`) 지원 여부를 자동 감지하고 안전하게 폴백.
- `mux` 모드에서 지정 언어를 **기본 표시 자막 트랙**으로 설정(`--sub-default`).
- `class-vt-loader.php` 에 `sanitize_sub_lang()` · `sanitize_sub_mode()` 추가 + `run()` 에 자막 파라미터 반영.
- 자막 파라미터를 **폼 → AJAX → WP-Cron → 백그라운드 실행 → Loader** 전 경로에 배선(`vt_background_run` accepted_args 4→6).
- `config.json` 에 전역 `subtitle` 블록 추가(과거의 死파라미터 `default_subtitle_language` 를 실제 동작하도록 개선).
- 활성/삭제 시 `vt_sub_lang_default`·`vt_sub_mode_default` 옵션 등록·정리(멀티사이트 포함).

**🎨 SaaS 관리자 UI 리디자인**
- `admin-style.css` 를 디자인 토큰 기반 시스템으로 전면 재작성(그라디언트 앱바·KPI 카드·카드 레이아웃·세그먼트 컨트롤·다크 모드·반응형).
- `class-vt-admin.php` 마크업을 시맨틱 구조(app bar / KPI / 2컬럼 그리드 / 파일 카드 / 빈 상태)로 재구성.
- `admin-script.js` 에 진행률 퍼센트·엔진 상태 표시, 자막 파라미터 전송, 버튼 스피너 복원 로직 추가.

**🧪 검증**
- 통합 테스트에 **자막·config 검증 12항목** 추가(총 36항목 전부 통과).
- 내부 `@version` 태그를 1.2.0 으로 통일.

### 1.1.0 — 안정성 & 보안 대규모 정비
- **[치명적]** `includes/` 클래스가 실제 로드/인스턴스화되지 않던 문제 수정 → `VT_Plugin` 싱글턴 컨테이너 부트스트랩.
- **[치명적]** 메인 파일·클래스에 **중복 등록**되던 메뉴·AJAX·미디어 임포트 훅 제거.
- **[치명적]** 백그라운드 작업 인자 불일치(`job_id` 누락) 수정 → 진행률 추적 정상화.
- **[높음]** WordPress 미지원 `minute` 대신 커스텀 `vt_minute` 크론 등록.
- **[높음]** 명령 구성 강화(`escapeshellarg`) + `shell_exec` 사용 가능 여부 사전 점검.
- **[높음]** `runner.py`: `global args` 제거, 설정 파일 경로 전달, `finally` 임시 디렉토리 정리, 회전 로그 핸들러.
- **[중간]** `.htaccess` 순서 수정으로 CSS/JS 정상 로드 + 내부 `vinetrimmer/` 완전 잠금.
- **[중간]** 파일 목록에 미디어 임포트/삭제 버튼, MIME 폴백, `wp_safe_redirect`, `Throwable` 포착.

### 1.0.0 — 최초 릴리스
- 9개 스트리밍 서비스 지원, AJAX 백그라운드 처리, WordPress 미디어 라이브러리 연동.

---

## ⏭️ 향후 개발 권장 사항

- 실시간 진행률 폴링(`vt_check_status`) 프론트엔드 완전 연결.
- `config.json` 값을 관리자 설정 페이지에서 직접 편집.
- 자막 언어 **다중 선택 UI**(현재 콤마 입력 → 태그 선택으로 개선).
- 작업 큐(다중 동시 다운로드) 및 오래된 파일 자동 정리 스케줄링.
- 서비스별 URL 형식 검증 규칙 추가.

---

## 🙏 크레딧 & 라이선스

- **Vinetrimmer Team** — 코어 DRM 엔진
- **Bread & Sonion** — WordPress 통합 플러그인
- **Support:** https://github.com/widevineleak/Vinetrimmer-Playready-V1.0

### 라이선스
GPLv2 or later. 본 소프트웨어는 어떠한 보증도 제공하지 않으며, 사용에 따른 모든 책임은 사용자에게 있습니다.

---

<div align="center">
<sub>🍞 Vinetrimmer Playready DRM Tool · v1.4.0 · 교육/연구 목적의 DRM 상호운용성 검증용</sub>
</div>
